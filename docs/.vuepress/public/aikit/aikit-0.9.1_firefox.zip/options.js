"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res) => function __init() {
    return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/preact/dist/preact.module.js
  function s(n2, l3) {
    for (var u3 in l3)
      n2[u3] = l3[u3];
    return n2;
  }
  function a(n2) {
    var l3 = n2.parentNode;
    l3 && l3.removeChild(n2);
  }
  function h(l3, u3, i3) {
    var t3, o4, r3, f3 = {};
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o4 = u3[r3] : f3[r3] = u3[r3];
    if (arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), "function" == typeof l3 && null != l3.defaultProps)
      for (r3 in l3.defaultProps)
        void 0 === f3[r3] && (f3[r3] = l3.defaultProps[r3]);
    return v(l3, f3, t3, o4, null);
  }
  function v(n2, i3, t3, o4, r3) {
    var f3 = { type: n2, props: i3, key: t3, ref: o4, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == r3 ? ++u : r3 };
    return null == r3 && null != l.vnode && l.vnode(f3), f3;
  }
  function y() {
    return { current: null };
  }
  function p(n2) {
    return n2.children;
  }
  function d(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function _(n2, l3) {
    if (null == l3)
      return n2.__ ? _(n2.__, n2.__.__k.indexOf(n2) + 1) : null;
    for (var u3; l3 < n2.__k.length; l3++)
      if (null != (u3 = n2.__k[l3]) && null != u3.__e)
        return u3.__e;
    return "function" == typeof n2.type ? _(n2) : null;
  }
  function k(n2) {
    var l3, u3;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l3 = 0; l3 < n2.__k.length; l3++)
        if (null != (u3 = n2.__k[l3]) && null != u3.__e) {
          n2.__e = n2.__c.base = u3.__e;
          break;
        }
      return k(n2);
    }
  }
  function b(n2) {
    (!n2.__d && (n2.__d = true) && t.push(n2) && !g.__r++ || o !== l.debounceRendering) && ((o = l.debounceRendering) || setTimeout)(g);
  }
  function g() {
    for (var n2; g.__r = t.length; )
      n2 = t.sort(function(n3, l3) {
        return n3.__v.__b - l3.__v.__b;
      }), t = [], n2.some(function(n3) {
        var l3, u3, i3, t3, o4, r3;
        n3.__d && (o4 = (t3 = (l3 = n3).__v).__e, (r3 = l3.__P) && (u3 = [], (i3 = s({}, t3)).__v = t3.__v + 1, j(r3, t3, i3, l3.__n, void 0 !== r3.ownerSVGElement, null != t3.__h ? [o4] : null, u3, null == o4 ? _(t3) : o4, t3.__h), z(u3, t3), t3.__e != o4 && k(t3)));
      });
  }
  function w(n2, l3, u3, i3, t3, o4, r3, c3, s3, a3) {
    var h3, y3, d3, k4, b3, g4, w4, x4 = i3 && i3.__k || e, C3 = x4.length;
    for (u3.__k = [], h3 = 0; h3 < l3.length; h3++)
      if (null != (k4 = u3.__k[h3] = null == (k4 = l3[h3]) || "boolean" == typeof k4 ? null : "string" == typeof k4 || "number" == typeof k4 || "bigint" == typeof k4 ? v(null, k4, null, null, k4) : Array.isArray(k4) ? v(p, { children: k4 }, null, null, null) : k4.__b > 0 ? v(k4.type, k4.props, k4.key, k4.ref ? k4.ref : null, k4.__v) : k4)) {
        if (k4.__ = u3, k4.__b = u3.__b + 1, null === (d3 = x4[h3]) || d3 && k4.key == d3.key && k4.type === d3.type)
          x4[h3] = void 0;
        else
          for (y3 = 0; y3 < C3; y3++) {
            if ((d3 = x4[y3]) && k4.key == d3.key && k4.type === d3.type) {
              x4[y3] = void 0;
              break;
            }
            d3 = null;
          }
        j(n2, k4, d3 = d3 || f, t3, o4, r3, c3, s3, a3), b3 = k4.__e, (y3 = k4.ref) && d3.ref != y3 && (w4 || (w4 = []), d3.ref && w4.push(d3.ref, null, k4), w4.push(y3, k4.__c || b3, k4)), null != b3 ? (null == g4 && (g4 = b3), "function" == typeof k4.type && k4.__k === d3.__k ? k4.__d = s3 = m(k4, s3, n2) : s3 = A(n2, k4, d3, x4, b3, s3), "function" == typeof u3.type && (u3.__d = s3)) : s3 && d3.__e == s3 && s3.parentNode != n2 && (s3 = _(d3));
      }
    for (u3.__e = g4, h3 = C3; h3--; )
      null != x4[h3] && N(x4[h3], x4[h3]);
    if (w4)
      for (h3 = 0; h3 < w4.length; h3++)
        M(w4[h3], w4[++h3], w4[++h3]);
  }
  function m(n2, l3, u3) {
    for (var i3, t3 = n2.__k, o4 = 0; t3 && o4 < t3.length; o4++)
      (i3 = t3[o4]) && (i3.__ = n2, l3 = "function" == typeof i3.type ? m(i3, l3, u3) : A(u3, i3, i3, t3, i3.__e, l3));
    return l3;
  }
  function x(n2, l3) {
    return l3 = l3 || [], null == n2 || "boolean" == typeof n2 || (Array.isArray(n2) ? n2.some(function(n3) {
      x(n3, l3);
    }) : l3.push(n2)), l3;
  }
  function A(n2, l3, u3, i3, t3, o4) {
    var r3, f3, e3;
    if (void 0 !== l3.__d)
      r3 = l3.__d, l3.__d = void 0;
    else if (null == u3 || t3 != o4 || null == t3.parentNode)
      n:
        if (null == o4 || o4.parentNode !== n2)
          n2.appendChild(t3), r3 = null;
        else {
          for (f3 = o4, e3 = 0; (f3 = f3.nextSibling) && e3 < i3.length; e3 += 1)
            if (f3 == t3)
              break n;
          n2.insertBefore(t3, o4), r3 = o4;
        }
    return void 0 !== r3 ? r3 : t3.nextSibling;
  }
  function C(n2, l3, u3, i3, t3) {
    var o4;
    for (o4 in u3)
      "children" === o4 || "key" === o4 || o4 in l3 || H(n2, o4, null, u3[o4], i3);
    for (o4 in l3)
      t3 && "function" != typeof l3[o4] || "children" === o4 || "key" === o4 || "value" === o4 || "checked" === o4 || u3[o4] === l3[o4] || H(n2, o4, l3[o4], u3[o4], i3);
  }
  function $(n2, l3, u3) {
    "-" === l3[0] ? n2.setProperty(l3, u3) : n2[l3] = null == u3 ? "" : "number" != typeof u3 || c.test(l3) ? u3 : u3 + "px";
  }
  function H(n2, l3, u3, i3, t3) {
    var o4;
    n:
      if ("style" === l3)
        if ("string" == typeof u3)
          n2.style.cssText = u3;
        else {
          if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3)
            for (l3 in i3)
              u3 && l3 in u3 || $(n2.style, l3, "");
          if (u3)
            for (l3 in u3)
              i3 && u3[l3] === i3[l3] || $(n2.style, l3, u3[l3]);
        }
      else if ("o" === l3[0] && "n" === l3[1])
        o4 = l3 !== (l3 = l3.replace(/Capture$/, "")), l3 = l3.toLowerCase() in n2 ? l3.toLowerCase().slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + o4] = u3, u3 ? i3 || n2.addEventListener(l3, o4 ? T : I, o4) : n2.removeEventListener(l3, o4 ? T : I, o4);
      else if ("dangerouslySetInnerHTML" !== l3) {
        if (t3)
          l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("href" !== l3 && "list" !== l3 && "form" !== l3 && "tabIndex" !== l3 && "download" !== l3 && l3 in n2)
          try {
            n2[l3] = null == u3 ? "" : u3;
            break n;
          } catch (n3) {
          }
        "function" == typeof u3 || (null == u3 || false === u3 && -1 == l3.indexOf("-") ? n2.removeAttribute(l3) : n2.setAttribute(l3, u3));
      }
  }
  function I(n2) {
    this.l[n2.type + false](l.event ? l.event(n2) : n2);
  }
  function T(n2) {
    this.l[n2.type + true](l.event ? l.event(n2) : n2);
  }
  function j(n2, u3, i3, t3, o4, r3, f3, e3, c3) {
    var a3, h3, v3, y3, _4, k4, b3, g4, m3, x4, A4, C3, $3, H3, I3, T4 = u3.type;
    if (void 0 !== u3.constructor)
      return null;
    null != i3.__h && (c3 = i3.__h, e3 = u3.__e = i3.__e, u3.__h = null, r3 = [e3]), (a3 = l.__b) && a3(u3);
    try {
      n:
        if ("function" == typeof T4) {
          if (g4 = u3.props, m3 = (a3 = T4.contextType) && t3[a3.__c], x4 = a3 ? m3 ? m3.props.value : a3.__ : t3, i3.__c ? b3 = (h3 = u3.__c = i3.__c).__ = h3.__E : ("prototype" in T4 && T4.prototype.render ? u3.__c = h3 = new T4(g4, x4) : (u3.__c = h3 = new d(g4, x4), h3.constructor = T4, h3.render = O), m3 && m3.sub(h3), h3.props = g4, h3.state || (h3.state = {}), h3.context = x4, h3.__n = t3, v3 = h3.__d = true, h3.__h = [], h3._sb = []), null == h3.__s && (h3.__s = h3.state), null != T4.getDerivedStateFromProps && (h3.__s == h3.state && (h3.__s = s({}, h3.__s)), s(h3.__s, T4.getDerivedStateFromProps(g4, h3.__s))), y3 = h3.props, _4 = h3.state, v3)
            null == T4.getDerivedStateFromProps && null != h3.componentWillMount && h3.componentWillMount(), null != h3.componentDidMount && h3.__h.push(h3.componentDidMount);
          else {
            if (null == T4.getDerivedStateFromProps && g4 !== y3 && null != h3.componentWillReceiveProps && h3.componentWillReceiveProps(g4, x4), !h3.__e && null != h3.shouldComponentUpdate && false === h3.shouldComponentUpdate(g4, h3.__s, x4) || u3.__v === i3.__v) {
              for (h3.props = g4, h3.state = h3.__s, u3.__v !== i3.__v && (h3.__d = false), h3.__v = u3, u3.__e = i3.__e, u3.__k = i3.__k, u3.__k.forEach(function(n3) {
                n3 && (n3.__ = u3);
              }), A4 = 0; A4 < h3._sb.length; A4++)
                h3.__h.push(h3._sb[A4]);
              h3._sb = [], h3.__h.length && f3.push(h3);
              break n;
            }
            null != h3.componentWillUpdate && h3.componentWillUpdate(g4, h3.__s, x4), null != h3.componentDidUpdate && h3.__h.push(function() {
              h3.componentDidUpdate(y3, _4, k4);
            });
          }
          if (h3.context = x4, h3.props = g4, h3.__v = u3, h3.__P = n2, C3 = l.__r, $3 = 0, "prototype" in T4 && T4.prototype.render) {
            for (h3.state = h3.__s, h3.__d = false, C3 && C3(u3), a3 = h3.render(h3.props, h3.state, h3.context), H3 = 0; H3 < h3._sb.length; H3++)
              h3.__h.push(h3._sb[H3]);
            h3._sb = [];
          } else
            do {
              h3.__d = false, C3 && C3(u3), a3 = h3.render(h3.props, h3.state, h3.context), h3.state = h3.__s;
            } while (h3.__d && ++$3 < 25);
          h3.state = h3.__s, null != h3.getChildContext && (t3 = s(s({}, t3), h3.getChildContext())), v3 || null == h3.getSnapshotBeforeUpdate || (k4 = h3.getSnapshotBeforeUpdate(y3, _4)), I3 = null != a3 && a3.type === p && null == a3.key ? a3.props.children : a3, w(n2, Array.isArray(I3) ? I3 : [I3], u3, i3, t3, o4, r3, f3, e3, c3), h3.base = u3.__e, u3.__h = null, h3.__h.length && f3.push(h3), b3 && (h3.__E = h3.__ = null), h3.__e = false;
        } else
          null == r3 && u3.__v === i3.__v ? (u3.__k = i3.__k, u3.__e = i3.__e) : u3.__e = L(i3.__e, u3, i3, t3, o4, r3, f3, c3);
      (a3 = l.diffed) && a3(u3);
    } catch (n3) {
      u3.__v = null, (c3 || null != r3) && (u3.__e = e3, u3.__h = !!c3, r3[r3.indexOf(e3)] = null), l.__e(n3, u3, i3);
    }
  }
  function z(n2, u3) {
    l.__c && l.__c(u3, n2), n2.some(function(u4) {
      try {
        n2 = u4.__h, u4.__h = [], n2.some(function(n3) {
          n3.call(u4);
        });
      } catch (n3) {
        l.__e(n3, u4.__v);
      }
    });
  }
  function L(l3, u3, i3, t3, o4, r3, e3, c3) {
    var s3, h3, v3, y3 = i3.props, p3 = u3.props, d3 = u3.type, k4 = 0;
    if ("svg" === d3 && (o4 = true), null != r3) {
      for (; k4 < r3.length; k4++)
        if ((s3 = r3[k4]) && "setAttribute" in s3 == !!d3 && (d3 ? s3.localName === d3 : 3 === s3.nodeType)) {
          l3 = s3, r3[k4] = null;
          break;
        }
    }
    if (null == l3) {
      if (null === d3)
        return document.createTextNode(p3);
      l3 = o4 ? document.createElementNS("http://www.w3.org/2000/svg", d3) : document.createElement(d3, p3.is && p3), r3 = null, c3 = false;
    }
    if (null === d3)
      y3 === p3 || c3 && l3.data === p3 || (l3.data = p3);
    else {
      if (r3 = r3 && n.call(l3.childNodes), h3 = (y3 = i3.props || f).dangerouslySetInnerHTML, v3 = p3.dangerouslySetInnerHTML, !c3) {
        if (null != r3)
          for (y3 = {}, k4 = 0; k4 < l3.attributes.length; k4++)
            y3[l3.attributes[k4].name] = l3.attributes[k4].value;
        (v3 || h3) && (v3 && (h3 && v3.__html == h3.__html || v3.__html === l3.innerHTML) || (l3.innerHTML = v3 && v3.__html || ""));
      }
      if (C(l3, p3, y3, o4, c3), v3)
        u3.__k = [];
      else if (k4 = u3.props.children, w(l3, Array.isArray(k4) ? k4 : [k4], u3, i3, t3, o4 && "foreignObject" !== d3, r3, e3, r3 ? r3[0] : i3.__k && _(i3, 0), c3), null != r3)
        for (k4 = r3.length; k4--; )
          null != r3[k4] && a(r3[k4]);
      c3 || ("value" in p3 && void 0 !== (k4 = p3.value) && (k4 !== l3.value || "progress" === d3 && !k4 || "option" === d3 && k4 !== y3.value) && H(l3, "value", k4, y3.value, false), "checked" in p3 && void 0 !== (k4 = p3.checked) && k4 !== l3.checked && H(l3, "checked", k4, y3.checked, false));
    }
    return l3;
  }
  function M(n2, u3, i3) {
    try {
      "function" == typeof n2 ? n2(u3) : n2.current = u3;
    } catch (n3) {
      l.__e(n3, i3);
    }
  }
  function N(n2, u3, i3) {
    var t3, o4;
    if (l.unmount && l.unmount(n2), (t3 = n2.ref) && (t3.current && t3.current !== n2.__e || M(t3, null, u3)), null != (t3 = n2.__c)) {
      if (t3.componentWillUnmount)
        try {
          t3.componentWillUnmount();
        } catch (n3) {
          l.__e(n3, u3);
        }
      t3.base = t3.__P = null, n2.__c = void 0;
    }
    if (t3 = n2.__k)
      for (o4 = 0; o4 < t3.length; o4++)
        t3[o4] && N(t3[o4], u3, i3 || "function" != typeof n2.type);
    i3 || null == n2.__e || a(n2.__e), n2.__ = n2.__e = n2.__d = void 0;
  }
  function O(n2, l3, u3) {
    return this.constructor(n2, u3);
  }
  function P(u3, i3, t3) {
    var o4, r3, e3;
    l.__ && l.__(u3, i3), r3 = (o4 = "function" == typeof t3) ? null : t3 && t3.__k || i3.__k, e3 = [], j(i3, u3 = (!o4 && t3 || i3).__k = h(p, null, [u3]), r3 || f, f, void 0 !== i3.ownerSVGElement, !o4 && t3 ? [t3] : r3 ? null : i3.firstChild ? n.call(i3.childNodes) : null, e3, !o4 && t3 ? t3 : r3 ? r3.__e : i3.firstChild, o4), z(e3, u3);
  }
  function S(n2, l3) {
    P(n2, l3, S);
  }
  function q(l3, u3, i3) {
    var t3, o4, r3, f3 = s({}, l3.props);
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o4 = u3[r3] : f3[r3] = u3[r3];
    return arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), v(l3.type, f3, t3 || l3.key, o4 || l3.ref, null);
  }
  function B(n2, l3) {
    var u3 = { __c: l3 = "__cC" + r++, __: n2, Consumer: function(n3, l4) {
      return n3.children(l4);
    }, Provider: function(n3) {
      var u4, i3;
      return this.getChildContext || (u4 = [], (i3 = {})[l3] = this, this.getChildContext = function() {
        return i3;
      }, this.shouldComponentUpdate = function(n4) {
        this.props.value !== n4.value && u4.some(b);
      }, this.sub = function(n4) {
        u4.push(n4);
        var l4 = n4.componentWillUnmount;
        n4.componentWillUnmount = function() {
          u4.splice(u4.indexOf(n4), 1), l4 && l4.call(n4);
        };
      }), n3.children;
    } };
    return u3.Provider.__ = u3.Consumer.contextType = u3;
  }
  var n, l, u, i, t, o, r, f, e, c;
  var init_preact_module = __esm({
    "node_modules/preact/dist/preact.module.js"() {
      f = {};
      e = [];
      c = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
      n = e.slice, l = { __e: function(n2, l3, u3, i3) {
        for (var t3, o4, r3; l3 = l3.__; )
          if ((t3 = l3.__c) && !t3.__)
            try {
              if ((o4 = t3.constructor) && null != o4.getDerivedStateFromError && (t3.setState(o4.getDerivedStateFromError(n2)), r3 = t3.__d), null != t3.componentDidCatch && (t3.componentDidCatch(n2, i3 || {}), r3 = t3.__d), r3)
                return t3.__E = t3;
            } catch (l4) {
              n2 = l4;
            }
        throw n2;
      } }, u = 0, i = function(n2) {
        return null != n2 && void 0 === n2.constructor;
      }, d.prototype.setState = function(n2, l3) {
        var u3;
        u3 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n2 && (n2 = n2(s({}, u3), this.props)), n2 && s(u3, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), b(this));
      }, d.prototype.forceUpdate = function(n2) {
        this.__v && (this.__e = true, n2 && this.__h.push(n2), b(this));
      }, d.prototype.render = p, t = [], g.__r = 0, r = 0;
    }
  });

  // node_modules/preact/hooks/dist/hooks.module.js
  function d2(t3, u3) {
    l.__h && l.__h(r2, t3, o2 || u3), o2 = 0;
    var i3 = r2.__H || (r2.__H = { __: [], __h: [] });
    return t3 >= i3.__.length && i3.__.push({ __V: c2 }), i3.__[t3];
  }
  function p2(n2) {
    return o2 = 1, y2(B2, n2);
  }
  function y2(n2, u3, i3) {
    var o4 = d2(t2++, 2);
    if (o4.t = n2, !o4.__c && (o4.__ = [i3 ? i3(u3) : B2(void 0, u3), function(n3) {
      var t3 = o4.__N ? o4.__N[0] : o4.__[0], r3 = o4.t(t3, n3);
      t3 !== r3 && (o4.__N = [r3, o4.__[1]], o4.__c.setState({}));
    }], o4.__c = r2, !r2.u)) {
      r2.u = true;
      var f3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        if (!o4.__c.__H)
          return true;
        var u4 = o4.__c.__H.__.filter(function(n4) {
          return n4.__c;
        });
        if (u4.every(function(n4) {
          return !n4.__N;
        }))
          return !f3 || f3.call(this, n3, t3, r3);
        var i4 = false;
        return u4.forEach(function(n4) {
          if (n4.__N) {
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), !(!i4 && o4.__c.props === n3) && (!f3 || f3.call(this, n3, t3, r3));
      };
    }
    return o4.__N || o4.__;
  }
  function h2(u3, i3) {
    var o4 = d2(t2++, 3);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__H.__h.push(o4));
  }
  function s2(u3, i3) {
    var o4 = d2(t2++, 4);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__h.push(o4));
  }
  function _2(n2) {
    return o2 = 5, F(function() {
      return { current: n2 };
    }, []);
  }
  function A2(n2, t3, r3) {
    o2 = 6, s2(function() {
      return "function" == typeof n2 ? (n2(t3()), function() {
        return n2(null);
      }) : n2 ? (n2.current = t3(), function() {
        return n2.current = null;
      }) : void 0;
    }, null == r3 ? r3 : r3.concat(n2));
  }
  function F(n2, r3) {
    var u3 = d2(t2++, 7);
    return z2(u3.__H, r3) ? (u3.__V = n2(), u3.i = r3, u3.__h = n2, u3.__V) : u3.__;
  }
  function T2(n2, t3) {
    return o2 = 8, F(function() {
      return n2;
    }, t3);
  }
  function q2(n2) {
    var u3 = r2.context[n2.__c], i3 = d2(t2++, 9);
    return i3.c = n2, u3 ? (null == i3.__ && (i3.__ = true, u3.sub(r2)), u3.props.value) : n2.__;
  }
  function x2(t3, r3) {
    l.useDebugValue && l.useDebugValue(r3 ? r3(t3) : t3);
  }
  function P2(n2) {
    var u3 = d2(t2++, 10), i3 = p2();
    return u3.__ = n2, r2.componentDidCatch || (r2.componentDidCatch = function(n3, t3) {
      u3.__ && u3.__(n3, t3), i3[1](n3);
    }), [i3[0], function() {
      i3[1](void 0);
    }];
  }
  function V() {
    var n2 = d2(t2++, 11);
    if (!n2.__) {
      for (var u3 = r2.__v; null !== u3 && !u3.__m && null !== u3.__; )
        u3 = u3.__;
      var i3 = u3.__m || (u3.__m = [0, 0]);
      n2.__ = "P" + i3[0] + "-" + i3[1]++;
    }
    return n2.__;
  }
  function b2() {
    for (var t3; t3 = f2.shift(); )
      if (t3.__P && t3.__H)
        try {
          t3.__H.__h.forEach(k2), t3.__H.__h.forEach(w2), t3.__H.__h = [];
        } catch (r3) {
          t3.__H.__h = [], l.__e(r3, t3.__v);
        }
  }
  function j2(n2) {
    var t3, r3 = function() {
      clearTimeout(u3), g2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u3 = setTimeout(r3, 100);
    g2 && (t3 = requestAnimationFrame(r3));
  }
  function k2(n2) {
    var t3 = r2, u3 = n2.__c;
    "function" == typeof u3 && (n2.__c = void 0, u3()), r2 = t3;
  }
  function w2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function z2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  function B2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }
  var t2, r2, u2, i2, o2, f2, c2, e2, a2, v2, l2, m2, g2;
  var init_hooks_module = __esm({
    "node_modules/preact/hooks/dist/hooks.module.js"() {
      init_preact_module();
      o2 = 0;
      f2 = [];
      c2 = [];
      e2 = l.__b;
      a2 = l.__r;
      v2 = l.diffed;
      l2 = l.__c;
      m2 = l.unmount;
      l.__b = function(n2) {
        r2 = null, e2 && e2(n2);
      }, l.__r = function(n2) {
        a2 && a2(n2), t2 = 0;
        var i3 = (r2 = n2.__c).__H;
        i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.forEach(function(n3) {
          n3.__N && (n3.__ = n3.__N), n3.__V = c2, n3.__N = n3.i = void 0;
        })) : (i3.__h.forEach(k2), i3.__h.forEach(w2), i3.__h = [])), u2 = r2;
      }, l.diffed = function(t3) {
        v2 && v2(t3);
        var o4 = t3.__c;
        o4 && o4.__H && (o4.__H.__h.length && (1 !== f2.push(o4) && i2 === l.requestAnimationFrame || ((i2 = l.requestAnimationFrame) || j2)(b2)), o4.__H.__.forEach(function(n2) {
          n2.i && (n2.__H = n2.i), n2.__V !== c2 && (n2.__ = n2.__V), n2.i = void 0, n2.__V = c2;
        })), u2 = r2 = null;
      }, l.__c = function(t3, r3) {
        r3.some(function(t4) {
          try {
            t4.__h.forEach(k2), t4.__h = t4.__h.filter(function(n2) {
              return !n2.__ || w2(n2);
            });
          } catch (u3) {
            r3.some(function(n2) {
              n2.__h && (n2.__h = []);
            }), r3 = [], l.__e(u3, t4.__v);
          }
        }), l2 && l2(t3, r3);
      }, l.unmount = function(t3) {
        m2 && m2(t3);
        var r3, u3 = t3.__c;
        u3 && u3.__H && (u3.__H.__.forEach(function(n2) {
          try {
            k2(n2);
          } catch (n3) {
            r3 = n3;
          }
        }), u3.__H = void 0, r3 && l.__e(r3, u3.__v));
      };
      g2 = "function" == typeof requestAnimationFrame;
    }
  });

  // node_modules/preact/compat/dist/compat.module.js
  function g3(n2, t3) {
    for (var e3 in t3)
      n2[e3] = t3[e3];
    return n2;
  }
  function C2(n2, t3) {
    for (var e3 in n2)
      if ("__source" !== e3 && !(e3 in t3))
        return true;
    for (var r3 in t3)
      if ("__source" !== r3 && n2[r3] !== t3[r3])
        return true;
    return false;
  }
  function E(n2, t3) {
    return n2 === t3 && (0 !== n2 || 1 / n2 == 1 / t3) || n2 != n2 && t3 != t3;
  }
  function w3(n2) {
    this.props = n2;
  }
  function R(n2, e3) {
    function r3(n3) {
      var t3 = this.props.ref, r4 = t3 == n3.ref;
      return !r4 && t3 && (t3.call ? t3(null) : t3.current = null), e3 ? !e3(this.props, n3) || !r4 : C2(this.props, n3);
    }
    function u3(e4) {
      return this.shouldComponentUpdate = r3, h(n2, e4);
    }
    return u3.displayName = "Memo(" + (n2.displayName || n2.name) + ")", u3.prototype.isReactComponent = true, u3.__f = true, u3;
  }
  function k3(n2) {
    function t3(t4) {
      var e3 = g3({}, t4);
      return delete e3.ref, n2(e3, t4.ref || null);
    }
    return t3.$$typeof = N2, t3.render = t3, t3.prototype.isReactComponent = t3.__f = true, t3.displayName = "ForwardRef(" + (n2.displayName || n2.name) + ")", t3;
  }
  function L2(n2, t3, e3) {
    return n2 && (n2.__c && n2.__c.__H && (n2.__c.__H.__.forEach(function(n3) {
      "function" == typeof n3.__c && n3.__c();
    }), n2.__c.__H = null), null != (n2 = g3({}, n2)).__c && (n2.__c.__P === e3 && (n2.__c.__P = t3), n2.__c = null), n2.__k = n2.__k && n2.__k.map(function(n3) {
      return L2(n3, t3, e3);
    })), n2;
  }
  function U(n2, t3, e3) {
    return n2 && (n2.__v = null, n2.__k = n2.__k && n2.__k.map(function(n3) {
      return U(n3, t3, e3);
    }), n2.__c && n2.__c.__P === t3 && (n2.__e && e3.insertBefore(n2.__e, n2.__d), n2.__c.__e = true, n2.__c.__P = e3)), n2;
  }
  function D() {
    this.__u = 0, this.t = null, this.__b = null;
  }
  function F2(n2) {
    var t3 = n2.__.__c;
    return t3 && t3.__a && t3.__a(n2);
  }
  function M2(n2) {
    var e3, r3, u3;
    function o4(o5) {
      if (e3 || (e3 = n2()).then(function(n3) {
        r3 = n3.default || n3;
      }, function(n3) {
        u3 = n3;
      }), u3)
        throw u3;
      if (!r3)
        throw e3;
      return h(r3, o5);
    }
    return o4.displayName = "Lazy", o4.__f = true, o4;
  }
  function V2() {
    this.u = null, this.o = null;
  }
  function P3(n2) {
    return this.getChildContext = function() {
      return n2.context;
    }, n2.children;
  }
  function $2(n2) {
    var e3 = this, r3 = n2.i;
    e3.componentWillUnmount = function() {
      P(null, e3.l), e3.l = null, e3.i = null;
    }, e3.i && e3.i !== r3 && e3.componentWillUnmount(), n2.__v ? (e3.l || (e3.i = r3, e3.l = { nodeType: 1, parentNode: r3, childNodes: [], appendChild: function(n3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, insertBefore: function(n3, t3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, removeChild: function(n3) {
      this.childNodes.splice(this.childNodes.indexOf(n3) >>> 1, 1), e3.i.removeChild(n3);
    } }), P(h(P3, { context: e3.context }, n2.__v), e3.l)) : e3.l && e3.componentWillUnmount();
  }
  function j3(n2, e3) {
    var r3 = h($2, { __v: n2, i: e3 });
    return r3.containerInfo = e3, r3;
  }
  function Y(n2, t3, e3) {
    return null == t3.__k && (t3.textContent = ""), P(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function q3(n2, t3, e3) {
    return S(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function J() {
  }
  function K() {
    return this.cancelBubble;
  }
  function Q() {
    return this.defaultPrevented;
  }
  function on(n2) {
    return h.bind(null, n2);
  }
  function ln(n2) {
    return !!n2 && n2.$$typeof === z3;
  }
  function cn(n2) {
    return ln(n2) ? q.apply(null, arguments) : n2;
  }
  function fn(n2) {
    return !!n2.__k && (P(null, n2), true);
  }
  function an(n2) {
    return n2 && (n2.base || 1 === n2.nodeType && n2) || null;
  }
  function dn(n2) {
    n2();
  }
  function pn(n2) {
    return n2;
  }
  function mn() {
    return [false, dn];
  }
  function _n(n2, t3) {
    var e3 = t3(), r3 = p2({ h: { __: e3, v: t3 } }), u3 = r3[0].h, o4 = r3[1];
    return s2(function() {
      u3.__ = e3, u3.v = t3, E(u3.__, t3()) || o4({ h: u3 });
    }, [n2, e3, t3]), h2(function() {
      return E(u3.__, u3.v()) || o4({ h: u3 }), n2(function() {
        E(u3.__, u3.v()) || o4({ h: u3 });
      });
    }, [n2]), e3;
  }
  var x3, N2, A3, O2, T3, I2, W, z3, B3, H2, Z, G, X, nn, tn, en, rn, un, sn, hn, vn, yn, bn;
  var init_compat_module = __esm({
    "node_modules/preact/compat/dist/compat.module.js"() {
      init_preact_module();
      init_preact_module();
      init_hooks_module();
      init_hooks_module();
      (w3.prototype = new d()).isPureReactComponent = true, w3.prototype.shouldComponentUpdate = function(n2, t3) {
        return C2(this.props, n2) || C2(this.state, t3);
      };
      x3 = l.__b;
      l.__b = function(n2) {
        n2.type && n2.type.__f && n2.ref && (n2.props.ref = n2.ref, n2.ref = null), x3 && x3(n2);
      };
      N2 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
      A3 = function(n2, t3) {
        return null == n2 ? null : x(x(n2).map(t3));
      };
      O2 = { map: A3, forEach: A3, count: function(n2) {
        return n2 ? x(n2).length : 0;
      }, only: function(n2) {
        var t3 = x(n2);
        if (1 !== t3.length)
          throw "Children.only";
        return t3[0];
      }, toArray: x };
      T3 = l.__e;
      l.__e = function(n2, t3, e3, r3) {
        if (n2.then) {
          for (var u3, o4 = t3; o4 = o4.__; )
            if ((u3 = o4.__c) && u3.__c)
              return null == t3.__e && (t3.__e = e3.__e, t3.__k = e3.__k), u3.__c(n2, t3);
        }
        T3(n2, t3, e3, r3);
      };
      I2 = l.unmount;
      l.unmount = function(n2) {
        var t3 = n2.__c;
        t3 && t3.__R && t3.__R(), t3 && true === n2.__h && (n2.type = null), I2 && I2(n2);
      }, (D.prototype = new d()).__c = function(n2, t3) {
        var e3 = t3.__c, r3 = this;
        null == r3.t && (r3.t = []), r3.t.push(e3);
        var u3 = F2(r3.__v), o4 = false, i3 = function() {
          o4 || (o4 = true, e3.__R = null, u3 ? u3(l3) : l3());
        };
        e3.__R = i3;
        var l3 = function() {
          if (!--r3.__u) {
            if (r3.state.__a) {
              var n3 = r3.state.__a;
              r3.__v.__k[0] = U(n3, n3.__c.__P, n3.__c.__O);
            }
            var t4;
            for (r3.setState({ __a: r3.__b = null }); t4 = r3.t.pop(); )
              t4.forceUpdate();
          }
        }, c3 = true === t3.__h;
        r3.__u++ || c3 || r3.setState({ __a: r3.__b = r3.__v.__k[0] }), n2.then(i3, i3);
      }, D.prototype.componentWillUnmount = function() {
        this.t = [];
      }, D.prototype.render = function(n2, e3) {
        if (this.__b) {
          if (this.__v.__k) {
            var r3 = document.createElement("div"), o4 = this.__v.__k[0].__c;
            this.__v.__k[0] = L2(this.__b, r3, o4.__O = o4.__P);
          }
          this.__b = null;
        }
        var i3 = e3.__a && h(p, null, n2.fallback);
        return i3 && (i3.__h = null), [h(p, null, e3.__a ? null : n2.children), i3];
      };
      W = function(n2, t3, e3) {
        if (++e3[1] === e3[0] && n2.o.delete(t3), n2.props.revealOrder && ("t" !== n2.props.revealOrder[0] || !n2.o.size))
          for (e3 = n2.u; e3; ) {
            for (; e3.length > 3; )
              e3.pop()();
            if (e3[1] < e3[0])
              break;
            n2.u = e3 = e3[2];
          }
      };
      (V2.prototype = new d()).__a = function(n2) {
        var t3 = this, e3 = F2(t3.__v), r3 = t3.o.get(n2);
        return r3[0]++, function(u3) {
          var o4 = function() {
            t3.props.revealOrder ? (r3.push(u3), W(t3, n2, r3)) : u3();
          };
          e3 ? e3(o4) : o4();
        };
      }, V2.prototype.render = function(n2) {
        this.u = null, this.o = /* @__PURE__ */ new Map();
        var t3 = x(n2.children);
        n2.revealOrder && "b" === n2.revealOrder[0] && t3.reverse();
        for (var e3 = t3.length; e3--; )
          this.o.set(t3[e3], this.u = [1, 0, this.u]);
        return n2.children;
      }, V2.prototype.componentDidUpdate = V2.prototype.componentDidMount = function() {
        var n2 = this;
        this.o.forEach(function(t3, e3) {
          W(n2, e3, t3);
        });
      };
      z3 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
      B3 = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
      H2 = "undefined" != typeof document;
      Z = function(n2) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/i : /fil|che|ra/i).test(n2);
      };
      d.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t3) {
        Object.defineProperty(d.prototype, t3, { configurable: true, get: function() {
          return this["UNSAFE_" + t3];
        }, set: function(n2) {
          Object.defineProperty(this, t3, { configurable: true, writable: true, value: n2 });
        } });
      });
      G = l.event;
      l.event = function(n2) {
        return G && (n2 = G(n2)), n2.persist = J, n2.isPropagationStopped = K, n2.isDefaultPrevented = Q, n2.nativeEvent = n2;
      };
      nn = { configurable: true, get: function() {
        return this.class;
      } };
      tn = l.vnode;
      l.vnode = function(n2) {
        var t3 = n2.type, e3 = n2.props, u3 = e3;
        if ("string" == typeof t3) {
          var o4 = -1 === t3.indexOf("-");
          for (var i3 in u3 = {}, e3) {
            var l3 = e3[i3];
            H2 && "children" === i3 && "noscript" === t3 || "value" === i3 && "defaultValue" in e3 && null == l3 || ("defaultValue" === i3 && "value" in e3 && null == e3.value ? i3 = "value" : "download" === i3 && true === l3 ? l3 = "" : /ondoubleclick/i.test(i3) ? i3 = "ondblclick" : /^onchange(textarea|input)/i.test(i3 + t3) && !Z(e3.type) ? i3 = "oninput" : /^onfocus$/i.test(i3) ? i3 = "onfocusin" : /^onblur$/i.test(i3) ? i3 = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(i3) ? i3 = i3.toLowerCase() : o4 && B3.test(i3) ? i3 = i3.replace(/[A-Z0-9]/g, "-$&").toLowerCase() : null === l3 && (l3 = void 0), /^oninput$/i.test(i3) && (i3 = i3.toLowerCase(), u3[i3] && (i3 = "oninputCapture")), u3[i3] = l3);
          }
          "select" == t3 && u3.multiple && Array.isArray(u3.value) && (u3.value = x(e3.children).forEach(function(n3) {
            n3.props.selected = -1 != u3.value.indexOf(n3.props.value);
          })), "select" == t3 && null != u3.defaultValue && (u3.value = x(e3.children).forEach(function(n3) {
            n3.props.selected = u3.multiple ? -1 != u3.defaultValue.indexOf(n3.props.value) : u3.defaultValue == n3.props.value;
          })), n2.props = u3, e3.class != e3.className && (nn.enumerable = "className" in e3, null != e3.className && (u3.class = e3.className), Object.defineProperty(u3, "className", nn));
        }
        n2.$$typeof = z3, tn && tn(n2);
      };
      en = l.__r;
      l.__r = function(n2) {
        en && en(n2), X = n2.__c;
      };
      rn = { ReactCurrentDispatcher: { current: { readContext: function(n2) {
        return X.__n[n2.__c].props.value;
      } } } };
      un = "17.0.2";
      sn = function(n2, t3) {
        return n2(t3);
      };
      hn = function(n2, t3) {
        return n2(t3);
      };
      vn = p;
      yn = s2;
      bn = { useState: p2, useId: V, useReducer: y2, useEffect: h2, useLayoutEffect: s2, useInsertionEffect: yn, useTransition: mn, useDeferredValue: pn, useSyncExternalStore: _n, startTransition: dn, useRef: _2, useImperativeHandle: A2, useMemo: F, useCallback: T2, useContext: q2, useDebugValue: x2, version: "17.0.2", Children: O2, render: Y, hydrate: q3, unmountComponentAtNode: fn, createPortal: j3, createElement: h, createContext: B, createFactory: on, cloneElement: cn, createRef: y, Fragment: p, isValidElement: ln, findDOMNode: an, Component: d, PureComponent: w3, memo: R, forwardRef: k3, flushSync: hn, unstable_batchedUpdates: sn, StrictMode: vn, Suspense: D, SuspenseList: V2, lazy: M2, __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: rn };
    }
  });

  // node_modules/react/index.mjs
  var react_exports = {};
  __export(react_exports, {
    Children: () => O2,
    Component: () => d,
    Fragment: () => p,
    PureComponent: () => w3,
    StrictMode: () => vn,
    Suspense: () => D,
    SuspenseList: () => V2,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => rn,
    cloneElement: () => cn,
    createContext: () => B,
    createElement: () => h,
    createFactory: () => on,
    createPortal: () => j3,
    createRef: () => y,
    default: () => bn,
    findDOMNode: () => an,
    flushSync: () => hn,
    forwardRef: () => k3,
    hydrate: () => q3,
    isValidElement: () => ln,
    lazy: () => M2,
    memo: () => R,
    render: () => Y,
    startTransition: () => dn,
    unmountComponentAtNode: () => fn,
    unstable_batchedUpdates: () => sn,
    useCallback: () => T2,
    useContext: () => q2,
    useDebugValue: () => x2,
    useDeferredValue: () => pn,
    useEffect: () => h2,
    useErrorBoundary: () => P2,
    useId: () => V,
    useImperativeHandle: () => A2,
    useInsertionEffect: () => yn,
    useLayoutEffect: () => s2,
    useMemo: () => F,
    useReducer: () => y2,
    useRef: () => _2,
    useState: () => p2,
    useSyncExternalStore: () => _n,
    useTransition: () => mn,
    version: () => un
  });
  var init_react = __esm({
    "node_modules/react/index.mjs"() {
      init_compat_module();
      init_compat_module();
    }
  });

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports2, module2) {
      (function(global2, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports2 !== "undefined") {
          factory(module2);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global2.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports2, function(module3) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty7 = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache2 = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache2;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache2) {
                    return cache2[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty7(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty7(wrappers, prop) || hasOwnProperty7(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty7(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache2, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache2[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache2) {
                    cache2[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache2, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache2, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(
                  req,
                  {},
                  {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  }
                );
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module3.exports = wrapAPIs(chrome);
        } else {
          module3.exports = globalThis.browser;
        }
      });
    }
  });

  // node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.min.js
  var require_use_sync_external_store_shim_production_min = __commonJS({
    "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.min.js"(exports2) {
      "use strict";
      var e3 = (init_react(), __toCommonJS(react_exports));
      function h3(a3, b3) {
        return a3 === b3 && (0 !== a3 || 1 / a3 === 1 / b3) || a3 !== a3 && b3 !== b3;
      }
      var k4 = "function" === typeof Object.is ? Object.is : h3;
      var l3 = e3.useState;
      var m3 = e3.useEffect;
      var n2 = e3.useLayoutEffect;
      var p3 = e3.useDebugValue;
      function q4(a3, b3) {
        var d3 = b3(), f3 = l3({ inst: { value: d3, getSnapshot: b3 } }), c3 = f3[0].inst, g4 = f3[1];
        n2(function() {
          c3.value = d3;
          c3.getSnapshot = b3;
          r3(c3) && g4({ inst: c3 });
        }, [a3, d3, b3]);
        m3(function() {
          r3(c3) && g4({ inst: c3 });
          return a3(function() {
            r3(c3) && g4({ inst: c3 });
          });
        }, [a3]);
        p3(d3);
        return d3;
      }
      function r3(a3) {
        var b3 = a3.getSnapshot;
        a3 = a3.value;
        try {
          var d3 = b3();
          return !k4(a3, d3);
        } catch (f3) {
          return true;
        }
      }
      function t3(a3, b3) {
        return b3();
      }
      var u3 = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? t3 : q4;
      exports2.useSyncExternalStore = void 0 !== e3.useSyncExternalStore ? e3.useSyncExternalStore : u3;
    }
  });

  // node_modules/use-sync-external-store/shim/index.js
  var require_shim = __commonJS({
    "node_modules/use-sync-external-store/shim/index.js"(exports2, module2) {
      "use strict";
      if (true) {
        module2.exports = require_use_sync_external_store_shim_production_min();
      } else {
        module2.exports = null;
      }
    }
  });

  // src/options/index.tsx
  init_preact_module();

  // node_modules/@babel/runtime/helpers/esm/extends.js
  function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
      for (var i3 = 1; i3 < arguments.length; i3++) {
        var source = arguments[i3];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    return _extends.apply(this, arguments);
  }

  // node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js
  function _arrayWithHoles(arr) {
    if (Array.isArray(arr))
      return arr;
  }

  // node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js
  function _iterableToArrayLimit(arr, i3) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
      var _s, _e, _x, _r, _arr = [], _n2 = true, _d = false;
      try {
        if (_x = (_i = _i.call(arr)).next, 0 === i3) {
          if (Object(_i) !== _i)
            return;
          _n2 = false;
        } else
          for (; !(_n2 = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i3); _n2 = true)
            ;
      } catch (err) {
        _d = true, _e = err;
      } finally {
        try {
          if (!_n2 && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r))
            return;
        } finally {
          if (_d)
            throw _e;
        }
      }
      return _arr;
    }
  }

  // node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js
  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length)
      len = arr.length;
    for (var i3 = 0, arr2 = new Array(len); i3 < len; i3++)
      arr2[i3] = arr[i3];
    return arr2;
  }

  // node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js
  function _unsupportedIterableToArray(o4, minLen) {
    if (!o4)
      return;
    if (typeof o4 === "string")
      return _arrayLikeToArray(o4, minLen);
    var n2 = Object.prototype.toString.call(o4).slice(8, -1);
    if (n2 === "Object" && o4.constructor)
      n2 = o4.constructor.name;
    if (n2 === "Map" || n2 === "Set")
      return Array.from(o4);
    if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
      return _arrayLikeToArray(o4, minLen);
  }

  // node_modules/@babel/runtime/helpers/esm/nonIterableRest.js
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  // node_modules/@babel/runtime/helpers/esm/slicedToArray.js
  function _slicedToArray(arr, i3) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i3) || _unsupportedIterableToArray(arr, i3) || _nonIterableRest();
  }

  // node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
  function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null)
      return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i3;
    for (i3 = 0; i3 < sourceKeys.length; i3++) {
      key = sourceKeys[i3];
      if (excluded.indexOf(key) >= 0)
        continue;
      target[key] = source[key];
    }
    return target;
  }

  // node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js
  function _objectWithoutProperties(source, excluded) {
    if (source == null)
      return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i3;
    if (Object.getOwnPropertySymbols) {
      var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
      for (i3 = 0; i3 < sourceSymbolKeys.length; i3++) {
        key = sourceSymbolKeys[i3];
        if (excluded.indexOf(key) >= 0)
          continue;
        if (!Object.prototype.propertyIsEnumerable.call(source, key))
          continue;
        target[key] = source[key];
      }
    }
    return target;
  }

  // node_modules/@geist-ui/core/esm/styled-jsx.es.js
  init_react();
  var style$1 = {};
  var stylesheetRegistry = {};
  function hash(str) {
    var hash2 = 5381, i3 = str.length;
    while (i3) {
      hash2 = hash2 * 33 ^ str.charCodeAt(--i3);
    }
    return hash2 >>> 0;
  }
  var stringHash = hash;
  var stylesheet = {};
  (function(exports2) {
    exports2.__esModule = true;
    exports2["default"] = void 0;
    function _defineProperties(target, props) {
      for (var i3 = 0; i3 < props.length; i3++) {
        var descriptor = props[i3];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor)
          descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass(Constructor, protoProps, staticProps) {
      if (protoProps)
        _defineProperties(Constructor.prototype, protoProps);
      if (staticProps)
        _defineProperties(Constructor, staticProps);
      return Constructor;
    }
    var isProd = typeof process !== "undefined" && process.env && true;
    var isString = function isString2(o4) {
      return Object.prototype.toString.call(o4) === "[object String]";
    };
    var StyleSheet = /* @__PURE__ */ function() {
      function StyleSheet2(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, _ref$name = _ref.name, name = _ref$name === void 0 ? "stylesheet" : _ref$name, _ref$optimizeForSpeed = _ref.optimizeForSpeed, optimizeForSpeed = _ref$optimizeForSpeed === void 0 ? isProd : _ref$optimizeForSpeed, _ref$isBrowser = _ref.isBrowser, isBrowser3 = _ref$isBrowser === void 0 ? typeof window !== "undefined" : _ref$isBrowser;
        invariant(isString(name), "`name` must be a string");
        this._name = name;
        this._deletedRulePlaceholder = "#" + name + "-deleted-rule____{}";
        invariant(
          typeof optimizeForSpeed === "boolean",
          "`optimizeForSpeed` must be a boolean"
        );
        this._optimizeForSpeed = optimizeForSpeed;
        this._isBrowser = isBrowser3;
        this._serverSheet = void 0;
        this._tags = [];
        this._injected = false;
        this._rulesCount = 0;
        var node = this._isBrowser && document.querySelector('meta[property="csp-nonce"]');
        this._nonce = node ? node.getAttribute("content") : null;
      }
      var _proto = StyleSheet2.prototype;
      _proto.setOptimizeForSpeed = function setOptimizeForSpeed(bool) {
        invariant(typeof bool === "boolean", "`setOptimizeForSpeed` accepts a boolean");
        invariant(
          this._rulesCount === 0,
          "optimizeForSpeed cannot be when rules have already been inserted"
        );
        this.flush();
        this._optimizeForSpeed = bool;
        this.inject();
      };
      _proto.isOptimizeForSpeed = function isOptimizeForSpeed() {
        return this._optimizeForSpeed;
      };
      _proto.inject = function inject() {
        var _this = this;
        invariant(!this._injected, "sheet already injected");
        this._injected = true;
        if (this._isBrowser && this._optimizeForSpeed) {
          this._tags[0] = this.makeStyleTag(this._name);
          this._optimizeForSpeed = "insertRule" in this.getSheet();
          if (!this._optimizeForSpeed) {
            if (!isProd) {
              console.warn(
                "StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."
              );
            }
            this.flush();
            this._injected = true;
          }
          return;
        }
        this._serverSheet = {
          cssRules: [],
          insertRule: function insertRule(rule, index) {
            if (typeof index === "number") {
              _this._serverSheet.cssRules[index] = {
                cssText: rule
              };
            } else {
              _this._serverSheet.cssRules.push({
                cssText: rule
              });
            }
            return index;
          },
          deleteRule: function deleteRule(index) {
            _this._serverSheet.cssRules[index] = null;
          }
        };
      };
      _proto.getSheetForTag = function getSheetForTag(tag) {
        if (tag.sheet) {
          return tag.sheet;
        }
        for (var i3 = 0; i3 < document.styleSheets.length; i3++) {
          if (document.styleSheets[i3].ownerNode === tag) {
            return document.styleSheets[i3];
          }
        }
      };
      _proto.getSheet = function getSheet() {
        return this.getSheetForTag(this._tags[this._tags.length - 1]);
      };
      _proto.insertRule = function insertRule(rule, index) {
        invariant(isString(rule), "`insertRule` accepts only strings");
        if (!this._isBrowser) {
          if (typeof index !== "number") {
            index = this._serverSheet.cssRules.length;
          }
          this._serverSheet.insertRule(rule, index);
          return this._rulesCount++;
        }
        if (this._optimizeForSpeed) {
          var sheet = this.getSheet();
          if (typeof index !== "number") {
            index = sheet.cssRules.length;
          }
          try {
            sheet.insertRule(rule, index);
          } catch (error) {
            if (!isProd) {
              console.warn(
                "StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info"
              );
            }
            return -1;
          }
        } else {
          var insertionPoint = this._tags[index];
          this._tags.push(this.makeStyleTag(this._name, rule, insertionPoint));
        }
        return this._rulesCount++;
      };
      _proto.replaceRule = function replaceRule(index, rule) {
        if (this._optimizeForSpeed || !this._isBrowser) {
          var sheet = this._isBrowser ? this.getSheet() : this._serverSheet;
          if (!rule.trim()) {
            rule = this._deletedRulePlaceholder;
          }
          if (!sheet.cssRules[index]) {
            return index;
          }
          sheet.deleteRule(index);
          try {
            sheet.insertRule(rule, index);
          } catch (error) {
            if (!isProd) {
              console.warn(
                "StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info"
              );
            }
            sheet.insertRule(this._deletedRulePlaceholder, index);
          }
        } else {
          var tag = this._tags[index];
          invariant(tag, "old rule at index `" + index + "` not found");
          tag.textContent = rule;
        }
        return index;
      };
      _proto.deleteRule = function deleteRule(index) {
        if (!this._isBrowser) {
          this._serverSheet.deleteRule(index);
          return;
        }
        if (this._optimizeForSpeed) {
          this.replaceRule(index, "");
        } else {
          var tag = this._tags[index];
          invariant(tag, "rule at index `" + index + "` not found");
          tag.parentNode.removeChild(tag);
          this._tags[index] = null;
        }
      };
      _proto.flush = function flush() {
        this._injected = false;
        this._rulesCount = 0;
        if (this._isBrowser) {
          this._tags.forEach(function(tag) {
            return tag && tag.parentNode.removeChild(tag);
          });
          this._tags = [];
        } else {
          this._serverSheet.cssRules = [];
        }
      };
      _proto.cssRules = function cssRules() {
        var _this2 = this;
        if (!this._isBrowser) {
          return this._serverSheet.cssRules;
        }
        return this._tags.reduce(function(rules, tag) {
          if (tag) {
            rules = rules.concat(
              Array.prototype.map.call(
                _this2.getSheetForTag(tag).cssRules,
                function(rule) {
                  return rule.cssText === _this2._deletedRulePlaceholder ? null : rule;
                }
              )
            );
          } else {
            rules.push(null);
          }
          return rules;
        }, []);
      };
      _proto.makeStyleTag = function makeStyleTag(name, cssString, relativeToTag) {
        if (cssString) {
          invariant(
            isString(cssString),
            "makeStyleTag acceps only strings as second parameter"
          );
        }
        var tag = document.createElement("style");
        if (this._nonce)
          tag.setAttribute("nonce", this._nonce);
        tag.type = "text/css";
        tag.setAttribute("data-" + name, "");
        if (cssString) {
          tag.appendChild(document.createTextNode(cssString));
        }
        var head = document.head || document.getElementsByTagName("head")[0];
        if (relativeToTag) {
          head.insertBefore(tag, relativeToTag);
        } else {
          head.appendChild(tag);
        }
        return tag;
      };
      _createClass(StyleSheet2, [
        {
          key: "length",
          get: function get() {
            return this._rulesCount;
          }
        }
      ]);
      return StyleSheet2;
    }();
    exports2["default"] = StyleSheet;
    function invariant(condition, message) {
      if (!condition) {
        throw new Error("StyleSheet: " + message + ".");
      }
    }
  })(stylesheet);
  (function(exports2) {
    exports2.__esModule = true;
    exports2["default"] = void 0;
    var _stringHash = _interopRequireDefault(stringHash);
    var _stylesheet = _interopRequireDefault(stylesheet);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var sanitize = function sanitize2(rule) {
      return rule.replace(/\/style/gi, "\\/style");
    };
    var StyleSheetRegistry = /* @__PURE__ */ function() {
      function StyleSheetRegistry2(_temp) {
        var _ref = _temp === void 0 ? {} : _temp, _ref$styleSheet = _ref.styleSheet, styleSheet = _ref$styleSheet === void 0 ? null : _ref$styleSheet, _ref$optimizeForSpeed = _ref.optimizeForSpeed, optimizeForSpeed = _ref$optimizeForSpeed === void 0 ? false : _ref$optimizeForSpeed, _ref$isBrowser = _ref.isBrowser, isBrowser3 = _ref$isBrowser === void 0 ? typeof window !== "undefined" : _ref$isBrowser;
        this._sheet = styleSheet || new _stylesheet["default"]({
          name: "styled-jsx",
          optimizeForSpeed
        });
        this._sheet.inject();
        if (styleSheet && typeof optimizeForSpeed === "boolean") {
          this._sheet.setOptimizeForSpeed(optimizeForSpeed);
          this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
        }
        this._isBrowser = isBrowser3;
        this._fromServer = void 0;
        this._indices = {};
        this._instancesCounts = {};
        this.computeId = this.createComputeId();
        this.computeSelector = this.createComputeSelector();
      }
      var _proto = StyleSheetRegistry2.prototype;
      _proto.add = function add(props) {
        var _this = this;
        if (void 0 === this._optimizeForSpeed) {
          this._optimizeForSpeed = Array.isArray(props.children);
          this._sheet.setOptimizeForSpeed(this._optimizeForSpeed);
          this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
        }
        if (this._isBrowser && !this._fromServer) {
          this._fromServer = this.selectFromServer();
          this._instancesCounts = Object.keys(this._fromServer).reduce(
            function(acc, tagName) {
              acc[tagName] = 0;
              return acc;
            },
            {}
          );
        }
        var _this$getIdAndRules = this.getIdAndRules(props), styleId = _this$getIdAndRules.styleId, rules = _this$getIdAndRules.rules;
        if (styleId in this._instancesCounts) {
          this._instancesCounts[styleId] += 1;
          return;
        }
        var indices = rules.map(function(rule) {
          return _this._sheet.insertRule(rule);
        }).filter(function(index) {
          return index !== -1;
        });
        this._indices[styleId] = indices;
        this._instancesCounts[styleId] = 1;
      };
      _proto.remove = function remove(props) {
        var _this2 = this;
        var _this$getIdAndRules2 = this.getIdAndRules(props), styleId = _this$getIdAndRules2.styleId;
        invariant(styleId in this._instancesCounts, "styleId: `" + styleId + "` not found");
        this._instancesCounts[styleId] -= 1;
        if (this._instancesCounts[styleId] < 1) {
          var tagFromServer = this._fromServer && this._fromServer[styleId];
          if (tagFromServer) {
            tagFromServer.parentNode.removeChild(tagFromServer);
            delete this._fromServer[styleId];
          } else {
            this._indices[styleId].forEach(function(index) {
              return _this2._sheet.deleteRule(index);
            });
            delete this._indices[styleId];
          }
          delete this._instancesCounts[styleId];
        }
      };
      _proto.update = function update(props, nextProps) {
        this.add(nextProps);
        this.remove(props);
      };
      _proto.flush = function flush() {
        this._sheet.flush();
        this._sheet.inject();
        this._fromServer = void 0;
        this._indices = {};
        this._instancesCounts = {};
        this.computeId = this.createComputeId();
        this.computeSelector = this.createComputeSelector();
      };
      _proto.cssRules = function cssRules() {
        var _this3 = this;
        var fromServer = this._fromServer ? Object.keys(this._fromServer).map(function(styleId) {
          return [styleId, _this3._fromServer[styleId]];
        }) : [];
        var cssRules2 = this._sheet.cssRules();
        return fromServer.concat(
          Object.keys(this._indices).map(function(styleId) {
            return [
              styleId,
              _this3._indices[styleId].map(function(index) {
                return cssRules2[index].cssText;
              }).join(_this3._optimizeForSpeed ? "" : "\n")
            ];
          }).filter(function(rule) {
            return Boolean(rule[1]);
          })
        );
      };
      _proto.createComputeId = function createComputeId() {
        var cache2 = {};
        return function(baseId, props) {
          if (!props) {
            return "jsx-" + baseId;
          }
          var propsToString = String(props);
          var key = baseId + propsToString;
          if (!cache2[key]) {
            cache2[key] = "jsx-" + (0, _stringHash["default"])(baseId + "-" + propsToString);
          }
          return cache2[key];
        };
      };
      _proto.createComputeSelector = function createComputeSelector(selectoPlaceholderRegexp) {
        if (selectoPlaceholderRegexp === void 0) {
          selectoPlaceholderRegexp = /__jsx-style-dynamic-selector/g;
        }
        var cache2 = {};
        return function(id, css) {
          if (!this._isBrowser) {
            css = sanitize(css);
          }
          var idcss = id + css;
          if (!cache2[idcss]) {
            cache2[idcss] = css.replace(selectoPlaceholderRegexp, id);
          }
          return cache2[idcss];
        };
      };
      _proto.getIdAndRules = function getIdAndRules(props) {
        var _this4 = this;
        var css = props.children, dynamic = props.dynamic, id = props.id;
        if (dynamic) {
          var styleId = this.computeId(id, dynamic);
          return {
            styleId,
            rules: Array.isArray(css) ? css.map(function(rule) {
              return _this4.computeSelector(styleId, rule);
            }) : [this.computeSelector(styleId, css)]
          };
        }
        return {
          styleId: this.computeId(id),
          rules: Array.isArray(css) ? css : [css]
        };
      };
      _proto.selectFromServer = function selectFromServer() {
        var elements = Array.prototype.slice.call(
          document.querySelectorAll('[id^="__jsx-"]')
        );
        return elements.reduce(function(acc, element) {
          var id = element.id.slice(2);
          acc[id] = element;
          return acc;
        }, {});
      };
      return StyleSheetRegistry2;
    }();
    exports2["default"] = StyleSheetRegistry;
    function invariant(condition, message) {
      if (!condition) {
        throw new Error("StyleSheetRegistry: " + message + ".");
      }
    }
  })(stylesheetRegistry);
  (function(exports2) {
    exports2.__esModule = true;
    exports2["default"] = JSXStyle;
    exports2.flush = flush;
    var _react = bn;
    var _stylesheetRegistry = _interopRequireDefault(stylesheetRegistry);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var styleSheetRegistry = new _stylesheetRegistry["default"]();
    function JSXStyle(props) {
      if (typeof window === "undefined") {
        styleSheetRegistry.add(props);
        return null;
      }
      ;
      (0, _react.useLayoutEffect)(
        function() {
          styleSheetRegistry.add(props);
          return function() {
            styleSheetRegistry.remove(props);
          };
        },
        [props.id, String(props.dynamic)]
      );
      return null;
    }
    JSXStyle.dynamic = function(info) {
      return info.map(function(tagInfo) {
        var baseId = tagInfo[0];
        var props = tagInfo[1];
        return styleSheetRegistry.computeId(baseId, props);
      }).join(" ");
    };
    function flush() {
      var cssRules = styleSheetRegistry.cssRules();
      styleSheetRegistry.flush();
      return cssRules;
    }
  })(style$1);
  var style = style$1.default || style$1;
  style.flush = style$1.flush;
  var server = {};
  (function(exports2) {
    exports2.__esModule = true;
    exports2["default"] = flushToReact;
    exports2.flushToHTML = flushToHTML2;
    var _react = _interopRequireDefault(bn);
    var _style = style$1.default || style$1;
    _style.flush = style$1.flush;
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function flushToReact(options) {
      if (options === void 0) {
        options = {};
      }
      return (0, _style.flush)().map(function(args) {
        var id = args[0];
        var css = args[1];
        return _react["default"].createElement("style", {
          id: "__" + id,
          // Avoid warnings upon render with a key
          key: "__" + id,
          nonce: options.nonce ? options.nonce : void 0,
          dangerouslySetInnerHTML: {
            __html: css
          }
        });
      });
    }
    function flushToHTML2(options) {
      if (options === void 0) {
        options = {};
      }
      return (0, _style.flush)().reduce(function(html, args) {
        var id = args[0];
        var css = args[1];
        html += '<style id="__' + id + '"' + (options.nonce ? ' nonce="' + options.nonce + '"' : "") + ">" + css + "</style>";
        return html;
      }, "");
    }
  })(server);
  var _server = server.default || server;
  _server.flushToHTML = server.flushToHTML;
  var styled_jsx_es_default = style;

  // node_modules/@geist-ui/core/esm/input/input.js
  init_react();

  // node_modules/@geist-ui/core/esm/use-theme/theme-context.js
  init_react();

  // node_modules/@babel/runtime/helpers/esm/typeof.js
  function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
      return typeof obj2;
    } : function(obj2) {
      return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
    }, _typeof(obj);
  }

  // node_modules/@geist-ui/core/esm/themes/presets/shared.js
  var defaultFont = {
    sans: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif',
    mono: "Menlo, Monaco, Lucida Console, Liberation Mono, DejaVu Sans Mono, Bitstream Vera Sans Mono, Courier New, monospace",
    prism: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,"Liberation Mono", "Courier New", monospace'
  };
  var defaultBreakpoints = {
    xs: {
      min: "0",
      max: "650px"
    },
    sm: {
      min: "650px",
      max: "900px"
    },
    md: {
      min: "900px",
      max: "1280px"
    },
    lg: {
      min: "1280px",
      max: "1920px"
    },
    xl: {
      min: "1920px",
      max: "10000px"
    }
  };
  var defaultLayout = {
    gap: "16pt",
    gapNegative: "-16pt",
    gapHalf: "8pt",
    gapHalfNegative: "-8pt",
    gapQuarter: "4pt",
    gapQuarterNegative: "-4pt",
    pageMargin: "16pt",
    pageWidth: "750pt",
    pageWidthWithMargin: "782pt",
    breakpointMobile: defaultBreakpoints.xs.max,
    breakpointTablet: defaultBreakpoints.sm.max,
    radius: "6px",
    unit: "16px"
  };

  // node_modules/@geist-ui/core/esm/themes/presets/default.js
  var palette = {
    accents_1: "#fafafa",
    accents_2: "#eaeaea",
    accents_3: "#999",
    accents_4: "#888",
    accents_5: "#666",
    accents_6: "#444",
    accents_7: "#333",
    accents_8: "#111",
    background: "#fff",
    foreground: "#000",
    selection: "#79ffe1",
    secondary: "#666",
    code: "#f81ce5",
    border: "#eaeaea",
    error: "#e00",
    errorLight: "#ff1a1a",
    errorLighter: "#f7d4d6",
    errorDark: "#c50000",
    success: "#0070f3",
    successLight: "#3291ff",
    successLighter: "#d3e5ff",
    successDark: "#0761d1",
    warning: "#f5a623",
    warningLight: "#f7b955",
    warningLighter: "#ffefcf",
    warningDark: "#ab570a",
    cyan: "#50e3c2",
    cyanLighter: "#aaffec",
    cyanLight: "#79ffe1",
    cyanDark: "#29bc9b",
    violet: "#7928ca",
    violetLighter: "#e3d7fc",
    violetLight: "#8a63d2",
    violetDark: "#4c2889",
    purple: "#f81ce5",
    alert: "#ff0080",
    magenta: "#eb367f",
    link: "#0070f3"
  };
  var expressiveness = {
    linkStyle: "none",
    linkHoverStyle: "none",
    dropdownBoxShadow: "0 4px 4px 0 rgba(0, 0, 0, 0.02)",
    scrollerStart: "rgba(255, 255, 255, 1)",
    scrollerEnd: "rgba(255, 255, 255, 0)",
    shadowSmall: "0 5px 10px rgba(0, 0, 0, 0.12)",
    shadowMedium: "0 8px 30px rgba(0, 0, 0, 0.12)",
    shadowLarge: "0 30px 60px rgba(0, 0, 0, 0.12)",
    portalOpacity: 0.25
  };
  var font = defaultFont;
  var breakpoints = defaultBreakpoints;
  var layout = defaultLayout;
  var themes = {
    type: "light",
    font,
    layout,
    palette,
    breakpoints,
    expressiveness
  };
  var default_default = themes;

  // node_modules/@geist-ui/core/esm/themes/presets/dark.js
  var palette2 = {
    accents_1: "#111",
    accents_2: "#333",
    accents_3: "#444",
    accents_4: "#666",
    accents_5: "#888",
    accents_6: "#999",
    accents_7: "#eaeaea",
    accents_8: "#fafafa",
    background: "#000",
    foreground: "#fff",
    selection: "#f81ce5",
    secondary: "#888",
    code: "#79ffe1",
    border: "#333",
    error: "#e00",
    errorLighter: "#f7d4d6",
    errorLight: "#ff1a1a",
    errorDark: "#c50000",
    success: "#0070f3",
    successLighter: "#d3e5ff",
    successLight: "#3291ff",
    successDark: "#0761d1",
    warning: "#f5a623",
    warningLighter: "#ffefcf",
    warningLight: "#f7b955",
    warningDark: "#ab570a",
    cyan: "#50e3c2",
    cyanLighter: "#aaffec",
    cyanLight: "#79ffe1",
    cyanDark: "#29bc9b",
    violet: "#7928ca",
    violetLighter: "#e3d7fc",
    violetLight: "#8a63d2",
    violetDark: "#4c2889",
    purple: "#f81ce5",
    alert: "#ff0080",
    magenta: "#eb367f",
    link: "#3291ff"
  };
  var expressiveness2 = {
    linkStyle: "none",
    linkHoverStyle: "none",
    dropdownBoxShadow: "0 0 0 1px #333",
    scrollerStart: "rgba(255, 255, 255, 1)",
    scrollerEnd: "rgba(255, 255, 255, 0)",
    shadowSmall: "0 0 0 1px #333",
    shadowMedium: "0 0 0 1px #333",
    shadowLarge: "0 0 0 1px #333",
    portalOpacity: 0.75
  };
  var font2 = defaultFont;
  var breakpoints2 = defaultBreakpoints;
  var layout2 = defaultLayout;
  var themes2 = {
    type: "dark",
    font: font2,
    layout: layout2,
    palette: palette2,
    breakpoints: breakpoints2,
    expressiveness: expressiveness2
  };
  var dark_default = themes2;

  // node_modules/@geist-ui/core/esm/themes/themes.js
  var isObject = function isObject2(target) {
    return target && _typeof(target) === "object";
  };
  var deepDuplicable = function deepDuplicable2(source, target) {
    if (!isObject(target) || !isObject(source))
      return source;
    var sourceKeys = Object.keys(source);
    var result = {};
    for (var _i = 0, _sourceKeys = sourceKeys; _i < _sourceKeys.length; _i++) {
      var key = _sourceKeys[_i];
      var sourceValue = source[key];
      var targetValue = target[key];
      if (Array.isArray(sourceValue) && Array.isArray(targetValue)) {
        result[key] = targetValue.concat(sourceValue);
      } else if (isObject(sourceValue) && isObject(targetValue)) {
        result[key] = deepDuplicable2(sourceValue, _extends({}, targetValue));
      } else if (targetValue) {
        result[key] = targetValue;
      } else {
        result[key] = sourceValue;
      }
    }
    return result;
  };
  var getPresets = function getPresets2() {
    return [default_default, dark_default];
  };
  var getPresetStaticTheme = function getPresetStaticTheme2() {
    return default_default;
  };
  var isAvailableThemeType = function isAvailableThemeType2(type) {
    if (!type)
      return false;
    var presetThemes = getPresets();
    var hasType = presetThemes.find(function(theme) {
      return theme.type === type;
    });
    return !hasType;
  };
  var isPresetTheme = function isPresetTheme2(themeOrType) {
    if (!themeOrType)
      return false;
    var isType = typeof themeOrType === "string";
    var type = isType ? themeOrType : themeOrType.type;
    return !isAvailableThemeType(type);
  };
  var hasUserCustomTheme = function hasUserCustomTheme2() {
    var themes3 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
    return !!themes3.find(function(item) {
      return isAvailableThemeType(item.type);
    });
  };
  var create = function create2(base, custom) {
    if (!isAvailableThemeType(custom.type)) {
      throw new Error("Duplicate or unavailable theme type");
    }
    return deepDuplicable(base, custom);
  };
  var createFromDark = function createFromDark2(custom) {
    return create(dark_default, custom);
  };
  var createFromLight = function createFromLight2(custom) {
    return create(default_default, custom);
  };
  var Themes = {
    isPresetTheme,
    isAvailableThemeType,
    hasUserCustomTheme,
    getPresets,
    getPresetStaticTheme,
    create,
    createFromDark,
    createFromLight
  };
  var themes_default = Themes;

  // node_modules/@geist-ui/core/esm/themes/index.js
  var themes_default2 = themes_default;

  // node_modules/@geist-ui/core/esm/use-theme/theme-context.js
  var defaultTheme = themes_default2.getPresetStaticTheme();
  var ThemeContext = /* @__PURE__ */ bn.createContext(defaultTheme);
  var useTheme = function useTheme2() {
    return bn.useContext(ThemeContext);
  };

  // node_modules/@geist-ui/core/esm/use-theme/index.js
  var use_theme_default = useTheme;

  // node_modules/@geist-ui/core/esm/input/input-label.js
  init_react();
  var InputLabel = function InputLabel2(_ref) {
    var children = _ref.children, isRight = _ref.isRight;
    var theme = use_theme_default();
    return /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["3089782703", [theme.layout.gapHalf, theme.palette.accents_4, theme.palette.accents_1, theme.layout.radius, theme.layout.radius, theme.palette.border, theme.palette.border, theme.palette.border, theme.layout.radius, theme.layout.radius, theme.palette.border]]]) + " " + ((isRight ? "right" : "") || "")
    }, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3089782703",
      dynamic: [theme.layout.gapHalf, theme.palette.accents_4, theme.palette.accents_1, theme.layout.radius, theme.layout.radius, theme.palette.border, theme.palette.border, theme.palette.border, theme.layout.radius, theme.layout.radius, theme.palette.border]
    }, "span.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;width:initial;height:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;pointer-events:none;margin:0;padding:0 ".concat(theme.layout.gapHalf, ";color:").concat(theme.palette.accents_4, ";background-color:").concat(theme.palette.accents_1, ";border-top-left-radius:").concat(theme.layout.radius, ";border-bottom-left-radius:").concat(theme.layout.radius, ";border-top:1px solid ").concat(theme.palette.border, ";border-left:1px solid ").concat(theme.palette.border, ";border-bottom:1px solid ").concat(theme.palette.border, ";font-size:inherit;line-height:1;}span.right.__jsx-style-dynamic-selector{border-top-left-radius:0;border-bottom-left-radius:0;border-top-right-radius:").concat(theme.layout.radius, ";border-bottom-right-radius:").concat(theme.layout.radius, ";border-left:0;border-right:1px solid ").concat(theme.palette.border, ";}")));
  };
  var MemoInputLabel = /* @__PURE__ */ bn.memo(InputLabel);
  var input_label_default = MemoInputLabel;

  // node_modules/@geist-ui/core/esm/input/input-block-label.js
  init_react();
  var InputBlockLabelComponent = function InputBlockLabelComponent2(_ref) {
    var children = _ref.children;
    var theme = use_theme_default();
    return /* @__PURE__ */ bn.createElement("label", {
      className: styled_jsx_es_default.dynamic([["1278828862", [theme.palette.accents_6]]])
    }, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1278828862",
      dynamic: [theme.palette.accents_6]
    }, "label.__jsx-style-dynamic-selector{display:block;font-weight:normal;color:".concat(theme.palette.accents_6, ";padding:0 0 0 1px;margin-bottom:0.5em;font-size:1em;line-height:1.5;}label.__jsx-style-dynamic-selector>*:first-child{margin-top:0;}label.__jsx-style-dynamic-selector>*:last-child{margin-bottom:0;}")));
  };
  InputBlockLabelComponent.displayName = "GeistInputBlockLabel";
  var InputBlockLabel = /* @__PURE__ */ bn.memo(InputBlockLabelComponent);
  var input_block_label_default = InputBlockLabel;

  // node_modules/@geist-ui/core/esm/input/input-icon.js
  init_react();
  var InputIconComponent = function InputIconComponent2(_ref) {
    var icon = _ref.icon, clickable = _ref.clickable, onClick = _ref.onClick;
    return /* @__PURE__ */ bn.createElement("span", {
      onClick,
      className: styled_jsx_es_default.dynamic([["4247656379", [clickable ? "pointer" : "default", clickable ? "auto" : "none"]]]) + " input-icon"
    }, icon, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "4247656379",
      dynamic: [clickable ? "pointer" : "default", clickable ? "auto" : "none"]
    }, ".input-icon.__jsx-style-dynamic-selector{box-sizing:border-box;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;width:calc(var(--input-height) - 2px);-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;height:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;margin:0;padding:0;line-height:1;position:relative;cursor:".concat(clickable ? "pointer" : "default", ";pointer-events:").concat(clickable ? "auto" : "none", ";}.input-icon.__jsx-style-dynamic-selector svg{width:calc(var(--input-height) - 2px);height:calc(var(--input-height) - 2px);-webkit-transform:scale(0.44);-ms-transform:scale(0.44);transform:scale(0.44);}")));
  };
  InputIconComponent.displayName = "GeistInputIcon";
  var InputIcon = /* @__PURE__ */ bn.memo(InputIconComponent);
  var input_icon_default = InputIcon;

  // node_modules/@geist-ui/core/esm/input/input-icon-clear.js
  init_react();

  // node_modules/@geist-ui/core/esm/use-classes/use-classes.js
  var classObjectToString = function classObjectToString2(className) {
    var keys = Object.keys(className);
    var len = keys.length;
    var str = "";
    for (var index = 0; index < len; index++) {
      var key = keys[index];
      var val = className[keys[index]];
      if (!val)
        continue;
      str = str ? "".concat(str, " ").concat(String(key)) : String(key);
    }
    return str;
  };
  var isObjectClassName = function isObjectClassName2(value) {
    return _typeof(value) === "object" && !Array.isArray(value);
  };
  var useClasses = function useClasses2() {
    var len = arguments.length;
    var classes = "";
    if (len === 0)
      return classes;
    for (var index = 0; index < len; index++) {
      var val = index < 0 || arguments.length <= index ? void 0 : arguments[index];
      if (!val)
        continue;
      if (isObjectClassName(val)) {
        classes += " ".concat(classObjectToString(val));
      } else {
        classes += " ".concat(String(val).trim());
      }
    }
    return classes.trim();
  };
  var use_classes_default = useClasses;

  // node_modules/@geist-ui/core/esm/use-classes/index.js
  var use_classes_default2 = use_classes_default;

  // node_modules/@geist-ui/core/esm/input/input-icon-clear.js
  var InputIconClear = function InputIconClear2(_ref) {
    var onClick = _ref.onClick, disabled = _ref.disabled, visible = _ref.visible;
    var theme = use_theme_default();
    var classes = use_classes_default2("clear-icon", {
      visible
    });
    var clickHandler = function clickHandler2(event) {
      event.preventDefault();
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      onClick && onClick(event);
    };
    return /* @__PURE__ */ bn.createElement("div", {
      onClick: clickHandler,
      className: styled_jsx_es_default.dynamic([["1567030211", [disabled ? "not-allowed" : "pointer", theme.palette.accents_3, disabled ? theme.palette.accents_3 : theme.palette.foreground]]]) + " " + (classes || "")
    }, /* @__PURE__ */ bn.createElement("svg", {
      viewBox: "0 0 24 24",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none",
      shapeRendering: "geometricPrecision",
      className: styled_jsx_es_default.dynamic([["1567030211", [disabled ? "not-allowed" : "pointer", theme.palette.accents_3, disabled ? theme.palette.accents_3 : theme.palette.foreground]]])
    }, /* @__PURE__ */ bn.createElement("path", {
      d: "M18 6L6 18",
      className: styled_jsx_es_default.dynamic([["1567030211", [disabled ? "not-allowed" : "pointer", theme.palette.accents_3, disabled ? theme.palette.accents_3 : theme.palette.foreground]]])
    }), /* @__PURE__ */ bn.createElement("path", {
      d: "M6 6l12 12",
      className: styled_jsx_es_default.dynamic([["1567030211", [disabled ? "not-allowed" : "pointer", theme.palette.accents_3, disabled ? theme.palette.accents_3 : theme.palette.foreground]]])
    })), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1567030211",
      dynamic: [disabled ? "not-allowed" : "pointer", theme.palette.accents_3, disabled ? theme.palette.accents_3 : theme.palette.foreground]
    }, ".clear-icon.__jsx-style-dynamic-selector{box-sizing:border-box;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;width:calc(var(--input-height) - 2px);-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;height:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;cursor:".concat(disabled ? "not-allowed" : "pointer", ";-webkit-transition:color 150ms ease 0s;transition:color 150ms ease 0s;margin:0;padding:0;color:").concat(theme.palette.accents_3, ";visibility:hidden;opacity:0;}.visible.__jsx-style-dynamic-selector{visibility:visible;opacity:1;}.clear-icon.__jsx-style-dynamic-selector:hover{color:").concat(disabled ? theme.palette.accents_3 : theme.palette.foreground, ";}svg.__jsx-style-dynamic-selector{color:currentColor;width:calc(var(--input-height) - 2px);height:calc(var(--input-height) - 2px);-webkit-transform:scale(0.44);-ms-transform:scale(0.44);transform:scale(0.44);}")));
  };
  var MemoInputIconClear = /* @__PURE__ */ bn.memo(InputIconClear);
  var input_icon_clear_default = MemoInputIconClear;

  // node_modules/@geist-ui/core/esm/input/styles.js
  var getColors = function getColors2(palette3, status) {
    var colors = {
      "default": {
        color: palette3.foreground,
        borderColor: palette3.border,
        hoverBorder: palette3.accents_5
      },
      secondary: {
        color: palette3.foreground,
        borderColor: palette3.secondary,
        hoverBorder: palette3.secondary
      },
      success: {
        color: palette3.foreground,
        borderColor: palette3.successLight,
        hoverBorder: palette3.success
      },
      warning: {
        color: palette3.foreground,
        borderColor: palette3.warningLight,
        hoverBorder: palette3.warning
      },
      error: {
        color: palette3.error,
        borderColor: palette3.error,
        hoverBorder: palette3.errorDark
      }
    };
    if (!status)
      return colors["default"];
    return colors[status];
  };

  // node_modules/@geist-ui/core/esm/input/input-props.js
  var defaultProps = {
    disabled: false,
    readOnly: false,
    clearable: false,
    iconClickable: false,
    type: "default",
    htmlType: "text",
    autoComplete: "off",
    className: "",
    placeholder: "",
    initialValue: ""
  };

  // node_modules/@geist-ui/core/esm/use-scale/with-scale.js
  init_react();

  // node_modules/@geist-ui/core/esm/use-scale/scale-context.js
  init_react();
  var ScalePropKeys = ["width", "height", "padding", "margin", "w", "h", "paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "pl", "pr", "pt", "pb", "marginLeft", "marginRight", "marginTop", "marginBottom", "ml", "mr", "mt", "mb", "px", "py", "mx", "my", "font", "unit", "scale"];
  var defaultDynamicLayoutPipe = function defaultDynamicLayoutPipe2(scale1x) {
    return "".concat(scale1x);
  };
  var defaultContext = {
    getScaleProps: function getScaleProps() {
      return void 0;
    },
    getAllScaleProps: function getAllScaleProps() {
      return {};
    },
    SCALES: {
      pl: defaultDynamicLayoutPipe,
      pr: defaultDynamicLayoutPipe,
      pb: defaultDynamicLayoutPipe,
      pt: defaultDynamicLayoutPipe,
      px: defaultDynamicLayoutPipe,
      py: defaultDynamicLayoutPipe,
      mb: defaultDynamicLayoutPipe,
      ml: defaultDynamicLayoutPipe,
      mr: defaultDynamicLayoutPipe,
      mt: defaultDynamicLayoutPipe,
      mx: defaultDynamicLayoutPipe,
      my: defaultDynamicLayoutPipe,
      width: defaultDynamicLayoutPipe,
      height: defaultDynamicLayoutPipe,
      font: defaultDynamicLayoutPipe
    },
    unit: "16px"
  };
  var ScaleContext = /* @__PURE__ */ bn.createContext(defaultContext);
  var useScale = function useScale2() {
    return bn.useContext(ScaleContext);
  };

  // node_modules/@geist-ui/core/esm/utils/collections.js
  init_react();
  var getId = function getId2() {
    return Math.random().toString(32).slice(2, 10);
  };
  var pickChild = function pickChild2(children, targetChild) {
    var target = [];
    var withoutTargetChildren = bn.Children.map(children, function(item) {
      if (!/* @__PURE__ */ bn.isValidElement(item))
        return item;
      if (item.type === targetChild) {
        target.push(item);
        return null;
      }
      return item;
    });
    var targetChildren = target.length >= 0 ? target : void 0;
    return [withoutTargetChildren, targetChildren];
  };
  var pickChildByProps = function pickChildByProps2(children, key, value) {
    var target = [];
    var isArray2 = Array.isArray(value);
    var withoutPropChildren = bn.Children.map(children, function(item) {
      if (!/* @__PURE__ */ bn.isValidElement(item))
        return null;
      if (!item.props)
        return item;
      if (isArray2) {
        if (value.includes(item.props[key])) {
          target.push(item);
          return null;
        }
        return item;
      }
      if (item.props[key] === value) {
        target.push(item);
        return null;
      }
      return item;
    });
    var targetChildren = target.length >= 0 ? target : void 0;
    return [withoutPropChildren, targetChildren];
  };
  var isGeistElement = function isGeistElement2(el) {
    if (!el)
      return false;
    if (el !== null && el !== void 0 && el.dataset && el !== null && el !== void 0 && el.dataset["geist"])
      return true;
    el.attributes.getNamedItem("data-geist");
    return !!el.attributes.getNamedItem("data-geist");
  };
  var isBrowser = function isBrowser2() {
    return Boolean(typeof window !== "undefined" && window.document && window.document.createElement);
  };
  var isCSSNumberValue = function isCSSNumberValue2(value) {
    return value !== void 0 && !Number.isNaN(+value);
  };

  // node_modules/@geist-ui/core/esm/use-scale/utils.js
  function _createForOfIteratorHelper(o4, allowArrayLike) {
    var it = typeof Symbol !== "undefined" && o4[Symbol.iterator] || o4["@@iterator"];
    if (!it) {
      if (Array.isArray(o4) || (it = _unsupportedIterableToArray2(o4)) || allowArrayLike && o4 && typeof o4.length === "number") {
        if (it)
          o4 = it;
        var i3 = 0;
        var F3 = function F4() {
        };
        return { s: F3, n: function n2() {
          if (i3 >= o4.length)
            return { done: true };
          return { done: false, value: o4[i3++] };
        }, e: function e3(_e) {
          throw _e;
        }, f: F3 };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var normalCompletion = true, didErr = false, err;
    return { s: function s3() {
      it = it.call(o4);
    }, n: function n2() {
      var step = it.next();
      normalCompletion = step.done;
      return step;
    }, e: function e3(_e2) {
      didErr = true;
      err = _e2;
    }, f: function f3() {
      try {
        if (!normalCompletion && it["return"] != null)
          it["return"]();
      } finally {
        if (didErr)
          throw err;
      }
    } };
  }
  function _unsupportedIterableToArray2(o4, minLen) {
    if (!o4)
      return;
    if (typeof o4 === "string")
      return _arrayLikeToArray2(o4, minLen);
    var n2 = Object.prototype.toString.call(o4).slice(8, -1);
    if (n2 === "Object" && o4.constructor)
      n2 = o4.constructor.name;
    if (n2 === "Map" || n2 === "Set")
      return Array.from(o4);
    if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
      return _arrayLikeToArray2(o4, minLen);
  }
  function _arrayLikeToArray2(arr, len) {
    if (len == null || len > arr.length)
      len = arr.length;
    for (var i3 = 0, arr2 = new Array(len); i3 < len; i3++) {
      arr2[i3] = arr[i3];
    }
    return arr2;
  }
  var generateGetScaleProps = function generateGetScaleProps2(props) {
    var getScaleProps2 = function getScaleProps3(keyOrKeys) {
      if (!Array.isArray(keyOrKeys))
        return props[keyOrKeys];
      var value = void 0;
      var _iterator = _createForOfIteratorHelper(keyOrKeys), _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done; ) {
          var key = _step.value;
          var currentValue = props[key];
          if (typeof currentValue !== "undefined") {
            value = currentValue;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      return value;
    };
    return getScaleProps2;
  };
  var generateGetAllScaleProps = function generateGetAllScaleProps2(props) {
    var getAllScaleProps2 = function getAllScaleProps3() {
      var scaleProps = {};
      var _iterator2 = _createForOfIteratorHelper(ScalePropKeys), _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done; ) {
          var key = _step2.value;
          var value = props[key];
          if (typeof value !== "undefined") {
            scaleProps[key] = value;
          }
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
      return scaleProps;
    };
    return getAllScaleProps2;
  };

  // node_modules/@geist-ui/core/esm/use-scale/with-scale.js
  var _excluded = ["children"];
  var _excluded2 = ["paddingLeft", "pl", "paddingRight", "pr", "paddingTop", "pt", "paddingBottom", "pb", "marginTop", "mt", "marginRight", "mr", "marginBottom", "mb", "marginLeft", "ml", "px", "py", "mx", "my", "width", "height", "font", "w", "h", "margin", "padding", "unit", "scale"];
  var reduceScaleCoefficient = function reduceScaleCoefficient2(scale) {
    if (scale === 1)
      return scale;
    var diff = Math.abs((scale - 1) / 2);
    return scale > 1 ? 1 + diff : 1 - diff;
  };
  var withScale = function withScale2(Render) {
    var ScaleFC = /* @__PURE__ */ k3(function(_ref, ref) {
      var _ref2, _ref3, _ref4, _ref5, _ref6, _ref7, _ref8, _ref9, _ref10, _ref11, _ref12, _ref13, _ref14, _ref15, _ref16, _ref17, _ref18, _ref19, _ref20, _ref21, _ref22, _ref23, _ref24, _ref25, _ref26, _ref27, _ref28, _ref29, _ref30, _ref31, _ref32, _ref33;
      var children = _ref.children, props = _objectWithoutProperties(_ref, _excluded);
      var _useTheme = use_theme_default(), layout3 = _useTheme.layout;
      var paddingLeft = props.paddingLeft, pl = props.pl, paddingRight = props.paddingRight, pr = props.pr, paddingTop = props.paddingTop, pt = props.pt, paddingBottom = props.paddingBottom, pb = props.pb, marginTop = props.marginTop, mt = props.mt, marginRight = props.marginRight, mr = props.mr, marginBottom = props.marginBottom, mb = props.mb, marginLeft = props.marginLeft, ml = props.ml, px = props.px, py = props.py, mx = props.mx, my = props.my, width = props.width, height = props.height, font3 = props.font, w4 = props.w, h3 = props.h, margin = props.margin, padding = props.padding, _props$unit = props.unit, unit = _props$unit === void 0 ? layout3.unit : _props$unit, _props$scale = props.scale, scale = _props$scale === void 0 ? 1 : _props$scale, innerProps = _objectWithoutProperties(props, _excluded2);
      var makeScaleHandler = function makeScaleHandler2(attrValue) {
        return function(scale1x, defaultValue) {
          if (scale1x === 0) {
            scale1x = 1;
            defaultValue = defaultValue || 0;
          }
          var factor = reduceScaleCoefficient(scale) * scale1x;
          if (typeof attrValue === "undefined") {
            if (typeof defaultValue !== "undefined")
              return "".concat(defaultValue);
            return "calc(".concat(factor, " * ").concat(unit, ")");
          }
          if (!isCSSNumberValue(attrValue))
            return "".concat(attrValue);
          var customFactor = factor * Number(attrValue);
          return "calc(".concat(customFactor, " * ").concat(unit, ")");
        };
      };
      var value = {
        unit,
        SCALES: {
          pt: makeScaleHandler((_ref2 = (_ref3 = paddingTop !== null && paddingTop !== void 0 ? paddingTop : pt) !== null && _ref3 !== void 0 ? _ref3 : py) !== null && _ref2 !== void 0 ? _ref2 : padding),
          pr: makeScaleHandler((_ref4 = (_ref5 = paddingRight !== null && paddingRight !== void 0 ? paddingRight : pr) !== null && _ref5 !== void 0 ? _ref5 : px) !== null && _ref4 !== void 0 ? _ref4 : padding),
          pb: makeScaleHandler((_ref6 = (_ref7 = paddingBottom !== null && paddingBottom !== void 0 ? paddingBottom : pb) !== null && _ref7 !== void 0 ? _ref7 : py) !== null && _ref6 !== void 0 ? _ref6 : padding),
          pl: makeScaleHandler((_ref8 = (_ref9 = paddingLeft !== null && paddingLeft !== void 0 ? paddingLeft : pl) !== null && _ref9 !== void 0 ? _ref9 : px) !== null && _ref8 !== void 0 ? _ref8 : padding),
          px: makeScaleHandler((_ref10 = (_ref11 = (_ref12 = (_ref13 = px !== null && px !== void 0 ? px : paddingLeft) !== null && _ref13 !== void 0 ? _ref13 : paddingRight) !== null && _ref12 !== void 0 ? _ref12 : pl) !== null && _ref11 !== void 0 ? _ref11 : pr) !== null && _ref10 !== void 0 ? _ref10 : padding),
          py: makeScaleHandler((_ref14 = (_ref15 = (_ref16 = (_ref17 = py !== null && py !== void 0 ? py : paddingTop) !== null && _ref17 !== void 0 ? _ref17 : paddingBottom) !== null && _ref16 !== void 0 ? _ref16 : pt) !== null && _ref15 !== void 0 ? _ref15 : pb) !== null && _ref14 !== void 0 ? _ref14 : padding),
          mt: makeScaleHandler((_ref18 = (_ref19 = marginTop !== null && marginTop !== void 0 ? marginTop : mt) !== null && _ref19 !== void 0 ? _ref19 : my) !== null && _ref18 !== void 0 ? _ref18 : margin),
          mr: makeScaleHandler((_ref20 = (_ref21 = marginRight !== null && marginRight !== void 0 ? marginRight : mr) !== null && _ref21 !== void 0 ? _ref21 : mx) !== null && _ref20 !== void 0 ? _ref20 : margin),
          mb: makeScaleHandler((_ref22 = (_ref23 = marginBottom !== null && marginBottom !== void 0 ? marginBottom : mb) !== null && _ref23 !== void 0 ? _ref23 : my) !== null && _ref22 !== void 0 ? _ref22 : margin),
          ml: makeScaleHandler((_ref24 = (_ref25 = marginLeft !== null && marginLeft !== void 0 ? marginLeft : ml) !== null && _ref25 !== void 0 ? _ref25 : mx) !== null && _ref24 !== void 0 ? _ref24 : margin),
          mx: makeScaleHandler((_ref26 = (_ref27 = (_ref28 = (_ref29 = mx !== null && mx !== void 0 ? mx : marginLeft) !== null && _ref29 !== void 0 ? _ref29 : marginRight) !== null && _ref28 !== void 0 ? _ref28 : ml) !== null && _ref27 !== void 0 ? _ref27 : mr) !== null && _ref26 !== void 0 ? _ref26 : margin),
          my: makeScaleHandler((_ref30 = (_ref31 = (_ref32 = (_ref33 = my !== null && my !== void 0 ? my : marginTop) !== null && _ref33 !== void 0 ? _ref33 : marginBottom) !== null && _ref32 !== void 0 ? _ref32 : mt) !== null && _ref31 !== void 0 ? _ref31 : mb) !== null && _ref30 !== void 0 ? _ref30 : margin),
          width: makeScaleHandler(width !== null && width !== void 0 ? width : w4),
          height: makeScaleHandler(height !== null && height !== void 0 ? height : h3),
          font: makeScaleHandler(font3)
        },
        getScaleProps: generateGetScaleProps(props),
        getAllScaleProps: generateGetAllScaleProps(props)
      };
      return /* @__PURE__ */ bn.createElement(ScaleContext.Provider, {
        value
      }, /* @__PURE__ */ bn.createElement(Render, _extends({}, innerProps, {
        ref
      }), children));
    });
    ScaleFC.displayName = "Scale".concat(Render.displayName || "Wrapper");
    return ScaleFC;
  };
  var with_scale_default = withScale;

  // node_modules/@geist-ui/core/esm/use-scale/index.js
  var use_scale_default = useScale;

  // node_modules/@geist-ui/core/esm/input/input.js
  var _excluded3 = ["label", "labelRight", "type", "htmlType", "icon", "iconRight", "iconClickable", "onIconClick", "initialValue", "onChange", "readOnly", "value", "onClearClick", "clearable", "className", "onBlur", "onFocus", "autoComplete", "placeholder", "children", "disabled"];
  var simulateChangeEvent = function simulateChangeEvent2(el, event) {
    return _extends({}, event, {
      target: el,
      currentTarget: el
    });
  };
  var InputComponent = /* @__PURE__ */ bn.forwardRef(function(_ref, ref) {
    var label = _ref.label, labelRight = _ref.labelRight, type = _ref.type, htmlType = _ref.htmlType, icon = _ref.icon, iconRight = _ref.iconRight, iconClickable = _ref.iconClickable, onIconClick = _ref.onIconClick, initialValue = _ref.initialValue, onChange = _ref.onChange, readOnly = _ref.readOnly, value = _ref.value, onClearClick = _ref.onClearClick, clearable = _ref.clearable, className = _ref.className, onBlur = _ref.onBlur, onFocus = _ref.onFocus, autoComplete = _ref.autoComplete, placeholder = _ref.placeholder, children = _ref.children, disabled = _ref.disabled, props = _objectWithoutProperties(_ref, _excluded3);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var inputRef = _2(null);
    A2(ref, function() {
      return inputRef.current;
    });
    var _useState = p2(initialValue), _useState2 = _slicedToArray(_useState, 2), selfValue = _useState2[0], setSelfValue = _useState2[1];
    var _useState3 = p2(false), _useState4 = _slicedToArray(_useState3, 2), hover = _useState4[0], setHover = _useState4[1];
    var isControlledComponent = F(function() {
      return value !== void 0;
    }, [value]);
    var labelClasses = F(function() {
      return labelRight ? "right-label" : label ? "left-label" : "";
    }, [label, labelRight]);
    var iconClasses = F(function() {
      return iconRight ? "right-icon" : icon ? "left-icon" : "";
    }, [icon, iconRight]);
    var _useMemo = F(function() {
      return getColors(theme.palette, type);
    }, [theme.palette, type]), color = _useMemo.color, borderColor = _useMemo.borderColor, hoverBorder = _useMemo.hoverBorder;
    var changeHandler = function changeHandler2(event) {
      if (disabled || readOnly)
        return;
      setSelfValue(event.target.value);
      onChange && onChange(event);
    };
    var clearHandler = function clearHandler2(event) {
      setSelfValue("");
      onClearClick && onClearClick(event);
      if (!inputRef.current)
        return;
      var changeEvent = simulateChangeEvent(inputRef.current, event);
      changeEvent.target.value = "";
      onChange && onChange(changeEvent);
      inputRef.current.focus();
    };
    var focusHandler = function focusHandler2(e3) {
      setHover(true);
      onFocus && onFocus(e3);
    };
    var blurHandler = function blurHandler2(e3) {
      setHover(false);
      onBlur && onBlur(e3);
    };
    var iconClickHandler = function iconClickHandler2(e3) {
      if (disabled)
        return;
      onIconClick && onIconClick(e3);
    };
    var iconProps = F(function() {
      return {
        clickable: iconClickable,
        onClick: iconClickHandler
      };
    }, [iconClickable, iconClickHandler]);
    h2(function() {
      if (isControlledComponent) {
        setSelfValue(value);
      }
    });
    var controlledValue = isControlledComponent ? {
      value: selfValue
    } : {
      defaultValue: initialValue
    };
    var inputProps = _extends({}, props, controlledValue);
    return /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["575189429", [SCALES.height(2.25), SCALES.font(0.875), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.width(1, "initial"), theme.layout.radius, borderColor, theme.palette.accents_1, theme.palette.accents_2, hoverBorder, SCALES.font(0.875), color, theme.palette.accents_3, theme.palette.background, color]]]) + " with-label"
    }, children && /* @__PURE__ */ bn.createElement(input_block_label_default, null, children), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["575189429", [SCALES.height(2.25), SCALES.font(0.875), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.width(1, "initial"), theme.layout.radius, borderColor, theme.palette.accents_1, theme.palette.accents_2, hoverBorder, SCALES.font(0.875), color, theme.palette.accents_3, theme.palette.background, color]]]) + " " + (use_classes_default2("input-container", className) || "")
    }, label && /* @__PURE__ */ bn.createElement(input_label_default, null, label), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["575189429", [SCALES.height(2.25), SCALES.font(0.875), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.width(1, "initial"), theme.layout.radius, borderColor, theme.palette.accents_1, theme.palette.accents_2, hoverBorder, SCALES.font(0.875), color, theme.palette.accents_3, theme.palette.background, color]]]) + " " + (use_classes_default2("input-wrapper", {
        hover,
        disabled
      }, labelClasses) || "")
    }, icon && /* @__PURE__ */ bn.createElement(input_icon_default, _extends({
      icon
    }, iconProps)), /* @__PURE__ */ bn.createElement("input", _extends({
      type: htmlType,
      ref: inputRef,
      placeholder,
      disabled,
      readOnly,
      onFocus: focusHandler,
      onBlur: blurHandler,
      onChange: changeHandler,
      autoComplete
    }, inputProps, {
      className: styled_jsx_es_default.dynamic([["575189429", [SCALES.height(2.25), SCALES.font(0.875), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.width(1, "initial"), theme.layout.radius, borderColor, theme.palette.accents_1, theme.palette.accents_2, hoverBorder, SCALES.font(0.875), color, theme.palette.accents_3, theme.palette.background, color]]]) + " " + (inputProps && inputProps.className != null && inputProps.className || use_classes_default2({
        disabled
      }, iconClasses) || "")
    })), clearable && /* @__PURE__ */ bn.createElement(input_icon_clear_default, {
      visible: Boolean(inputRef.current && inputRef.current.value !== ""),
      disabled: disabled || readOnly,
      onClick: clearHandler
    }), iconRight && /* @__PURE__ */ bn.createElement(input_icon_default, _extends({
      icon: iconRight
    }, iconProps))), labelRight && /* @__PURE__ */ bn.createElement(input_label_default, {
      isRight: true
    }, labelRight)), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "575189429",
      dynamic: [SCALES.height(2.25), SCALES.font(0.875), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.width(1, "initial"), theme.layout.radius, borderColor, theme.palette.accents_1, theme.palette.accents_2, hoverBorder, SCALES.font(0.875), color, theme.palette.accents_3, theme.palette.background, color]
    }, ".with-label.__jsx-style-dynamic-selector{display:inline-block;box-sizing:border-box;-webkit-box-align:center;--input-height:".concat(SCALES.height(2.25), ";font-size:").concat(SCALES.font(0.875), ";width:").concat(SCALES.width(1, "initial"), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.input-container.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:").concat(SCALES.width(1, "initial"), ";height:var(--input-height);}.input-wrapper.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;vertical-align:middle;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:100%;-webkit-flex:1;-ms-flex:1;flex:1;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-radius:").concat(theme.layout.radius, ";border:1px solid ").concat(borderColor, ";-webkit-transition:border 0.2s ease 0s,color 0.2s ease 0s;transition:border 0.2s ease 0s,color 0.2s ease 0s;}.input-wrapper.left-label.__jsx-style-dynamic-selector{border-top-left-radius:0;border-bottom-left-radius:0;}.input-wrapper.right-label.__jsx-style-dynamic-selector{border-top-right-radius:0;border-bottom-right-radius:0;}.input-wrapper.disabled.__jsx-style-dynamic-selector{background-color:").concat(theme.palette.accents_1, ";border-color:").concat(theme.palette.accents_2, ";cursor:not-allowed;}input.disabled.__jsx-style-dynamic-selector{cursor:not-allowed;}.input-wrapper.hover.__jsx-style-dynamic-selector{border-color:").concat(hoverBorder, ";}input.__jsx-style-dynamic-selector{margin:0.25em 0.625em;padding:0;box-shadow:none;font-size:").concat(SCALES.font(0.875), ";background-color:transparent;border:none;color:").concat(color, ";outline:none;border-radius:0;width:100%;min-width:0;-webkit-appearance:none;}input.left-icon.__jsx-style-dynamic-selector{margin-left:0;}input.right-icon.__jsx-style-dynamic-selector{margin-right:0;}.__jsx-style-dynamic-selector::-webkit-input-placeholder,.__jsx-style-dynamic-selector::-moz-placeholder,.__jsx-style-dynamic-selector:-ms-input-placeholder,.__jsx-style-dynamic-selector::-webkit-input-placeholder{color:").concat(theme.palette.accents_3, ";}.__jsx-style-dynamic-selector::-moz-placeholder,.__jsx-style-dynamic-selector::-moz-placeholder,.__jsx-style-dynamic-selector:-ms-input-placeholder,.__jsx-style-dynamic-selector::-webkit-input-placeholder{color:").concat(theme.palette.accents_3, ";}.__jsx-style-dynamic-selector:-ms-input-placeholder,.__jsx-style-dynamic-selector::-moz-placeholder,.__jsx-style-dynamic-selector:-ms-input-placeholder,.__jsx-style-dynamic-selector::-webkit-input-placeholder{color:").concat(theme.palette.accents_3, ";}.__jsx-style-dynamic-selector::placeholder,.__jsx-style-dynamic-selector::-moz-placeholder,.__jsx-style-dynamic-selector:-ms-input-placeholder,.__jsx-style-dynamic-selector::-webkit-input-placeholder{color:").concat(theme.palette.accents_3, ";}.__jsx-style-dynamic-selector::-ms-reveal{display:none !important;}input.__jsx-style-dynamic-selector:-webkit-autofill,input.__jsx-style-dynamic-selector:-webkit-autofill.__jsx-style-dynamic-selector:hover,input.__jsx-style-dynamic-selector:-webkit-autofill.__jsx-style-dynamic-selector:active,input.__jsx-style-dynamic-selector:-webkit-autofill.__jsx-style-dynamic-selector:focus{-webkit-box-shadow:0 0 0 30px ").concat(theme.palette.background, " inset !important;-webkit-text-fill-color:").concat(color, " !important;}")));
  });
  InputComponent.defaultProps = defaultProps;
  InputComponent.displayName = "GeistInput";
  var Input = with_scale_default(InputComponent);
  var input_default = Input;

  // node_modules/@geist-ui/core/esm/textarea/textarea.js
  init_react();

  // node_modules/@geist-ui/core/esm/utils/prop-types.js
  var tuple = function tuple2() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return args;
  };
  var buttonTypes = tuple("default", "secondary", "success", "warning", "error", "abort", "secondary-light", "success-light", "warning-light", "error-light");
  var normalTypes = tuple("default", "secondary", "success", "warning", "error");
  var snippetTypes = tuple("default", "secondary", "success", "warning", "error", "dark", "lite");
  var cardTypes = tuple("default", "secondary", "success", "warning", "error", "dark", "lite", "alert", "purple", "violet", "cyan");
  var copyTypes = tuple("default", "silent", "prevent");
  var triggerTypes = tuple("hover", "click");
  var placement = tuple("top", "topStart", "topEnd", "left", "leftStart", "leftEnd", "bottom", "bottomStart", "bottomEnd", "right", "rightStart", "rightEnd");
  var dividerAlign = tuple("start", "center", "end", "left", "right");

  // node_modules/@geist-ui/core/esm/textarea/textarea.js
  var _excluded4 = ["type", "disabled", "readOnly", "onFocus", "onBlur", "className", "initialValue", "onChange", "value", "placeholder", "resize"];
  var resizeTypes = tuple("none", "both", "horizontal", "vertical", "initial", "inherit");
  var defaultProps2 = {
    initialValue: "",
    type: "default",
    disabled: false,
    readOnly: false,
    className: "",
    resize: "none"
  };
  var TextareaComponent = /* @__PURE__ */ bn.forwardRef(function(_ref, ref) {
    var type = _ref.type, disabled = _ref.disabled, readOnly = _ref.readOnly, onFocus = _ref.onFocus, onBlur = _ref.onBlur, className = _ref.className, initialValue = _ref.initialValue, onChange = _ref.onChange, value = _ref.value, placeholder = _ref.placeholder, resize = _ref.resize, props = _objectWithoutProperties(_ref, _excluded4);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var textareaRef = _2(null);
    A2(ref, function() {
      return textareaRef.current;
    });
    var isControlledComponent = F(function() {
      return value !== void 0;
    }, [value]);
    var _useState = p2(initialValue), _useState2 = _slicedToArray(_useState, 2), selfValue = _useState2[0], setSelfValue = _useState2[1];
    var _useState3 = p2(false), _useState4 = _slicedToArray(_useState3, 2), hover = _useState4[0], setHover = _useState4[1];
    var _useMemo = F(function() {
      return getColors(theme.palette, type);
    }, [theme.palette, type]), color = _useMemo.color, borderColor = _useMemo.borderColor, hoverBorder = _useMemo.hoverBorder;
    var classes = use_classes_default2("wrapper", {
      hover,
      disabled
    }, className);
    var changeHandler = function changeHandler2(event) {
      if (disabled || readOnly)
        return;
      setSelfValue(event.target.value);
      onChange && onChange(event);
    };
    var focusHandler = function focusHandler2(e3) {
      setHover(true);
      onFocus && onFocus(e3);
    };
    var blurHandler = function blurHandler2(e3) {
      setHover(false);
      onBlur && onBlur(e3);
    };
    h2(function() {
      if (isControlledComponent) {
        setSelfValue(value);
      }
    });
    var controlledValue = isControlledComponent ? {
      value: selfValue
    } : {
      defaultValue: initialValue
    };
    var textareaProps = _extends({}, props, controlledValue);
    return /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["12276481", [theme.layout.radius, borderColor, color, SCALES.font(0.875), SCALES.height(1, "auto"), SCALES.width(1, "initial"), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hoverBorder, theme.palette.accents_1, theme.palette.accents_2, theme.font.sans, SCALES.pt(0.5), SCALES.pr(0.5), SCALES.pb(0.5), SCALES.pl(0.5), resize, theme.palette.background]]]) + " " + (classes || "")
    }, /* @__PURE__ */ bn.createElement("textarea", _extends({
      ref: textareaRef,
      disabled,
      placeholder,
      readOnly,
      onFocus: focusHandler,
      onBlur: blurHandler,
      onChange: changeHandler
    }, textareaProps, {
      className: styled_jsx_es_default.dynamic([["12276481", [theme.layout.radius, borderColor, color, SCALES.font(0.875), SCALES.height(1, "auto"), SCALES.width(1, "initial"), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hoverBorder, theme.palette.accents_1, theme.palette.accents_2, theme.font.sans, SCALES.pt(0.5), SCALES.pr(0.5), SCALES.pb(0.5), SCALES.pl(0.5), resize, theme.palette.background]]]) + " " + (textareaProps && textareaProps.className != null && textareaProps.className || "")
    })), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "12276481",
      dynamic: [theme.layout.radius, borderColor, color, SCALES.font(0.875), SCALES.height(1, "auto"), SCALES.width(1, "initial"), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hoverBorder, theme.palette.accents_1, theme.palette.accents_2, theme.font.sans, SCALES.pt(0.5), SCALES.pr(0.5), SCALES.pb(0.5), SCALES.pl(0.5), resize, theme.palette.background]
    }, ".wrapper.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-radius:".concat(theme.layout.radius, ";border:1px solid ").concat(borderColor, ";color:").concat(color, ";-webkit-transition:border 0.2s ease 0s,color 0.2s ease 0s;transition:border 0.2s ease 0s,color 0.2s ease 0s;min-width:12.5rem;max-width:95vw;--textarea-font-size:").concat(SCALES.font(0.875), ";--textarea-height:").concat(SCALES.height(1, "auto"), ";width:").concat(SCALES.width(1, "initial"), ";height:var(--textarea-height);margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.wrapper.hover.__jsx-style-dynamic-selector{border-color:").concat(hoverBorder, ";}.wrapper.disabled.__jsx-style-dynamic-selector{background-color:").concat(theme.palette.accents_1, ";border-color:").concat(theme.palette.accents_2, ";cursor:not-allowed;}textarea.__jsx-style-dynamic-selector{background-color:transparent;box-shadow:none;display:block;font-family:").concat(theme.font.sans, ";font-size:var(--textarea-font-size);width:100%;height:var(--textarea-height);border:none;outline:none;padding:").concat(SCALES.pt(0.5), " ").concat(SCALES.pr(0.5), " ").concat(SCALES.pb(0.5), " ").concat(SCALES.pl(0.5), ";resize:").concat(resize, ";}.disabled.__jsx-style-dynamic-selector>textarea.__jsx-style-dynamic-selector{cursor:not-allowed;}textarea.__jsx-style-dynamic-selector:-webkit-autofill,textarea.__jsx-style-dynamic-selector:-webkit-autofill.__jsx-style-dynamic-selector:hover,textarea.__jsx-style-dynamic-selector:-webkit-autofill.__jsx-style-dynamic-selector:active,textarea.__jsx-style-dynamic-selector:-webkit-autofill.__jsx-style-dynamic-selector:focus{-webkit-box-shadow:0 0 0 30px ").concat(theme.palette.background, " inset !important;}")));
  });
  TextareaComponent.defaultProps = defaultProps2;
  TextareaComponent.displayName = "GeistTextarea";
  var Textarea = with_scale_default(TextareaComponent);
  var textarea_default = Textarea;

  // node_modules/@geist-ui/core/esm/textarea/index.js
  var textarea_default2 = textarea_default;

  // node_modules/@geist-ui/core/esm/input/password.js
  init_react();

  // node_modules/@geist-ui/core/esm/input/password-icon.js
  init_react();
  var PasswordIcon = function PasswordIcon2(_ref) {
    var visible = _ref.visible;
    return /* @__PURE__ */ bn.createElement("svg", {
      viewBox: "0 0 24 24",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none",
      shapeRendering: "geometricPrecision",
      style: {
        color: "currentColor"
      }
    }, !visible ? /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement("path", {
      d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"
    }), /* @__PURE__ */ bn.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "3"
    })) : /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement("path", {
      d: "M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"
    }), /* @__PURE__ */ bn.createElement("path", {
      d: "M1 1l22 22"
    })));
  };
  var MemoPasswordIcon = /* @__PURE__ */ bn.memo(PasswordIcon);
  var password_icon_default = MemoPasswordIcon;

  // node_modules/@geist-ui/core/esm/input/password.js
  var _excluded5 = ["hideToggle", "children"];
  var passwordDefaultProps = _extends({}, defaultProps, {
    hideToggle: false
  });
  var InputPasswordComponent = /* @__PURE__ */ bn.forwardRef(function(_ref, ref) {
    var hideToggle = _ref.hideToggle, children = _ref.children, props = _objectWithoutProperties(_ref, _excluded5);
    var _useScale = useScale(), getAllScaleProps2 = _useScale.getAllScaleProps;
    var inputRef = _2(null);
    var _useState = p2(false), _useState2 = _slicedToArray(_useState, 2), visible = _useState2[0], setVisible = _useState2[1];
    A2(ref, function() {
      return inputRef.current;
    });
    var iconClickHandler = function iconClickHandler2() {
      setVisible(function(v3) {
        return !v3;
      });
      if (inputRef && inputRef.current) {
        inputRef.current.focus();
      }
    };
    var inputProps = F(function() {
      return _extends({}, props, {
        ref: inputRef,
        iconClickable: true,
        onIconClick: iconClickHandler,
        htmlType: visible ? "text" : "password"
      });
    }, [props, iconClickHandler, visible, inputRef]);
    var icon = F(function() {
      if (hideToggle)
        return null;
      return /* @__PURE__ */ bn.createElement(password_icon_default, {
        visible
      });
    }, [hideToggle, visible]);
    return /* @__PURE__ */ bn.createElement(input_default, _extends({
      iconRight: icon
    }, getAllScaleProps2(), inputProps), children);
  });
  InputPasswordComponent.defaultProps = passwordDefaultProps;
  InputPasswordComponent.displayName = "GeistInputPassword";
  var InputPassword = with_scale_default(InputPasswordComponent);
  var password_default = InputPassword;

  // node_modules/@geist-ui/core/esm/input/index.js
  input_default.Textarea = textarea_default2;
  input_default.Password = password_default;
  var input_default2 = input_default;

  // node_modules/@geist-ui/core/esm/shared/ellipsis.js
  init_react();
  var Ellipsis = function Ellipsis2(_ref) {
    var children = _ref.children, height = _ref.height;
    return /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["822089635", [height]]])
    }, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "822089635",
      dynamic: [height]
    }, "span.__jsx-style-dynamic-selector{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:".concat(height, ";min-width:0;}")));
  };
  var ellipsis_default = /* @__PURE__ */ bn.memo(Ellipsis);

  // node_modules/@geist-ui/core/esm/shared/dropdown.js
  init_react();

  // node_modules/react-dom/index.mjs
  init_compat_module();
  init_compat_module();

  // node_modules/@geist-ui/core/esm/utils/use-portal.js
  init_react();

  // node_modules/@geist-ui/core/esm/utils/use-ssr.js
  init_react();
  var useSSR = function useSSR2() {
    var _useState = p2(false), _useState2 = _slicedToArray(_useState, 2), browser = _useState2[0], setBrowser = _useState2[1];
    h2(function() {
      setBrowser(isBrowser());
    }, []);
    return {
      isBrowser: browser,
      isServer: !browser
    };
  };
  var use_ssr_default = useSSR;

  // node_modules/@geist-ui/core/esm/utils/use-portal.js
  var createElement = function createElement2(id) {
    var el = document.createElement("div");
    el.setAttribute("id", id);
    return el;
  };
  var usePortal = function usePortal2() {
    var selectId = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getId();
    var getContainer = arguments.length > 1 ? arguments[1] : void 0;
    var id = "geist-ui-".concat(selectId);
    var _useSSR = use_ssr_default(), isBrowser3 = _useSSR.isBrowser;
    var _useState = p2(isBrowser3 ? createElement(id) : null), _useState2 = _slicedToArray(_useState, 2), elSnapshot = _useState2[0], setElSnapshot = _useState2[1];
    h2(function() {
      var customContainer = getContainer ? getContainer() : null;
      var parentElement = customContainer || document.body;
      var hasElement = parentElement.querySelector("#".concat(id));
      var el = hasElement || createElement(id);
      if (!hasElement) {
        parentElement.appendChild(el);
      }
      setElSnapshot(el);
    }, []);
    return elSnapshot;
  };
  var use_portal_default = usePortal;

  // node_modules/@geist-ui/core/esm/utils/use-resize.js
  init_react();
  var useResize = function useResize2(callback) {
    var immediatelyInvoke = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
    h2(function() {
      var fn2 = function fn3() {
        return callback();
      };
      if (immediatelyInvoke) {
        fn2();
      }
      window.addEventListener("resize", fn2);
      return function() {
        return window.removeEventListener("resize", fn2);
      };
    }, []);
  };
  var use_resize_default = useResize;

  // node_modules/@geist-ui/core/esm/shared/css-transition.js
  init_react();
  var _excluded6 = ["children", "className", "visible", "enterTime", "leaveTime", "clearTime", "name"];
  var defaultProps3 = {
    visible: false,
    enterTime: 60,
    leaveTime: 60,
    clearTime: 60,
    className: "",
    name: "transition"
  };
  var CssTransition = function CssTransition2(_ref) {
    var children = _ref.children, className = _ref.className, visible = _ref.visible, enterTime = _ref.enterTime, leaveTime = _ref.leaveTime, clearTime = _ref.clearTime, name = _ref.name, props = _objectWithoutProperties(_ref, _excluded6);
    var _useState = p2(""), _useState2 = _slicedToArray(_useState, 2), classes = _useState2[0], setClasses = _useState2[1];
    var _useState3 = p2(visible), _useState4 = _slicedToArray(_useState3, 2), renderable = _useState4[0], setRenderable = _useState4[1];
    h2(function() {
      var statusClassName = visible ? "enter" : "leave";
      var time = visible ? enterTime : leaveTime;
      if (visible && !renderable) {
        setRenderable(true);
      }
      setClasses("".concat(name, "-").concat(statusClassName));
      var timer = setTimeout(function() {
        setClasses("".concat(name, "-").concat(statusClassName, " ").concat(name, "-").concat(statusClassName, "-active"));
        clearTimeout(timer);
      }, time);
      var clearClassesTimer = setTimeout(function() {
        if (!visible) {
          setClasses("");
          setRenderable(false);
        }
        clearTimeout(clearClassesTimer);
      }, time + clearTime);
      return function() {
        clearTimeout(timer);
        clearTimeout(clearClassesTimer);
      };
    }, [visible, renderable]);
    if (!/* @__PURE__ */ bn.isValidElement(children) || !renderable)
      return null;
    return /* @__PURE__ */ bn.cloneElement(children, _extends({}, props, {
      className: "".concat(children.props.className, " ").concat(className, " ").concat(classes)
    }));
  };
  CssTransition.defaultProps = defaultProps3;
  CssTransition.displayName = "GeistCssTransition";
  var css_transition_default = CssTransition;

  // node_modules/@geist-ui/core/esm/utils/use-click-anywhere.js
  init_react();
  var useClickAnyWhere = function useClickAnyWhere2(handler) {
    h2(function() {
      var callback = function callback2(event) {
        return handler(event);
      };
      document.addEventListener("click", callback);
      return function() {
        return document.removeEventListener("click", callback);
      };
    }, [handler]);
  };
  var use_click_anywhere_default = useClickAnyWhere;

  // node_modules/@geist-ui/core/esm/utils/use-dom-observer.js
  init_react();
  var useDOMObserver = function useDOMObserver2(ref) {
    var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : function() {
    };
    var config = {
      attributes: false,
      childList: true,
      subtree: true
    };
    h2(function() {
      if (!ref || !ref.current)
        return;
      var unmount = false;
      var done = function done2() {
        if (unmount)
          return;
        callback.apply(void 0, arguments);
      };
      var observer = new MutationObserver(done);
      observer.observe(ref.current, config);
      return function() {
        unmount = true;
        observer.disconnect();
      };
    }, [ref]);
  };
  var use_dom_observer_default = useDOMObserver;

  // node_modules/@geist-ui/core/esm/utils/use-warning.js
  var warningStack = {};
  var useWarning = function useWarning2(message, component) {
    var tag = component ? " [".concat(component, "]") : " ";
    var log = "[Geist UI]".concat(tag, ": ").concat(message);
    if (typeof console === "undefined")
      return;
    if (warningStack[log])
      return;
    warningStack[log] = true;
    if (false) {
      return console.error(log);
    }
    console.warn(log);
  };
  var use_warning_default = useWarning;

  // node_modules/@geist-ui/core/esm/utils/layouts.js
  init_react();
  var getElementOffset = function getElementOffset2(el) {
    if (!el)
      return {
        top: 0,
        left: 0
      };
    var _el$getBoundingClient = el.getBoundingClientRect(), top = _el$getBoundingClient.top, left = _el$getBoundingClient.left;
    return {
      top,
      left
    };
  };
  var defaultRect = {
    top: -1e3,
    left: -1e3,
    right: -1e3,
    width: 0,
    height: 0,
    elementTop: -1e3
  };
  var getRectFromDOMWithContainer = function getRectFromDOMWithContainer2(domRect, getContainer) {
    if (!domRect)
      return defaultRect;
    var container = getContainer ? getContainer() : null;
    var scrollElement = container || document.documentElement;
    var _getElementOffset = getElementOffset(container), offsetTop = _getElementOffset.top, offsetLeft = _getElementOffset.left;
    return _extends({}, domRect, {
      width: domRect.width || domRect.right - domRect.left,
      height: domRect.height || domRect.top - domRect.bottom,
      top: domRect.bottom + scrollElement.scrollTop - offsetTop,
      left: domRect.left + scrollElement.scrollLeft - offsetLeft,
      elementTop: domRect.top + scrollElement.scrollTop - offsetTop
    });
  };
  var isUnplacedRect = function isUnplacedRect2(rect) {
    if (!rect)
      return true;
    return rect.top === defaultRect.top && rect.left === defaultRect.left;
  };
  var getRefRect = function getRefRect2(ref, getContainer) {
    if (!ref || !ref.current)
      return defaultRect;
    var rect = ref.current.getBoundingClientRect();
    return getRectFromDOMWithContainer(rect, getContainer);
  };
  var getEventRect = function getEventRect2(event, getContainer) {
    var _event$target;
    var rect = event === null || event === void 0 ? void 0 : (_event$target = event.target) === null || _event$target === void 0 ? void 0 : _event$target.getBoundingClientRect();
    if (!rect)
      return defaultRect;
    return getRectFromDOMWithContainer(rect, getContainer);
  };
  var isRefTarget = function isRefTarget2(eventOrRef) {
    return typeof (eventOrRef === null || eventOrRef === void 0 ? void 0 : eventOrRef.target) === "undefined";
  };
  var useRect = function useRect2(initialState) {
    var _useState = p2(initialState || defaultRect), _useState2 = _slicedToArray(_useState, 2), rect = _useState2[0], setRect = _useState2[1];
    var updateRect = function updateRect2(eventOrRef, getContainer) {
      if (isRefTarget(eventOrRef))
        return setRect(getRefRect(eventOrRef, getContainer));
      setRect(getEventRect(eventOrRef, getContainer));
    };
    return {
      rect,
      setRect: updateRect
    };
  };

  // node_modules/@geist-ui/core/esm/shared/dropdown.js
  var defaultRect2 = {
    top: -1e3,
    left: -1e3,
    right: -1e3,
    width: 0
  };
  var Dropdown = /* @__PURE__ */ bn.memo(function(_ref) {
    var children = _ref.children, parent = _ref.parent, visible = _ref.visible, disableMatchWidth = _ref.disableMatchWidth, getPopupContainer = _ref.getPopupContainer;
    var el = use_portal_default("dropdown", getPopupContainer);
    var _useState = p2(defaultRect2), _useState2 = _slicedToArray(_useState, 2), rect = _useState2[0], setRect = _useState2[1];
    var classes = use_classes_default2("dropdown", disableMatchWidth ? "disable-match" : "width-match");
    if (!parent)
      return null;
    if (false) {
      if (getPopupContainer && getPopupContainer()) {
        var _el = getPopupContainer();
        var style2 = window.getComputedStyle(_el);
        if (style2.position === "static") {
          use_warning_default('The element specified by "getPopupContainer" must have "position" set.');
        }
      }
    }
    var updateRect = function updateRect2() {
      var _getRefRect = getRefRect(parent, getPopupContainer), top = _getRefRect.top, left = _getRefRect.left, right = _getRefRect.right, nativeWidth = _getRefRect.width;
      setRect({
        top,
        left,
        right,
        width: nativeWidth
      });
    };
    use_resize_default(updateRect);
    use_click_anywhere_default(function() {
      var _getRefRect2 = getRefRect(parent, getPopupContainer), top = _getRefRect2.top, left = _getRefRect2.left;
      var shouldUpdatePosition = top !== rect.top || left !== rect.left;
      if (!shouldUpdatePosition)
        return;
      updateRect();
    });
    use_dom_observer_default(parent, function() {
      updateRect();
    });
    h2(function() {
      if (!parent || !parent.current)
        return;
      parent.current.addEventListener("mouseenter", updateRect);
      return function() {
        if (!parent || !parent.current)
          return;
        parent.current.removeEventListener("mouseenter", updateRect);
      };
    }, [parent]);
    var clickHandler = function clickHandler2(event) {
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      event.preventDefault();
    };
    var mouseDownHandler = function mouseDownHandler2(event) {
      event.preventDefault();
    };
    if (!el)
      return null;
    return /* @__PURE__ */ j3(/* @__PURE__ */ bn.createElement(css_transition_default, {
      visible
    }, /* @__PURE__ */ bn.createElement("div", {
      onClick: clickHandler,
      onMouseDown: mouseDownHandler,
      className: styled_jsx_es_default.dynamic([["1644673105", [rect.top + 2, rect.left, rect.width, rect.width]]]) + " " + (classes || "")
    }, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1644673105",
      dynamic: [rect.top + 2, rect.left, rect.width, rect.width]
    }, ".dropdown.__jsx-style-dynamic-selector{position:absolute;top:".concat(rect.top + 2, "px;left:").concat(rect.left, "px;z-index:1100;}.width-match.__jsx-style-dynamic-selector{width:").concat(rect.width, "px;}.disable-match.__jsx-style-dynamic-selector{min-width:").concat(rect.width, "px;}")))), el);
  });
  var dropdown_default = Dropdown;

  // node_modules/@geist-ui/core/esm/loading/loading.js
  init_react();
  var _excluded7 = ["children", "type", "color", "className", "spaceRatio"];
  var defaultProps4 = {
    type: "default",
    className: "",
    spaceRatio: 1
  };
  var getIconBgColor = function getIconBgColor2(type, palette3, color) {
    var colors = {
      "default": palette3.accents_6,
      secondary: palette3.secondary,
      success: palette3.success,
      warning: palette3.warning,
      error: palette3.error
    };
    return color ? color : colors[type];
  };
  var LoadingComponent = function LoadingComponent2(_ref) {
    var children = _ref.children, type = _ref.type, color = _ref.color, className = _ref.className, spaceRatio = _ref.spaceRatio, props = _objectWithoutProperties(_ref, _excluded7);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var classes = use_classes_default2("loading-container", className);
    var bgColor = F(function() {
      return getIconBgColor(type, theme.palette, color);
    }, [type, theme.palette, color]);
    return /* @__PURE__ */ bn.createElement("div", _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["2201634259", [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]]]) + " " + (props && props.className != null && props.className || classes || "")
    }), /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["2201634259", [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]]]) + " loading"
    }, children && /* @__PURE__ */ bn.createElement("label", {
      className: styled_jsx_es_default.dynamic([["2201634259", [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]]])
    }, children), /* @__PURE__ */ bn.createElement("i", {
      className: styled_jsx_es_default.dynamic([["2201634259", [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]]])
    }), /* @__PURE__ */ bn.createElement("i", {
      className: styled_jsx_es_default.dynamic([["2201634259", [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]]])
    }), /* @__PURE__ */ bn.createElement("i", {
      className: styled_jsx_es_default.dynamic([["2201634259", [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]]])
    })), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "2201634259",
      dynamic: [SCALES.font(1), SCALES.width(1, "100%"), SCALES.height(1, "100%"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), theme.palette.accents_5, bgColor, spaceRatio]
    }, ".loading-container.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;position:relative;font-size:".concat(SCALES.font(1), ";width:").concat(SCALES.width(1, "100%"), ";height:").concat(SCALES.height(1, "100%"), ";min-height:1em;padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}label.__jsx-style-dynamic-selector{margin-right:0.5em;color:").concat(theme.palette.accents_5, ";line-height:1;}label.__jsx-style-dynamic-selector *{margin:0;}.loading.__jsx-style-dynamic-selector{position:absolute;top:50%;left:50%;width:100%;height:100%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-color:transparent;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}i.__jsx-style-dynamic-selector{width:0.25em;height:0.25em;border-radius:50%;background-color:").concat(bgColor, ";margin:0 calc(0.25em / 2 * ").concat(spaceRatio, ");display:inline-block;-webkit-animation:loading-blink-__jsx-style-dynamic-selector 1.4s infinite both;animation:loading-blink-__jsx-style-dynamic-selector 1.4s infinite both;}i.__jsx-style-dynamic-selector:nth-child(2){-webkit-animation-delay:0.2s;animation-delay:0.2s;}i.__jsx-style-dynamic-selector:nth-child(3){-webkit-animation-delay:0.4s;animation-delay:0.4s;}@-webkit-keyframes loading-blink-__jsx-style-dynamic-selector{0%{opacity:0.2;}20%{opacity:1;}100%{opacity:0.2;}}@keyframes loading-blink-__jsx-style-dynamic-selector{0%{opacity:0.2;}20%{opacity:1;}100%{opacity:0.2;}}")));
  };
  LoadingComponent.defaultProps = defaultProps4;
  LoadingComponent.displayName = "GeistLoading";
  var Loading = with_scale_default(LoadingComponent);
  var loading_default = Loading;

  // node_modules/@geist-ui/core/esm/loading/index.js
  var loading_default2 = loading_default;

  // node_modules/@geist-ui/core/esm/use-current-state/use-current-state.js
  init_react();
  var useCurrentState = function useCurrentState2(initialState) {
    var _useState = p2(function() {
      return typeof initialState === "function" ? initialState() : initialState;
    }), _useState2 = _slicedToArray(_useState, 2), state = _useState2[0], setState = _useState2[1];
    var ref = _2(initialState);
    h2(function() {
      ref.current = state;
    }, [state]);
    var setValue = function setValue2(val) {
      var result = typeof val === "function" ? val(ref.current) : val;
      ref.current = result;
      setState(result);
    };
    return [state, setValue, ref];
  };
  var use_current_state_default = useCurrentState;

  // node_modules/@geist-ui/core/esm/use-current-state/index.js
  var use_current_state_default2 = use_current_state_default;

  // node_modules/@geist-ui/core/esm/utils/use-current-state.js
  var use_current_state_default3 = use_current_state_default2;

  // node_modules/@geist-ui/core/esm/utils/color.js
  var hexToRgb = function hexToRgb2(color) {
    var fullReg = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    var full = color.replace(fullReg, function(_4, r3, g4, b3) {
      return "".concat(r3).concat(r3).concat(g4).concat(g4).concat(b3).concat(b3);
    });
    var values = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(full);
    if (!values) {
      throw new Error("Geist UI: Unsupported ".concat(color, " color."));
    }
    return [Number.parseInt(values[1], 16), Number.parseInt(values[2], 16), Number.parseInt(values[3], 16)];
  };
  var colorToRgbValues = function colorToRgbValues2(color) {
    if (color.charAt(0) === "#")
      return hexToRgb(color);
    var safeColor = color.replace(/ /g, "");
    var colorType = color.substr(0, 4);
    var regArray = safeColor.match(/\((.+)\)/);
    if (!colorType.startsWith("rgb") || !regArray) {
      console.log(color);
      throw new Error('Geist UI: Only support ["RGB", "RGBA", "HEX"] color.');
    }
    return regArray[1].split(",").map(function(str) {
      return Number.parseFloat(str);
    });
  };
  var addColorAlpha = function addColorAlpha2(color, alpha) {
    if (!/^#|rgb|RGB/.test(color))
      return color;
    var _colorToRgbValues = colorToRgbValues(color), _colorToRgbValues2 = _slicedToArray(_colorToRgbValues, 3), r3 = _colorToRgbValues2[0], g4 = _colorToRgbValues2[1], b3 = _colorToRgbValues2[2];
    var safeAlpha = alpha > 1 ? 1 : alpha < 0 ? 0 : alpha;
    return "rgba(".concat(r3, ", ").concat(g4, ", ").concat(b3, ", ").concat(safeAlpha, ")");
  };

  // node_modules/@geist-ui/core/esm/button/button.js
  init_react();

  // node_modules/@geist-ui/core/esm/button/button.drip.js
  init_react();
  var defaultProps5 = {
    x: 0,
    y: 0
  };
  var ButtonDrip = function ButtonDrip2(_ref) {
    var x4 = _ref.x, y3 = _ref.y, color = _ref.color, onCompleted = _ref.onCompleted;
    var dripRef = _2(null);
    var top = Number.isNaN(+y3) ? 0 : y3 - 10;
    var left = Number.isNaN(+x4) ? 0 : x4 - 10;
    h2(function() {
      if (!dripRef.current)
        return;
      dripRef.current.addEventListener("animationend", onCompleted);
      return function() {
        if (!dripRef.current)
          return;
        dripRef.current.removeEventListener("animationend", onCompleted);
      };
    });
    return /* @__PURE__ */ bn.createElement("div", {
      ref: dripRef,
      className: "jsx-3424889537 drip"
    }, /* @__PURE__ */ bn.createElement("svg", {
      width: "20",
      height: "20",
      viewBox: "0 0 20 20",
      style: {
        top,
        left
      },
      className: "jsx-3424889537"
    }, /* @__PURE__ */ bn.createElement("g", {
      stroke: "none",
      strokeWidth: "1",
      fill: "none",
      fillRule: "evenodd",
      className: "jsx-3424889537"
    }, /* @__PURE__ */ bn.createElement("g", {
      fill: color,
      className: "jsx-3424889537"
    }, /* @__PURE__ */ bn.createElement("rect", {
      width: "100%",
      height: "100%",
      rx: "10",
      className: "jsx-3424889537"
    })))), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3424889537"
    }, ".drip.jsx-3424889537{position:absolute;left:0;right:0;top:0;bottom:0;}svg.jsx-3424889537{position:absolute;-webkit-animation:350ms ease-in expand-jsx-3424889537;animation:350ms ease-in expand-jsx-3424889537;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;width:1rem;height:1rem;}@-webkit-keyframes expand-jsx-3424889537{0%{opacity:0;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}30%{opacity:1;}80%{opacity:0.5;}100%{-webkit-transform:scale(28);-ms-transform:scale(28);transform:scale(28);opacity:0;}}@keyframes expand-jsx-3424889537{0%{opacity:0;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}30%{opacity:1;}80%{opacity:0.5;}100%{-webkit-transform:scale(28);-ms-transform:scale(28);transform:scale(28);opacity:0;}}"));
  };
  ButtonDrip.defaultProps = defaultProps5;
  ButtonDrip.displayName = "GeistButtonDrip";
  var button_drip_default = ButtonDrip;

  // node_modules/@geist-ui/core/esm/button/button-loading.js
  init_react();
  var ButtonLoading = function ButtonLoading2(_ref) {
    var color = _ref.color;
    return /* @__PURE__ */ bn.createElement("div", {
      className: "jsx-3416748964 btn-loading"
    }, /* @__PURE__ */ bn.createElement(loading_default2, {
      color
    }), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3416748964"
    }, ".btn-loading.jsx-3416748964{position:absolute;top:0;left:0;right:0;bottom:0;z-index:2;background-color:var(--geist-ui-button-bg);}"));
  };
  ButtonLoading.displayName = "GeistButtonLoading";
  var button_loading_default = ButtonLoading;

  // node_modules/@geist-ui/core/esm/button/utils.js
  init_react();

  // node_modules/@geist-ui/core/esm/button/button-icon.js
  init_react();
  var _excluded8 = ["isRight", "isSingle", "children", "className"];
  var defaultProps6 = {
    isRight: false,
    className: ""
  };
  var ButtonIcon = function ButtonIcon2(_ref) {
    var isRight = _ref.isRight, isSingle = _ref.isSingle, children = _ref.children, className = _ref.className, props = _objectWithoutProperties(_ref, _excluded8);
    var classes = use_classes_default2("icon", {
      right: isRight,
      single: isSingle
    }, className);
    return /* @__PURE__ */ bn.createElement("span", _extends({}, props, {
      className: "jsx-643337184 " + (props && props.className != null && props.className || classes || "")
    }), children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "643337184"
    }, ".icon.jsx-643337184{position:absolute;left:var(--geist-ui-button-icon-padding);right:auto;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:var(--geist-ui-button-color);z-index:1;}.right.jsx-643337184{right:var(--geist-ui-button-icon-padding);left:auto;}.icon.jsx-643337184 svg{background:transparent;height:calc(var(--geist-ui-button-height) / 2.35);width:calc(var(--geist-ui-button-height) / 2.35);}.single.jsx-643337184{position:static;-webkit-transform:none;-ms-transform:none;transform:none;}"));
  };
  ButtonIcon.defaultProps = defaultProps6;
  ButtonIcon.displayName = "GeistButtonIcon";
  var button_icon_default = ButtonIcon;

  // node_modules/@geist-ui/core/esm/button/utils.js
  var getButtonChildrenWithIcon = function getButtonChildrenWithIcon2(auto, children, icons) {
    var icon = icons.icon, iconRight = icons.iconRight;
    var hasIcon = icon || iconRight;
    var isRight = Boolean(iconRight);
    var paddingForAutoMode = auto ? "calc(var(--geist-ui-button-height) / 2 + var(--geist-ui-button-icon-padding) * .5)" : 0;
    var classes = use_classes_default2("text", isRight ? "right" : "left");
    if (!hasIcon)
      return /* @__PURE__ */ bn.createElement("div", {
        className: "text"
      }, children);
    if (bn.Children.count(children) === 0) {
      return /* @__PURE__ */ bn.createElement(button_icon_default, {
        isRight,
        isSingle: true
      }, hasIcon);
    }
    return /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement(button_icon_default, {
      isRight
    }, hasIcon), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["3568181479", [paddingForAutoMode, paddingForAutoMode]]]) + " " + (classes || "")
    }, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3568181479",
      dynamic: [paddingForAutoMode, paddingForAutoMode]
    }, ".left.__jsx-style-dynamic-selector{padding-left:".concat(paddingForAutoMode, ";}.right.__jsx-style-dynamic-selector{padding-right:").concat(paddingForAutoMode, ";}"))));
  };
  var filterPropsWithGroup = function filterPropsWithGroup2(props, config) {
    if (!config.isButtonGroup)
      return props;
    return _extends({}, props, {
      auto: true,
      shadow: false,
      ghost: config.ghost || props.ghost,
      type: config.type || props.type,
      disabled: config.disabled || props.disabled
    });
  };

  // node_modules/@geist-ui/core/esm/button-group/button-group-context.js
  init_react();
  var defaultContext2 = {
    isButtonGroup: false,
    disabled: false
  };
  var ButtonGroupContext = /* @__PURE__ */ bn.createContext(defaultContext2);
  var useButtonGroupContext = function useButtonGroupContext2() {
    return bn.useContext(ButtonGroupContext);
  };

  // node_modules/@geist-ui/core/esm/button/styles.js
  var getButtonGhostColors = function getButtonGhostColors2(palette3, type) {
    var colors = {
      secondary: {
        bg: palette3.background,
        border: palette3.foreground,
        color: palette3.foreground
      },
      success: {
        bg: palette3.background,
        border: palette3.success,
        color: palette3.success
      },
      warning: {
        bg: palette3.background,
        border: palette3.warning,
        color: palette3.warning
      },
      error: {
        bg: palette3.background,
        border: palette3.error,
        color: palette3.error
      }
    };
    return colors[type] || null;
  };
  var getButtonColors = function getButtonColors2(palette3, props) {
    var type = props.type, disabled = props.disabled, ghost = props.ghost;
    var colors = {
      "default": {
        bg: palette3.background,
        border: palette3.border,
        color: palette3.accents_5
      },
      secondary: {
        bg: palette3.foreground,
        border: palette3.foreground,
        color: palette3.background
      },
      success: {
        bg: palette3.success,
        border: palette3.success,
        color: "#fff"
      },
      warning: {
        bg: palette3.warning,
        border: palette3.warning,
        color: "#fff"
      },
      error: {
        bg: palette3.error,
        border: palette3.error,
        color: "#fff"
      },
      abort: {
        bg: "transparent",
        border: "transparent",
        color: palette3.accents_5
      }
    };
    if (disabled)
      return {
        bg: palette3.accents_1,
        border: palette3.accents_2,
        color: "#ccc"
      };
    var withoutLightType = type === null || type === void 0 ? void 0 : type.replace("-light", "");
    var defaultColor = colors["default"];
    if (ghost)
      return getButtonGhostColors(palette3, withoutLightType) || defaultColor;
    return colors[withoutLightType] || defaultColor;
  };
  var getButtonGhostHoverColors = function getButtonGhostHoverColors2(palette3, type) {
    var colors = {
      secondary: {
        bg: palette3.foreground,
        border: palette3.background,
        color: palette3.background
      },
      success: {
        bg: palette3.success,
        border: palette3.background,
        color: "white"
      },
      warning: {
        bg: palette3.warning,
        border: palette3.background,
        color: "white"
      },
      error: {
        bg: palette3.error,
        border: palette3.background,
        color: "white"
      }
    };
    var withoutLightType = type.replace("-light", "");
    return colors[withoutLightType] || null;
  };
  var getButtonHoverColors = function getButtonHoverColors2(palette3, props) {
    var type = props.type, disabled = props.disabled, loading = props.loading, shadow = props.shadow, ghost = props.ghost;
    var defaultColor = getButtonColors(palette3, props);
    var alphaBackground = addColorAlpha(defaultColor.bg, 0.85);
    var colors = {
      "default": {
        bg: palette3.background,
        border: palette3.foreground
      },
      secondary: {
        bg: palette3.background,
        border: palette3.foreground
      },
      success: {
        bg: palette3.background,
        border: palette3.success
      },
      warning: {
        bg: palette3.background,
        border: palette3.warning
      },
      error: {
        bg: palette3.background,
        border: palette3.error
      },
      abort: {
        bg: "transparent",
        border: "transparent",
        color: palette3.accents_5
      },
      "secondary-light": _extends({}, defaultColor, {
        bg: alphaBackground
      }),
      "success-light": _extends({}, defaultColor, {
        bg: alphaBackground
      }),
      "warning-light": _extends({}, defaultColor, {
        bg: alphaBackground
      }),
      "error-light": _extends({}, defaultColor, {
        bg: alphaBackground
      })
    };
    if (disabled)
      return {
        bg: palette3.accents_1,
        border: palette3.accents_2,
        color: "#ccc"
      };
    if (loading)
      return _extends({}, defaultColor, {
        color: "transparent"
      });
    if (shadow)
      return defaultColor;
    var hoverColor = (ghost ? getButtonGhostHoverColors(palette3, type) : colors[type]) || colors["default"];
    return _extends({}, hoverColor, {
      color: hoverColor.color || hoverColor.border
    });
  };
  var getButtonCursor = function getButtonCursor2(disabled, loading) {
    if (disabled)
      return {
        cursor: "not-allowed",
        events: "auto"
      };
    if (loading)
      return {
        cursor: "default",
        events: "none"
      };
    return {
      cursor: "pointer",
      events: "auto"
    };
  };
  var getButtonDripColor = function getButtonDripColor2(palette3, props) {
    var type = props.type;
    var isLightHover = type.endsWith("light");
    var hoverColors = getButtonHoverColors(palette3, props);
    return isLightHover ? addColorAlpha(hoverColors.bg, 0.65) : addColorAlpha(palette3.accents_2, 0.65);
  };

  // node_modules/@geist-ui/core/esm/button/button.js
  var _excluded9 = ["children", "disabled", "type", "loading", "shadow", "ghost", "effect", "onClick", "auto", "icon", "htmlType", "iconRight", "className"];
  var defaultProps7 = {
    type: "default",
    htmlType: "button",
    ghost: false,
    loading: false,
    shadow: false,
    auto: false,
    effect: true,
    disabled: false,
    className: ""
  };
  var ButtonComponent = /* @__PURE__ */ bn.forwardRef(function(btnProps, ref) {
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var buttonRef = _2(null);
    A2(ref, function() {
      return buttonRef.current;
    });
    var _useState = p2(false), _useState2 = _slicedToArray(_useState, 2), dripShow = _useState2[0], setDripShow = _useState2[1];
    var _useState3 = p2(0), _useState4 = _slicedToArray(_useState3, 2), dripX = _useState4[0], setDripX = _useState4[1];
    var _useState5 = p2(0), _useState6 = _slicedToArray(_useState5, 2), dripY = _useState6[0], setDripY = _useState6[1];
    var groupConfig = useButtonGroupContext();
    var filteredProps = filterPropsWithGroup(btnProps, groupConfig);
    var children = filteredProps.children, disabled = filteredProps.disabled, type = filteredProps.type, loading = filteredProps.loading, shadow = filteredProps.shadow, ghost = filteredProps.ghost, effect = filteredProps.effect, onClick = filteredProps.onClick, auto = filteredProps.auto, icon = filteredProps.icon, htmlType = filteredProps.htmlType, iconRight = filteredProps.iconRight, className = filteredProps.className, props = _objectWithoutProperties(filteredProps, _excluded9);
    var _useMemo = F(function() {
      return getButtonColors(theme.palette, filteredProps);
    }, [theme.palette, filteredProps]), bg = _useMemo.bg, border = _useMemo.border, color = _useMemo.color;
    var hover = F(function() {
      return getButtonHoverColors(theme.palette, filteredProps);
    }, [theme.palette, filteredProps]);
    var _useMemo2 = F(function() {
      return getButtonCursor(disabled, loading);
    }, [disabled, loading]), cursor = _useMemo2.cursor, events = _useMemo2.events;
    var dripColor = F(function() {
      return getButtonDripColor(theme.palette, filteredProps);
    }, [theme.palette, filteredProps]);
    var dripCompletedHandle = function dripCompletedHandle2() {
      setDripShow(false);
      setDripX(0);
      setDripY(0);
    };
    var clickHandler = function clickHandler2(event) {
      if (disabled || loading)
        return;
      var showDrip = !shadow && !ghost && effect;
      if (showDrip && buttonRef.current) {
        var rect = buttonRef.current.getBoundingClientRect();
        setDripShow(true);
        setDripX(event.clientX - rect.left);
        setDripY(event.clientY - rect.top);
      }
      onClick && onClick(event);
    };
    var childrenWithIcon = F(function() {
      return getButtonChildrenWithIcon(auto, children, {
        icon,
        iconRight
      });
    }, [auto, children, icon, iconRight]);
    var paddingLeft = auto ? SCALES.pl(1.15) : SCALES.pl(1.375), paddingRight = auto ? SCALES.pr(1.15) : SCALES.pr(1.375);
    return /* @__PURE__ */ bn.createElement("button", _extends({
      ref: buttonRef,
      type: htmlType,
      disabled,
      onClick: clickHandler
    }, props, {
      className: styled_jsx_es_default.dynamic([["86551275", [SCALES.height(2.5), theme.layout.radius, SCALES.font(0.875), color, bg, border, cursor, events, shadow ? theme.expressiveness.shadowSmall : "none", SCALES.pl(0.727), SCALES.height(2.5), color, bg, auto ? "min-content" : SCALES.width(10.5), auto ? "auto" : "initial", SCALES.height(2.5), SCALES.pt(0), paddingRight, SCALES.pb(0), paddingLeft, SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hover.color, hover.color, hover.bg, hover.border, cursor, events, shadow ? theme.expressiveness.shadowMedium : "none", shadow ? "-1px" : "0px"]]]) + " " + (props && props.className != null && props.className || use_classes_default2("btn", className) || "")
    }), loading && /* @__PURE__ */ bn.createElement(button_loading_default, {
      color
    }), childrenWithIcon, dripShow && /* @__PURE__ */ bn.createElement(button_drip_default, {
      x: dripX,
      y: dripY,
      color: dripColor,
      onCompleted: dripCompletedHandle
    }), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "86551275",
      dynamic: [SCALES.height(2.5), theme.layout.radius, SCALES.font(0.875), color, bg, border, cursor, events, shadow ? theme.expressiveness.shadowSmall : "none", SCALES.pl(0.727), SCALES.height(2.5), color, bg, auto ? "min-content" : SCALES.width(10.5), auto ? "auto" : "initial", SCALES.height(2.5), SCALES.pt(0), paddingRight, SCALES.pb(0), paddingLeft, SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hover.color, hover.color, hover.bg, hover.border, cursor, events, shadow ? theme.expressiveness.shadowMedium : "none", shadow ? "-1px" : "0px"]
    }, ".btn.__jsx-style-dynamic-selector{box-sizing:border-box;display:inline-block;line-height:".concat(SCALES.height(2.5), ";border-radius:").concat(theme.layout.radius, ";font-weight:400;font-size:").concat(SCALES.font(0.875), ";-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;outline:none;text-transform:capitalize;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;text-align:center;white-space:nowrap;-webkit-transition:background-color 200ms ease 0ms,box-shadow 200ms ease 0ms, border 200ms ease 0ms,color 200ms ease 0ms;transition:background-color 200ms ease 0ms,box-shadow 200ms ease 0ms, border 200ms ease 0ms,color 200ms ease 0ms;position:relative;overflow:hidden;color:").concat(color, ";background-color:").concat(bg, ";border:1px solid ").concat(border, ";cursor:").concat(cursor, ";pointer-events:").concat(events, ";box-shadow:").concat(shadow ? theme.expressiveness.shadowSmall : "none", ";--geist-ui-button-icon-padding:").concat(SCALES.pl(0.727), ";--geist-ui-button-height:").concat(SCALES.height(2.5), ";--geist-ui-button-color:").concat(color, ";--geist-ui-button-bg:").concat(bg, ";min-width:").concat(auto ? "min-content" : SCALES.width(10.5), ";width:").concat(auto ? "auto" : "initial", ";height:").concat(SCALES.height(2.5), ";padding:").concat(SCALES.pt(0), " ").concat(paddingRight, " ").concat(SCALES.pb(0), " ").concat(paddingLeft, ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.btn.__jsx-style-dynamic-selector:hover,.btn.__jsx-style-dynamic-selector:focus{color:").concat(hover.color, ";--geist-ui-button-color:").concat(hover.color, ";background-color:").concat(hover.bg, ";border-color:").concat(hover.border, ";cursor:").concat(cursor, ";pointer-events:").concat(events, ";box-shadow:").concat(shadow ? theme.expressiveness.shadowMedium : "none", ";-webkit-transform:translate3d(0px,").concat(shadow ? "-1px" : "0px", ",0px);-ms-transform:translate3d(0px,").concat(shadow ? "-1px" : "0px", ",0px);transform:translate3d(0px,").concat(shadow ? "-1px" : "0px", ",0px);}.btn.__jsx-style-dynamic-selector .text{position:relative;z-index:1;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;text-align:center;line-height:inherit;top:-1px;}.btn.__jsx-style-dynamic-selector .text p,.btn.__jsx-style-dynamic-selector .text pre,.btn.__jsx-style-dynamic-selector .text div{margin:0;}")));
  });
  ButtonComponent.defaultProps = defaultProps7;
  ButtonComponent.displayName = "GeistButton";
  var Button = with_scale_default(ButtonComponent);
  var button_default = Button;

  // node_modules/@geist-ui/core/esm/button/index.js
  var button_default2 = button_default;

  // node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js
  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr))
      return _arrayLikeToArray(arr);
  }

  // node_modules/@babel/runtime/helpers/esm/iterableToArray.js
  function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null)
      return Array.from(iter);
  }

  // node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  // node_modules/@babel/runtime/helpers/esm/toConsumableArray.js
  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
  }

  // node_modules/@geist-ui/core/esm/geist-provider/geist-provider.js
  init_react();

  // node_modules/@geist-ui/core/esm/utils/use-geist-ui-context.js
  init_react();
  var defaultToastLayout = {
    padding: "12px 16px",
    margin: "8px 0",
    width: "420px",
    maxWidth: "90vw",
    maxHeight: "75px",
    placement: "bottomRight"
  };
  var defaultParams = {
    toasts: [],
    toastLayout: defaultToastLayout,
    updateToastLayout: function updateToastLayout(t3) {
      return t3;
    },
    updateToasts: function updateToasts(t3) {
      return t3;
    },
    lastUpdateToastId: null,
    updateLastToastId: function updateLastToastId() {
      return null;
    }
  };
  var GeistUIContent = /* @__PURE__ */ bn.createContext(defaultParams);
  var useGeistUIContext = function useGeistUIContext2() {
    return bn.useContext(GeistUIContent);
  };

  // node_modules/@geist-ui/core/esm/geist-provider/theme-provider.js
  init_react();

  // node_modules/@geist-ui/core/esm/use-all-themes/all-themes-context.js
  init_react();
  var defaultAllThemesConfig = {
    themes: themes_default.getPresets()
  };
  var AllThemesContext = /* @__PURE__ */ bn.createContext(defaultAllThemesConfig);

  // node_modules/@geist-ui/core/esm/geist-provider/theme-provider.js
  var ThemeProvider = function ThemeProvider2(_ref) {
    var children = _ref.children, themeType = _ref.themeType, _ref$themes = _ref.themes, themes3 = _ref$themes === void 0 ? [] : _ref$themes;
    var _useState = p2({
      themes: themes_default2.getPresets()
    }), _useState2 = _slicedToArray(_useState, 2), allThemes = _useState2[0], setAllThemes = _useState2[1];
    var currentTheme = F(function() {
      var theme = allThemes.themes.find(function(item) {
        return item.type === themeType;
      });
      if (theme)
        return theme;
      return themes_default2.getPresetStaticTheme();
    }, [allThemes, themeType]);
    h2(function() {
      if (!(themes3 !== null && themes3 !== void 0 && themes3.length))
        return;
      setAllThemes(function(last) {
        var safeThemes = themes3.filter(function(item) {
          return themes_default2.isAvailableThemeType(item.type);
        });
        var nextThemes = themes_default2.getPresets().concat(safeThemes);
        return _extends({}, last, {
          themes: nextThemes
        });
      });
    }, [themes3]);
    return /* @__PURE__ */ bn.createElement(AllThemesContext.Provider, {
      value: allThemes
    }, /* @__PURE__ */ bn.createElement(ThemeContext.Provider, {
      value: currentTheme
    }, children));
  };
  var theme_provider_default = ThemeProvider;

  // node_modules/@geist-ui/core/esm/use-toasts/toast-container.js
  init_react();

  // node_modules/@geist-ui/core/esm/use-toasts/toast-item.js
  init_react();

  // node_modules/@geist-ui/core/esm/use-toasts/helpers.js
  init_react();
  var makeToastActions = function makeToastActions2(actions, cancelHandle) {
    var handler = function handler2(event, userHandler) {
      userHandler && userHandler(event, cancelHandle);
    };
    if (!actions || !actions.length)
      return null;
    return actions.map(function(action, index) {
      return /* @__PURE__ */ bn.createElement(button_default2, {
        auto: true,
        scale: 1 / 3,
        font: "13px",
        type: action.passive ? "default" : "secondary",
        key: "action-".concat(index),
        onClick: function onClick(event) {
          return handler(event, action.handler);
        }
      }, action.name);
    });
  };
  var getColors3 = function getColors4(palette3, type) {
    var colors = {
      "default": palette3.background,
      secondary: palette3.secondary,
      success: palette3.success,
      warning: palette3.warning,
      error: palette3.error
    };
    var isDefault = !type || type === "default";
    if (isDefault)
      return {
        bgColor: colors["default"],
        color: palette3.foreground
      };
    return {
      bgColor: colors[type],
      color: "white"
    };
  };
  var toastPlacement = tuple("topLeft", "topRight", "bottomLeft", "bottomRight");
  var isTopPlacement = function isTopPlacement2(placement2) {
    return "".concat(placement2).toLowerCase().startsWith("top");
  };
  var isLeftPlacement = function isLeftPlacement2(placement2) {
    return "".concat(placement2).toLowerCase().endsWith("left");
  };
  var getTranslateByPlacement = function getTranslateByPlacement2(placement2) {
    var translateInByPlacement = {
      topLeft: "translate(-60px, -60px)",
      topRight: "translate(60px, -60px)",
      bottomLeft: "translate(-60px, 60px)",
      bottomRight: "translate(60px, 60px)"
    };
    var translateOutByPlacement = {
      topLeft: "translate(-50px, 15px) scale(0.85)",
      topRight: "translate(50px, 15px) scale(0.85)",
      bottomLeft: "translate(-50px, -15px) scale(0.85)",
      bottomRight: "translate(50px, -15px) scale(0.85)"
    };
    return {
      enter: translateInByPlacement[placement2],
      leave: translateOutByPlacement[placement2]
    };
  };

  // node_modules/@geist-ui/core/esm/use-toasts/toast-item.js
  var ToastItem = /* @__PURE__ */ bn.memo(function(_ref) {
    var toast = _ref.toast, layout3 = _ref.layout;
    var theme = use_theme_default();
    var _useMemo = F(function() {
      return getColors3(theme.palette, toast.type);
    }, [theme.palette, toast.type]), color = _useMemo.color, bgColor = _useMemo.bgColor;
    var isReactNode = typeof toast.text !== "string";
    var padding = layout3.padding, margin = layout3.margin, maxHeight = layout3.maxHeight, maxWidth = layout3.maxWidth, width = layout3.width, placement2 = layout3.placement;
    var _useMemo2 = F(function() {
      return getTranslateByPlacement(placement2);
    }, [placement2]), enter = _useMemo2.enter, leave = _useMemo2.leave;
    return /* @__PURE__ */ bn.createElement(css_transition_default, {
      name: "toast",
      visible: toast.visible,
      clearTime: 350
    }, /* @__PURE__ */ bn.createElement("div", {
      key: toast.id,
      className: styled_jsx_es_default.dynamic([["1407001838", [width, maxWidth, maxHeight, theme.palette.foreground, bgColor, color, theme.layout.radius, theme.expressiveness.shadowSmall, theme.layout.gapHalf, enter, margin, padding, margin, padding, leave]]]) + " toast"
    }, isReactNode ? toast.text : /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["1407001838", [width, maxWidth, maxHeight, theme.palette.foreground, bgColor, color, theme.layout.radius, theme.expressiveness.shadowSmall, theme.layout.gapHalf, enter, margin, padding, margin, padding, leave]]]) + " message"
    }, toast.text), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["1407001838", [width, maxWidth, maxHeight, theme.palette.foreground, bgColor, color, theme.layout.radius, theme.expressiveness.shadowSmall, theme.layout.gapHalf, enter, margin, padding, margin, padding, leave]]]) + " action"
    }, makeToastActions(toast.actions, toast.cancel))), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1407001838",
      dynamic: [width, maxWidth, maxHeight, theme.palette.foreground, bgColor, color, theme.layout.radius, theme.expressiveness.shadowSmall, theme.layout.gapHalf, enter, margin, padding, margin, padding, leave]
    }, ".toast.__jsx-style-dynamic-selector{width:".concat(width, ";max-width:").concat(maxWidth, ";max-height:").concat(maxHeight, ";display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:").concat(theme.palette.foreground, ";background-color:").concat(bgColor, ";color:").concat(color, ";border:0;border-radius:").concat(theme.layout.radius, ";opacity:1;box-shadow:").concat(theme.expressiveness.shadowSmall, ";-webkit-transition:all 350ms cubic-bezier(0.1,0.2,0.1,1);transition:all 350ms cubic-bezier(0.1,0.2,0.1,1);overflow:hidden;}.message.__jsx-style-dynamic-selector{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:100%;font-size:0.875em;display:-webkit-box;word-break:break-all;padding-right:").concat(theme.layout.gapHalf, ";overflow:hidden;max-height:100%;text-overflow:ellipsis;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-height:1.1rem;}.toast-enter.__jsx-style-dynamic-selector{opacity:0;height:0;padding:0;margin:0;-webkit-transform:").concat(enter, ";-ms-transform:").concat(enter, ";transform:").concat(enter, ";}.toast-enter-active.__jsx-style-dynamic-selector{opacity:1;height:auto;margin:").concat(margin, ";padding:").concat(padding, ";-webkit-transform:translate(0,0);-ms-transform:translate(0,0);transform:translate(0,0);}.toast-leave.__jsx-style-dynamic-selector{opacity:1;-webkit-transform:translate(0,0);-ms-transform:translate(0,0);transform:translate(0,0);height:auto;margin:").concat(margin, ";padding:").concat(padding, ";}.toast-leave-active.__jsx-style-dynamic-selector{opacity:0;-webkit-transform:").concat(leave, ";-ms-transform:").concat(leave, ";transform:").concat(leave, ";}"))));
  });
  var toast_item_default = ToastItem;

  // node_modules/@geist-ui/core/esm/use-toasts/toast-container.js
  var ToastContainer = function ToastContainer2() {
    var theme = use_theme_default();
    var portal = use_portal_default("toast");
    var _useCurrentState = use_current_state_default3(false), _useCurrentState2 = _slicedToArray(_useCurrentState, 3), setHovering = _useCurrentState2[1], hoveringRef = _useCurrentState2[2];
    var _useGeistUIContext = useGeistUIContext(), toasts = _useGeistUIContext.toasts, updateToasts2 = _useGeistUIContext.updateToasts, toastLayout = _useGeistUIContext.toastLayout, lastUpdateToastId = _useGeistUIContext.lastUpdateToastId;
    var memoizedLayout = F(function() {
      return toastLayout;
    }, [toastLayout]);
    var toastElements = F(function() {
      return toasts.map(function(toast) {
        return /* @__PURE__ */ bn.createElement(toast_item_default, {
          toast,
          layout: memoizedLayout,
          key: toast._internalIdent
        });
      });
    }, [toasts, memoizedLayout]);
    var classNames = F(function() {
      return use_classes_default2("toasts", {
        top: isTopPlacement(toastLayout.placement),
        left: isLeftPlacement(toastLayout.placement)
      });
    }, [memoizedLayout]);
    var hoverHandler = function hoverHandler2(isHovering) {
      setHovering(isHovering);
      if (isHovering) {
        return updateToasts2(function(last) {
          return last.map(function(toast) {
            if (!toast.visible)
              return toast;
            toast._timeout && window.clearTimeout(toast._timeout);
            return _extends({}, toast, {
              timeout: null
            });
          });
        });
      }
      updateToasts2(function(last) {
        return last.map(function(toast, index) {
          if (!toast.visible)
            return toast;
          toast._timeout && window.clearTimeout(toast._timeout);
          return _extends({}, toast, {
            _timeout: function() {
              var timer = window.setTimeout(function() {
                toast.cancel();
                window.clearTimeout(timer);
              }, toast.delay + index * 100);
              return timer;
            }()
          });
        });
      });
    };
    h2(function() {
      var index = toasts.findIndex(function(r3) {
        return r3._internalIdent === lastUpdateToastId;
      });
      var toast = toasts[index];
      if (!toast || toast.visible || !hoveringRef.current)
        return;
      var hasVisible = toasts.find(function(r3, i3) {
        return i3 < index && r3.visible;
      });
      if (hasVisible || !hoveringRef.current)
        return;
      hoverHandler(false);
    }, [toasts, lastUpdateToastId]);
    h2(function() {
      var timeout = null;
      var timer = window.setInterval(function() {
        if (toasts.length === 0)
          return;
        timeout = window.setTimeout(function() {
          var allInvisible = !toasts.find(function(r3) {
            return r3.visible;
          });
          allInvisible && updateToasts2(function() {
            return [];
          });
          timeout && clearTimeout(timeout);
        }, 350);
      }, 5e3);
      return function() {
        timer && clearInterval(timer);
        timeout && clearTimeout(timeout);
      };
    }, [toasts]);
    if (!portal)
      return null;
    if (!toasts || toasts.length === 0)
      return null;
    return /* @__PURE__ */ j3(/* @__PURE__ */ bn.createElement("div", {
      onMouseEnter: function onMouseEnter() {
        return hoverHandler(true);
      },
      onMouseLeave: function onMouseLeave() {
        return hoverHandler(false);
      },
      className: styled_jsx_es_default.dynamic([["622610754", [theme.layout.gap, theme.layout.gap, theme.layout.gap, theme.layout.gap]]]) + " " + (classNames || "")
    }, toastElements, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "622610754",
      dynamic: [theme.layout.gap, theme.layout.gap, theme.layout.gap, theme.layout.gap]
    }, ".toasts.__jsx-style-dynamic-selector{position:fixed;width:auto;max-width:100%;right:".concat(theme.layout.gap, ";bottom:").concat(theme.layout.gap, ";z-index:2000;-webkit-transition:all 400ms ease;transition:all 400ms ease;box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}.top.__jsx-style-dynamic-selector{bottom:unset;-webkit-flex-direction:column-reverse;-ms-flex-direction:column-reverse;flex-direction:column-reverse;top:").concat(theme.layout.gap, ";}.left.__jsx-style-dynamic-selector{right:unset;left:").concat(theme.layout.gap, ";}"))), portal);
  };
  var toast_container_default = ToastContainer;

  // node_modules/@geist-ui/core/esm/geist-provider/geist-provider.js
  var GeistProvider = function GeistProvider2(_ref) {
    var themes3 = _ref.themes, themeType = _ref.themeType, children = _ref.children;
    var _useState = p2(null), _useState2 = _slicedToArray(_useState, 2), lastUpdateToastId = _useState2[0], setLastUpdateToastId = _useState2[1];
    var _useCurrentState = use_current_state_default3([]), _useCurrentState2 = _slicedToArray(_useCurrentState, 3), toasts = _useCurrentState2[0], setToasts = _useCurrentState2[1], toastsRef = _useCurrentState2[2];
    var _useCurrentState3 = use_current_state_default3(defaultToastLayout), _useCurrentState4 = _slicedToArray(_useCurrentState3, 3), toastLayout = _useCurrentState4[0], setToastLayout = _useCurrentState4[1], toastLayoutRef = _useCurrentState4[2];
    var updateToasts2 = function updateToasts3(fn2) {
      var nextToasts = fn2(toastsRef.current);
      setToasts(nextToasts);
    };
    var updateToastLayout2 = function updateToastLayout3(fn2) {
      var nextLayout = fn2(toastLayoutRef.current);
      setToastLayout(nextLayout);
    };
    var updateLastToastId2 = function updateLastToastId3(fn2) {
      setLastUpdateToastId(fn2());
    };
    var initialValue = F(function() {
      return {
        toasts,
        toastLayout,
        updateToasts: updateToasts2,
        lastUpdateToastId,
        updateToastLayout: updateToastLayout2,
        updateLastToastId: updateLastToastId2
      };
    }, [toasts, toastLayout, lastUpdateToastId]);
    return /* @__PURE__ */ bn.createElement(GeistUIContent.Provider, {
      value: initialValue
    }, /* @__PURE__ */ bn.createElement(theme_provider_default, {
      themes: themes3,
      themeType
    }, children, /* @__PURE__ */ bn.createElement(toast_container_default, null)));
  };
  var geist_provider_default = GeistProvider;

  // node_modules/@geist-ui/core/esm/geist-provider/index.js
  var geist_provider_default2 = geist_provider_default;

  // node_modules/@geist-ui/core/esm/grid/grid.js
  init_react();

  // node_modules/@geist-ui/core/esm/grid/basic-item.js
  init_react();
  var _excluded10 = ["xs", "sm", "md", "lg", "xl", "justify", "direction", "alignItems", "alignContent", "children", "className"];
  var defaultProps8 = {
    xs: false,
    sm: false,
    md: false,
    lg: false,
    xl: false,
    className: ""
  };
  var getItemLayout = function getItemLayout2(val) {
    var display = val === 0 ? "display: none;" : "display: inherit;";
    if (typeof val === "number") {
      var width = 100 / 24 * val;
      var ratio = width > 100 ? "100%" : width < 0 ? "0" : "".concat(width, "%");
      return {
        grow: 0,
        display,
        width: ratio,
        basis: ratio
      };
    }
    return {
      grow: 1,
      display,
      width: "100%",
      basis: "0"
    };
  };
  var GridBasicItem = function GridBasicItem2(_ref) {
    var xs = _ref.xs, sm = _ref.sm, md = _ref.md, lg = _ref.lg, xl = _ref.xl, justify = _ref.justify, direction = _ref.direction, alignItems = _ref.alignItems, alignContent = _ref.alignContent, children = _ref.children, className = _ref.className, props = _objectWithoutProperties(_ref, _excluded10);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var classes = F(function() {
      var aligns = {
        justify,
        direction,
        alignItems,
        alignContent,
        xs,
        sm,
        md,
        lg,
        xl
      };
      var classString = Object.keys(aligns).reduce(function(pre, name) {
        if (aligns[name] !== void 0 && aligns[name] !== false)
          return "".concat(pre, " ").concat(name);
        return pre;
      }, "");
      return classString.trim();
    }, [justify, direction, alignItems, alignContent, xs, sm, md, lg, xl]);
    var layout3 = F(function() {
      return {
        xs: getItemLayout(xs),
        sm: getItemLayout(sm),
        md: getItemLayout(md),
        lg: getItemLayout(lg),
        xl: getItemLayout(xl)
      };
    }, [xs, sm, md, lg, xl]);
    return /* @__PURE__ */ bn.createElement("div", _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["568430467", [SCALES.font(1, "inherit"), SCALES.height(1, "auto"), justify, direction, alignContent, alignItems, layout3.xs.grow, layout3.xs.width, layout3.xs.basis, layout3.xs.display, theme.breakpoints.sm.min, layout3.sm.grow, layout3.sm.width, layout3.sm.basis, layout3.sm.display, theme.breakpoints.md.min, layout3.md.grow, layout3.md.width, layout3.md.basis, layout3.md.display, theme.breakpoints.lg.min, layout3.lg.grow, layout3.lg.width, layout3.lg.basis, layout3.lg.display, theme.breakpoints.xl.min, layout3.xl.grow, layout3.xl.width, layout3.xl.basis, layout3.xl.display]]]) + " " + (props && props.className != null && props.className || use_classes_default2("item", classes, className) || "")
    }), children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "568430467",
      dynamic: [SCALES.font(1, "inherit"), SCALES.height(1, "auto"), justify, direction, alignContent, alignItems, layout3.xs.grow, layout3.xs.width, layout3.xs.basis, layout3.xs.display, theme.breakpoints.sm.min, layout3.sm.grow, layout3.sm.width, layout3.sm.basis, layout3.sm.display, theme.breakpoints.md.min, layout3.md.grow, layout3.md.width, layout3.md.basis, layout3.md.display, theme.breakpoints.lg.min, layout3.lg.grow, layout3.lg.width, layout3.lg.basis, layout3.lg.display, theme.breakpoints.xl.min, layout3.xl.grow, layout3.xl.width, layout3.xl.basis, layout3.xl.display]
    }, ".item.__jsx-style-dynamic-selector{font-size:".concat(SCALES.font(1, "inherit"), ";height:").concat(SCALES.height(1, "auto"), ";}.justify.__jsx-style-dynamic-selector{-webkit-box-pack:").concat(justify, ";-webkit-justify-content:").concat(justify, ";-ms-flex-pack:").concat(justify, ";justify-content:").concat(justify, ";}.direction.__jsx-style-dynamic-selector{-webkit-flex-direction:").concat(direction, ";-ms-flex-direction:").concat(direction, ";flex-direction:").concat(direction, ";}.alignContent.__jsx-style-dynamic-selector{-webkit-align-content:").concat(alignContent, ";-ms-flex-line-pack:").concat(alignContent, ";align-content:").concat(alignContent, ";}.alignItems.__jsx-style-dynamic-selector{-webkit-align-items:").concat(alignItems, ";-webkit-box-align:").concat(alignItems, ";-ms-flex-align:").concat(alignItems, ";align-items:").concat(alignItems, ";}.xs.__jsx-style-dynamic-selector{-webkit-box-flex:").concat(layout3.xs.grow, ";-webkit-flex-grow:").concat(layout3.xs.grow, ";-ms-flex-positive:").concat(layout3.xs.grow, ";flex-grow:").concat(layout3.xs.grow, ";max-width:").concat(layout3.xs.width, ";-webkit-flex-basis:").concat(layout3.xs.basis, ";-ms-flex-preferred-size:").concat(layout3.xs.basis, ";flex-basis:").concat(layout3.xs.basis, ";").concat(layout3.xs.display, ";}@media only screen and (min-width:").concat(theme.breakpoints.sm.min, "){.sm.__jsx-style-dynamic-selector{-webkit-box-flex:").concat(layout3.sm.grow, ";-webkit-flex-grow:").concat(layout3.sm.grow, ";-ms-flex-positive:").concat(layout3.sm.grow, ";flex-grow:").concat(layout3.sm.grow, ";max-width:").concat(layout3.sm.width, ";-webkit-flex-basis:").concat(layout3.sm.basis, ";-ms-flex-preferred-size:").concat(layout3.sm.basis, ";flex-basis:").concat(layout3.sm.basis, ";").concat(layout3.sm.display, ";}}@media only screen and (min-width:").concat(theme.breakpoints.md.min, "){.md.__jsx-style-dynamic-selector{-webkit-box-flex:").concat(layout3.md.grow, ";-webkit-flex-grow:").concat(layout3.md.grow, ";-ms-flex-positive:").concat(layout3.md.grow, ";flex-grow:").concat(layout3.md.grow, ";max-width:").concat(layout3.md.width, ";-webkit-flex-basis:").concat(layout3.md.basis, ";-ms-flex-preferred-size:").concat(layout3.md.basis, ";flex-basis:").concat(layout3.md.basis, ";").concat(layout3.md.display, ";}}@media only screen and (min-width:").concat(theme.breakpoints.lg.min, "){.lg.__jsx-style-dynamic-selector{-webkit-box-flex:").concat(layout3.lg.grow, ";-webkit-flex-grow:").concat(layout3.lg.grow, ";-ms-flex-positive:").concat(layout3.lg.grow, ";flex-grow:").concat(layout3.lg.grow, ";max-width:").concat(layout3.lg.width, ";-webkit-flex-basis:").concat(layout3.lg.basis, ";-ms-flex-preferred-size:").concat(layout3.lg.basis, ";flex-basis:").concat(layout3.lg.basis, ";").concat(layout3.lg.display, ";}}@media only screen and (min-width:").concat(theme.breakpoints.xl.min, "){.xl.__jsx-style-dynamic-selector{-webkit-box-flex:").concat(layout3.xl.grow, ";-webkit-flex-grow:").concat(layout3.xl.grow, ";-ms-flex-positive:").concat(layout3.xl.grow, ";flex-grow:").concat(layout3.xl.grow, ";max-width:").concat(layout3.xl.width, ";-webkit-flex-basis:").concat(layout3.xl.basis, ";-ms-flex-preferred-size:").concat(layout3.xl.basis, ";flex-basis:").concat(layout3.xl.basis, ";").concat(layout3.xl.display, ";}}")));
  };
  GridBasicItem.defaultProps = defaultProps8;
  GridBasicItem.displayName = "GeistGridBasicItem";
  var basic_item_default = GridBasicItem;

  // node_modules/@geist-ui/core/esm/grid/grid.js
  var _excluded11 = ["children", "className"];
  var defaultProps9 = {
    className: ""
  };
  var GridComponent = function GridComponent2(_ref) {
    var children = _ref.children, className = _ref.className, props = _objectWithoutProperties(_ref, _excluded11);
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var _styles$className = {
      styles: /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
        id: "1271839607",
        dynamic: [SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0, "var(--grid-gap-unit)"), SCALES.pr(0, "var(--grid-gap-unit)"), SCALES.pb(0, "var(--grid-gap-unit)"), SCALES.pl(0, "var(--grid-gap-unit)")]
      }, "div.__jsx-style-dynamic-selector{margin:".concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";box-sizing:border-box;padding:").concat(SCALES.pt(0, "var(--grid-gap-unit)"), " ").concat(SCALES.pr(0, "var(--grid-gap-unit)"), " ").concat(SCALES.pb(0, "var(--grid-gap-unit)"), " ").concat(SCALES.pl(0, "var(--grid-gap-unit)"), ";}")),
      className: styled_jsx_es_default.dynamic([["1271839607", [SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0, "var(--grid-gap-unit)"), SCALES.pr(0, "var(--grid-gap-unit)"), SCALES.pb(0, "var(--grid-gap-unit)"), SCALES.pl(0, "var(--grid-gap-unit)")]]])
    }, resolveClassName = _styles$className.className, styles = _styles$className.styles;
    var classes = use_classes_default2(resolveClassName, className);
    return /* @__PURE__ */ bn.createElement(basic_item_default, _extends({
      className: classes
    }, props), children, styles);
  };
  GridComponent.defaultProps = defaultProps9;
  GridComponent.displayName = "GeistGrid";
  var Grid = with_scale_default(GridComponent);
  var grid_default = Grid;

  // node_modules/@geist-ui/core/esm/grid/grid-container.js
  init_react();
  var _excluded12 = ["gap", "wrap", "children", "className"];
  var defaultProps10 = {
    gap: 0,
    wrap: "wrap",
    className: ""
  };
  var GridContainerComponent = function GridContainerComponent2(_ref) {
    var gap = _ref.gap, wrap = _ref.wrap, children = _ref.children, className = _ref.className, props = _objectWithoutProperties(_ref, _excluded12);
    var _useScale = use_scale_default(), unit = _useScale.unit, SCALES = _useScale.SCALES;
    var gapUnit = F(function() {
      return "calc(".concat(gap, " * ").concat(unit, " * 1/3)");
    }, [gap, unit]);
    var _styles$className = {
      styles: /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
        id: "3631618093",
        dynamic: [gapUnit, wrap, SCALES.width(1, "var(--grid-container-width)"), SCALES.mt(0, "var(--grid-container-margin)"), SCALES.mr(0, "var(--grid-container-margin)"), SCALES.mb(0, "var(--grid-container-margin)"), SCALES.ml(0, "var(--grid-container-margin)")]
      }, "div.__jsx-style-dynamic-selector{--grid-gap-unit:".concat(gapUnit, ";--grid-container-margin:calc(-1 * var(--grid-gap-unit));--grid-container-width:calc(100% + var(--grid-gap-unit) * 2);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-wrap:").concat(wrap, ";-ms-flex-wrap:").concat(wrap, ";flex-wrap:").concat(wrap, ";box-sizing:border-box;width:").concat(SCALES.width(1, "var(--grid-container-width)"), ";margin:").concat(SCALES.mt(0, "var(--grid-container-margin)"), " ").concat(SCALES.mr(0, "var(--grid-container-margin)"), " ").concat(SCALES.mb(0, "var(--grid-container-margin)"), " ").concat(SCALES.ml(0, "var(--grid-container-margin)"), ";}")),
      className: styled_jsx_es_default.dynamic([["3631618093", [gapUnit, wrap, SCALES.width(1, "var(--grid-container-width)"), SCALES.mt(0, "var(--grid-container-margin)"), SCALES.mr(0, "var(--grid-container-margin)"), SCALES.mb(0, "var(--grid-container-margin)"), SCALES.ml(0, "var(--grid-container-margin)")]]])
    }, resolveClassName = _styles$className.className, styles = _styles$className.styles;
    var classes = use_classes_default2(resolveClassName, className);
    return /* @__PURE__ */ bn.createElement(basic_item_default, _extends({
      className: classes
    }, props), children, styles);
  };
  GridContainerComponent.defaultProps = defaultProps10;
  GridContainerComponent.displayName = "GeistGridContainer";
  var GridContainer = with_scale_default(GridContainerComponent);
  var grid_container_default = GridContainer;

  // node_modules/@geist-ui/core/esm/grid/index.js
  grid_default.Container = grid_container_default;
  var grid_default2 = grid_default;

  // node_modules/@geist-ui/core/esm/radio/radio.js
  init_react();

  // node_modules/@geist-ui/core/esm/radio/radio-context.js
  init_react();
  var defaultContext3 = {
    disabledAll: false,
    inGroup: false
  };
  var RadioContext = /* @__PURE__ */ bn.createContext(defaultContext3);
  var useRadioContext = function useRadioContext2() {
    return bn.useContext(RadioContext);
  };

  // node_modules/@geist-ui/core/esm/radio/radio-description.js
  init_react();
  var _excluded13 = ["className", "children"];
  var defaultProps11 = {
    className: ""
  };
  var RadioDescriptionComponent = function RadioDescriptionComponent2(_ref) {
    var className = _ref.className, children = _ref.children, props = _objectWithoutProperties(_ref, _excluded13);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    return /* @__PURE__ */ bn.createElement("span", _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["2489497926", [theme.palette.accents_3, SCALES.font(0.85, "calc(var(--radio-size) * 0.85)"), SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0, "calc(var(--radio-size) + var(--radio-size) * 0.375)")]]]) + " " + (props && props.className != null && props.className || className || "")
    }), children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "2489497926",
      dynamic: [theme.palette.accents_3, SCALES.font(0.85, "calc(var(--radio-size) * 0.85)"), SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0, "calc(var(--radio-size) + var(--radio-size) * 0.375)")]
    }, "span.__jsx-style-dynamic-selector{color:".concat(theme.palette.accents_3, ";font-size:").concat(SCALES.font(0.85, "calc(var(--radio-size) * 0.85)"), ";width:").concat(SCALES.width(1, "auto"), ";height:").concat(SCALES.height(1, "auto"), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0, "calc(var(--radio-size) + var(--radio-size) * 0.375)"), ";}")));
  };
  RadioDescriptionComponent.defaultProps = defaultProps11;
  RadioDescriptionComponent.displayName = "GeistRadioDescription";
  var RadioDescription = with_scale_default(RadioDescriptionComponent);
  var radio_description_default = RadioDescription;

  // node_modules/@geist-ui/core/esm/radio/styles.js
  var getColors5 = function getColors6(palette3, status) {
    var colors = {
      "default": {
        label: palette3.foreground,
        border: palette3.border,
        bg: palette3.foreground
      },
      secondary: {
        label: palette3.foreground,
        border: palette3.border,
        bg: palette3.foreground
      },
      success: {
        label: palette3.success,
        border: palette3.success,
        bg: palette3.success
      },
      warning: {
        label: palette3.warning,
        border: palette3.warning,
        bg: palette3.warning
      },
      error: {
        label: palette3.error,
        border: palette3.error,
        bg: palette3.error
      }
    };
    if (!status)
      return colors["default"];
    return colors[status];
  };

  // node_modules/@geist-ui/core/esm/radio/radio.js
  var _excluded14 = ["className", "checked", "onChange", "disabled", "type", "value", "children"];
  var defaultProps12 = {
    type: "default",
    disabled: false,
    className: ""
  };
  var RadioComponent = function RadioComponent2(_ref) {
    var className = _ref.className, checked = _ref.checked, onChange = _ref.onChange, disabled = _ref.disabled, type = _ref.type, radioValue = _ref.value, children = _ref.children, props = _objectWithoutProperties(_ref, _excluded14);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var _useState = p2(!!checked), _useState2 = _slicedToArray(_useState, 2), selfChecked = _useState2[0], setSelfChecked = _useState2[1];
    var _useRadioContext = useRadioContext(), groupValue = _useRadioContext.value, disabledAll = _useRadioContext.disabledAll, inGroup = _useRadioContext.inGroup, updateState = _useRadioContext.updateState;
    var _pickChild = pickChild(children, radio_description_default), _pickChild2 = _slicedToArray(_pickChild, 2), withoutDescChildren = _pickChild2[0], DescChildren = _pickChild2[1];
    if (inGroup) {
      if (checked !== void 0) {
        use_warning_default('Remove props "checked" if in the Radio.Group.', "Radio");
      }
      if (radioValue === void 0) {
        use_warning_default('Props "value" must be deinfed if in the Radio.Group.', "Radio");
      }
      h2(function() {
        setSelfChecked(groupValue === radioValue);
      }, [groupValue, radioValue]);
    }
    var _useMemo = F(function() {
      return getColors5(theme.palette, type);
    }, [theme.palette, type]), label = _useMemo.label, border = _useMemo.border, bg = _useMemo.bg;
    var isDisabled = F(function() {
      return disabled || disabledAll;
    }, [disabled, disabledAll]);
    var changeHandler = function changeHandler2(event) {
      if (isDisabled)
        return;
      var selfEvent = {
        target: {
          checked: !selfChecked
        },
        stopPropagation: event.stopPropagation,
        preventDefault: event.preventDefault,
        nativeEvent: event
      };
      setSelfChecked(!selfChecked);
      if (inGroup) {
        updateState && updateState(radioValue);
      }
      onChange && onChange(selfEvent);
    };
    h2(function() {
      if (checked === void 0)
        return;
      setSelfChecked(Boolean(checked));
    }, [checked]);
    return /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["2664604043", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), isDisabled ? theme.palette.accents_4 : label, isDisabled ? "not-allowed" : "pointer", border, isDisabled ? theme.palette.accents_4 : bg]]]) + " " + (use_classes_default2("radio", className) || "")
    }, /* @__PURE__ */ bn.createElement("label", {
      className: styled_jsx_es_default.dynamic([["2664604043", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), isDisabled ? theme.palette.accents_4 : label, isDisabled ? "not-allowed" : "pointer", border, isDisabled ? theme.palette.accents_4 : bg]]])
    }, /* @__PURE__ */ bn.createElement("input", _extends({
      type: "radio",
      value: radioValue,
      checked: selfChecked,
      onChange: changeHandler
    }, props, {
      className: styled_jsx_es_default.dynamic([["2664604043", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), isDisabled ? theme.palette.accents_4 : label, isDisabled ? "not-allowed" : "pointer", border, isDisabled ? theme.palette.accents_4 : bg]]]) + " " + (props && props.className != null && props.className || "")
    })), /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["2664604043", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), isDisabled ? theme.palette.accents_4 : label, isDisabled ? "not-allowed" : "pointer", border, isDisabled ? theme.palette.accents_4 : bg]]]) + " name"
    }, /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["2664604043", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), isDisabled ? theme.palette.accents_4 : label, isDisabled ? "not-allowed" : "pointer", border, isDisabled ? theme.palette.accents_4 : bg]]]) + " " + (use_classes_default2("point", {
        active: selfChecked
      }) || "")
    }), withoutDescChildren), DescChildren && DescChildren), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "2664604043",
      dynamic: [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), isDisabled ? theme.palette.accents_4 : label, isDisabled ? "not-allowed" : "pointer", border, isDisabled ? theme.palette.accents_4 : bg]
    }, "input.__jsx-style-dynamic-selector{opacity:0;visibility:hidden;overflow:hidden;width:1px;height:1px;top:-1000px;right:-1000px;position:fixed;font-size:0;}.radio.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;position:relative;--radio-size:".concat(SCALES.font(1), ";width:").concat(SCALES.width(1, "initial"), ";height:").concat(SCALES.height(1, "auto"), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}label.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:start;-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start;color:").concat(isDisabled ? theme.palette.accents_4 : label, ";cursor:").concat(isDisabled ? "not-allowed" : "pointer", ";}.name.__jsx-style-dynamic-selector{font-size:var(--radio-size);font-weight:bold;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}.point.__jsx-style-dynamic-selector{height:var(--radio-size);width:var(--radio-size);border-radius:50%;border:1px solid ").concat(border, ";-webkit-transition:all 0.2s ease 0s;transition:all 0.2s ease 0s;position:relative;display:inline-block;-webkit-transform:scale(0.875);-ms-transform:scale(0.875);transform:scale(0.875);margin-right:calc(var(--radio-size) * 0.375);}.point.__jsx-style-dynamic-selector:before{content:'';position:absolute;left:-1px;top:-1px;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);height:var(--radio-size);width:var(--radio-size);border-radius:50%;background-color:").concat(isDisabled ? theme.palette.accents_4 : bg, ";}.active.__jsx-style-dynamic-selector:before{-webkit-transform:scale(0.875);-ms-transform:scale(0.875);transform:scale(0.875);-webkit-transition:all 0.2s ease 0s;transition:all 0.2s ease 0s;}")));
  };
  RadioComponent.defaultProps = defaultProps12;
  RadioComponent.displayName = "GeistRadio";
  var Radio = with_scale_default(RadioComponent);
  var radio_default = Radio;

  // node_modules/@geist-ui/core/esm/radio/radio-group.js
  init_react();
  var _excluded15 = ["disabled", "onChange", "value", "children", "className", "initialValue", "useRow"];
  var defaultProps13 = {
    disabled: false,
    className: "",
    useRow: false
  };
  var RadioGroupComponent = function RadioGroupComponent2(_ref) {
    var disabled = _ref.disabled, onChange = _ref.onChange, value = _ref.value, children = _ref.children, className = _ref.className, initialValue = _ref.initialValue, useRow = _ref.useRow, props = _objectWithoutProperties(_ref, _excluded15);
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var _useState = p2(initialValue), _useState2 = _slicedToArray(_useState, 2), selfVal = _useState2[0], setSelfVal = _useState2[1];
    var updateState = function updateState2(nextValue) {
      setSelfVal(nextValue);
      onChange && onChange(nextValue);
    };
    var providerValue = F(function() {
      return {
        updateState,
        disabledAll: disabled,
        inGroup: true,
        value: selfVal
      };
    }, [disabled, selfVal]);
    h2(function() {
      if (value === void 0)
        return;
      setSelfVal(value);
    }, [value]);
    return /* @__PURE__ */ bn.createElement(RadioContext.Provider, {
      value: providerValue
    }, /* @__PURE__ */ bn.createElement("div", _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["1223822443", [useRow ? "col" : "column", SCALES.font(1), SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), useRow ? 0 : "var(--radio-group-gap)", useRow ? "var(--radio-group-gap)" : 0, SCALES.font(1)]]]) + " " + (props && props.className != null && props.className || use_classes_default2("radio-group", className) || "")
    }), children), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1223822443",
      dynamic: [useRow ? "col" : "column", SCALES.font(1), SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), useRow ? 0 : "var(--radio-group-gap)", useRow ? "var(--radio-group-gap)" : 0, SCALES.font(1)]
    }, ".radio-group.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:".concat(useRow ? "col" : "column", ";-ms-flex-direction:").concat(useRow ? "col" : "column", ";flex-direction:").concat(useRow ? "col" : "column", ";--radio-group-gap:").concat(SCALES.font(1), ";width:").concat(SCALES.width(1, "auto"), ";height:").concat(SCALES.height(1, "auto"), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.radio-group.__jsx-style-dynamic-selector .radio{margin-top:").concat(useRow ? 0 : "var(--radio-group-gap)", ";margin-left:").concat(useRow ? "var(--radio-group-gap)" : 0, ";--radio-size:").concat(SCALES.font(1), ";}.radio-group.__jsx-style-dynamic-selector .radio:first-of-type{margin:0;}")));
  };
  RadioGroupComponent.defaultProps = defaultProps13;
  RadioGroupComponent.displayName = "GeistRadioGroup";
  var RadioGroup = with_scale_default(RadioGroupComponent);
  var radio_group_default = RadioGroup;

  // node_modules/@geist-ui/core/esm/radio/index.js
  radio_default.Group = radio_group_default;
  radio_default.Description = radio_description_default;
  radio_default.Desc = radio_description_default;
  var radio_default2 = radio_default;

  // node_modules/@geist-ui/core/esm/select/select.js
  init_react();

  // node_modules/@geist-ui/core/esm/select/select-icon.js
  init_react();
  var SelectIconComponent = function SelectIconComponent2() {
    return /* @__PURE__ */ bn.createElement("svg", {
      viewBox: "0 0 24 24",
      strokeWidth: "1",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none",
      shapeRendering: "geometricPrecision",
      className: "jsx-2742933678"
    }, /* @__PURE__ */ bn.createElement("path", {
      d: "M6 9l6 6 6-6",
      className: "jsx-2742933678"
    }), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "2742933678"
    }, "svg.jsx-2742933678{color:inherit;stroke:currentColor;-webkit-transition:all 200ms ease;transition:all 200ms ease;width:1.214em;height:1.214em;}"));
  };
  SelectIconComponent.displayName = "GeistSelectIcon";
  var SelectIcon = /* @__PURE__ */ bn.memo(SelectIconComponent);
  var select_icon_default = SelectIcon;

  // node_modules/@geist-ui/core/esm/select/select-dropdown.js
  init_react();

  // node_modules/@geist-ui/core/esm/select/select-context.js
  init_react();
  var defaultContext4 = {
    visible: false,
    disableAll: false
  };
  var SelectContext = /* @__PURE__ */ bn.createContext(defaultContext4);
  var useSelectContext = function useSelectContext2() {
    return bn.useContext(SelectContext);
  };

  // node_modules/@geist-ui/core/esm/select/select-dropdown.js
  var defaultProps14 = {
    className: "",
    dropdownStyle: {}
  };
  var SelectDropdown = /* @__PURE__ */ bn.forwardRef(function(_ref, dropdownRef) {
    var visible = _ref.visible, children = _ref.children, className = _ref.className, dropdownStyle = _ref.dropdownStyle, disableMatchWidth = _ref.disableMatchWidth, getPopupContainer = _ref.getPopupContainer;
    var theme = use_theme_default();
    var internalDropdownRef = _2(null);
    var _useSelectContext = useSelectContext(), ref = _useSelectContext.ref;
    var classes = use_classes_default2("select-dropdown", className);
    A2(dropdownRef, function() {
      return internalDropdownRef.current;
    });
    return /* @__PURE__ */ bn.createElement(dropdown_default, {
      parent: ref,
      visible,
      disableMatchWidth,
      getPopupContainer
    }, /* @__PURE__ */ bn.createElement("div", {
      ref: internalDropdownRef,
      style: dropdownStyle,
      className: styled_jsx_es_default.dynamic([["2782510679", [theme.layout.radius, theme.expressiveness.shadowLarge, theme.palette.background]]]) + " " + (classes || "")
    }, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "2782510679",
      dynamic: [theme.layout.radius, theme.expressiveness.shadowLarge, theme.palette.background]
    }, ".select-dropdown.__jsx-style-dynamic-selector{border-radius:".concat(theme.layout.radius, ";box-shadow:").concat(theme.expressiveness.shadowLarge, ";background-color:").concat(theme.palette.background, ";max-height:17em;overflow-y:auto;overflow-anchor:none;padding:0.38em 0;-webkit-scroll-behavior:smooth;-moz-scroll-behavior:smooth;-ms-scroll-behavior:smooth;scroll-behavior:smooth;}"))));
  });
  SelectDropdown.defaultProps = defaultProps14;
  SelectDropdown.displayName = "GeistSelectDropdown";
  var select_dropdown_default = SelectDropdown;

  // node_modules/@geist-ui/core/esm/select/select-multiple-value.js
  init_react();

  // node_modules/@geist-ui/core/esm/select/select-icon-clear.js
  init_react();
  var SelectIconClear = function SelectIconClear2(_ref) {
    var onClick = _ref.onClick;
    var theme = use_theme_default();
    var clickHandler = function clickHandler2(event) {
      event.preventDefault();
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      onClick && onClick(event);
    };
    return /* @__PURE__ */ bn.createElement("div", {
      onClick: clickHandler,
      className: styled_jsx_es_default.dynamic([["1984024521", [theme.palette.accents_3, theme.palette.foreground]]]) + " clear-icon"
    }, /* @__PURE__ */ bn.createElement("svg", {
      viewBox: "0 0 24 24",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      fill: "none",
      shapeRendering: "geometricPrecision",
      className: styled_jsx_es_default.dynamic([["1984024521", [theme.palette.accents_3, theme.palette.foreground]]])
    }, /* @__PURE__ */ bn.createElement("path", {
      d: "M18 6L6 18",
      className: styled_jsx_es_default.dynamic([["1984024521", [theme.palette.accents_3, theme.palette.foreground]]])
    }), /* @__PURE__ */ bn.createElement("path", {
      d: "M6 6l12 12",
      className: styled_jsx_es_default.dynamic([["1984024521", [theme.palette.accents_3, theme.palette.foreground]]])
    })), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1984024521",
      dynamic: [theme.palette.accents_3, theme.palette.foreground]
    }, ".clear-icon.__jsx-style-dynamic-selector{padding:0 0 0 0.5em;margin:0;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:100%;cursor:pointer;box-sizing:border-box;-webkit-transition:color 150ms ease 0s;transition:color 150ms ease 0s;color:".concat(theme.palette.accents_3, ";visibility:visible;opacity:1;}.clear-icon.__jsx-style-dynamic-selector:hover{color:").concat(theme.palette.foreground, ";}svg.__jsx-style-dynamic-selector{color:currentColor;width:1em;height:1em;}")));
  };
  var MemoSelectIconClear = /* @__PURE__ */ bn.memo(SelectIconClear);
  var select_icon_clear_default = MemoSelectIconClear;

  // node_modules/@geist-ui/core/esm/select/select-multiple-value.js
  var SelectMultipleValue = function SelectMultipleValue2(_ref) {
    var disabled = _ref.disabled, onClear = _ref.onClear, children = _ref.children;
    var theme = use_theme_default();
    return /* @__PURE__ */ bn.createElement(grid_default2, null, /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["3357578496", [theme.layout.radius, theme.palette.accents_2, disabled ? theme.palette.accents_4 : theme.palette.accents_6]]]) + " item"
    }, children, !!onClear && /* @__PURE__ */ bn.createElement(select_icon_clear_default, {
      onClick: onClear
    })), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3357578496",
      dynamic: [theme.layout.radius, theme.palette.accents_2, disabled ? theme.palette.accents_4 : theme.palette.accents_6]
    }, ".item.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;justify-items:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;line-height:1;padding:0 0.5em;font-size:var(--select-font-size);height:calc(var(--select-font-size) * 2);border-radius:".concat(theme.layout.radius, ";background-color:").concat(theme.palette.accents_2, ";color:").concat(disabled ? theme.palette.accents_4 : theme.palette.accents_6, ";}.item.__jsx-style-dynamic-selector>div:not(.clear-icon),.item.__jsx-style-dynamic-selector>div:not(.clear-icon):hover{border-radius:0;background-color:transparent;padding:0;margin:0;color:inherit;}")));
  };
  SelectMultipleValue.displayName = "GeistSelectMultipleValue";
  var select_multiple_value_default = SelectMultipleValue;

  // node_modules/@geist-ui/core/esm/select/styles.js
  var getColors7 = function getColors8(palette3, status) {
    var colors = {
      "default": {
        border: palette3.border,
        borderActive: palette3.foreground,
        iconBorder: palette3.accents_5,
        placeholderColor: palette3.accents_3
      },
      secondary: {
        border: palette3.border,
        borderActive: palette3.foreground,
        iconBorder: palette3.accents_5,
        placeholderColor: palette3.accents_3
      },
      success: {
        border: palette3.successLight,
        borderActive: palette3.successDark,
        iconBorder: palette3.success,
        placeholderColor: palette3.accents_3
      },
      warning: {
        border: palette3.warningLight,
        borderActive: palette3.warningDark,
        iconBorder: palette3.warning,
        placeholderColor: palette3.accents_3
      },
      error: {
        border: palette3.errorLight,
        borderActive: palette3.errorDark,
        iconBorder: palette3.error,
        placeholderColor: palette3.error
      }
    };
    if (!status)
      return colors["default"];
    return colors[status];
  };

  // node_modules/@geist-ui/core/esm/select/select-input.js
  init_react();
  var SelectInput = /* @__PURE__ */ bn.forwardRef(function(_ref, inputRef) {
    var visible = _ref.visible, onBlur = _ref.onBlur, onFocus = _ref.onFocus;
    var ref = _2(null);
    A2(inputRef, function() {
      return ref.current;
    });
    h2(function() {
      if (visible) {
        var _ref$current;
        (_ref$current = ref.current) === null || _ref$current === void 0 ? void 0 : _ref$current.focus();
      }
    }, [visible]);
    return /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement("input", {
      ref,
      type: "search",
      role: "combobox",
      "aria-haspopup": "listbox",
      readOnly: true,
      unselectable: "on",
      "aria-expanded": visible,
      onBlur,
      onFocus,
      className: "jsx-2813108835"
    }), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "2813108835"
    }, "input.jsx-2813108835{position:fixed;top:-10000px;left:-10000px;opacity:0;z-index:-1;width:0;height:0;padding:0;font-size:0;border:none;}"));
  });
  SelectInput.displayName = "GeistSelectInput";
  var select_input_default = SelectInput;

  // node_modules/@geist-ui/core/esm/select/select.js
  var _excluded16 = ["children", "type", "disabled", "initialValue", "value", "icon", "onChange", "pure", "multiple", "clearable", "placeholder", "className", "dropdownClassName", "dropdownStyle", "disableMatchWidth", "getPopupContainer", "onDropdownVisibleChange"];
  var defaultProps15 = {
    disabled: false,
    type: "default",
    icon: select_icon_default,
    pure: false,
    multiple: false,
    clearable: true,
    className: "",
    disableMatchWidth: false,
    onDropdownVisibleChange: function onDropdownVisibleChange() {
    }
  };
  var SelectComponent = /* @__PURE__ */ bn.forwardRef(function(_ref, selectRef) {
    var children = _ref.children, type = _ref.type, disabled = _ref.disabled, init = _ref.initialValue, customValue = _ref.value, Icon = _ref.icon, onChange = _ref.onChange, pure = _ref.pure, multiple = _ref.multiple, clearable = _ref.clearable, placeholder = _ref.placeholder, className = _ref.className, dropdownClassName = _ref.dropdownClassName, dropdownStyle = _ref.dropdownStyle, disableMatchWidth = _ref.disableMatchWidth, getPopupContainer = _ref.getPopupContainer, onDropdownVisibleChange2 = _ref.onDropdownVisibleChange, props = _objectWithoutProperties(_ref, _excluded16);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var ref = _2(null);
    var inputRef = _2(null);
    var dropdownRef = _2(null);
    var _useState = p2(false), _useState2 = _slicedToArray(_useState, 2), visible = _useState2[0], setVisible = _useState2[1];
    var _useState3 = p2(false), _useState4 = _slicedToArray(_useState3, 2), selectFocus = _useState4[0], setSelectFocus = _useState4[1];
    var _useCurrentState = use_current_state_default3(function() {
      if (!multiple)
        return init;
      if (Array.isArray(init))
        return init;
      return typeof init === "undefined" ? [] : [init];
    }), _useCurrentState2 = _slicedToArray(_useCurrentState, 3), value = _useCurrentState2[0], setValue = _useCurrentState2[1], valueRef = _useCurrentState2[2];
    var isEmpty = F(function() {
      if (!Array.isArray(value))
        return !value;
      return value.length === 0;
    }, [value]);
    var _useMemo = F(function() {
      return getColors7(theme.palette, type);
    }, [theme.palette, type]), border = _useMemo.border, borderActive = _useMemo.borderActive, iconBorder = _useMemo.iconBorder, placeholderColor = _useMemo.placeholderColor;
    var updateVisible = function updateVisible2(next) {
      onDropdownVisibleChange2(next);
      setVisible(next);
    };
    var updateValue = function updateValue2(next) {
      setValue(function(last) {
        if (!Array.isArray(last))
          return next;
        if (!last.includes(next))
          return [].concat(_toConsumableArray(last), [next]);
        return last.filter(function(item) {
          return item !== next;
        });
      });
      onChange && onChange(valueRef.current);
      if (!multiple) {
        updateVisible(false);
      }
    };
    var initialValue = F(function() {
      return {
        value,
        visible,
        updateValue,
        updateVisible,
        ref,
        disableAll: disabled
      };
    }, [visible, disabled, ref, value, multiple]);
    var clickHandler = function clickHandler2(event) {
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      event.preventDefault();
      if (disabled)
        return;
      updateVisible(!visible);
      event.preventDefault();
    };
    var mouseDownHandler = function mouseDownHandler2(event) {
      if (visible) {
        event.preventDefault();
      }
    };
    h2(function() {
      if (customValue === void 0)
        return;
      setValue(customValue);
    }, [customValue]);
    A2(selectRef, function() {
      return {
        focus: function focus() {
          var _inputRef$current;
          return (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 ? void 0 : _inputRef$current.focus();
        },
        blur: function blur() {
          var _inputRef$current2;
          return (_inputRef$current2 = inputRef.current) === null || _inputRef$current2 === void 0 ? void 0 : _inputRef$current2.blur();
        },
        scrollTo: function scrollTo(options) {
          var _dropdownRef$current;
          return (_dropdownRef$current = dropdownRef.current) === null || _dropdownRef$current === void 0 ? void 0 : _dropdownRef$current.scrollTo(options);
        }
      };
    }, [inputRef, dropdownRef]);
    var selectedChild = F(function() {
      var _pickChildByProps = pickChildByProps(children, "value", value), _pickChildByProps2 = _slicedToArray(_pickChildByProps, 2), optionChildren = _pickChildByProps2[1];
      return bn.Children.map(optionChildren, function(child) {
        if (!/* @__PURE__ */ bn.isValidElement(child))
          return null;
        var el = /* @__PURE__ */ bn.cloneElement(child, {
          preventAllEvents: true
        });
        if (!multiple)
          return el;
        return /* @__PURE__ */ bn.createElement(select_multiple_value_default, {
          disabled,
          onClear: clearable ? function() {
            return updateValue(child.props.value);
          } : null
        }, el);
      });
    }, [value, children, multiple]);
    var onInputBlur = function onInputBlur2() {
      updateVisible(false);
      setSelectFocus(false);
    };
    var classes = use_classes_default2("select", {
      active: selectFocus || visible,
      multiple
    }, className);
    return /* @__PURE__ */ bn.createElement(SelectContext.Provider, {
      value: initialValue
    }, /* @__PURE__ */ bn.createElement("div", _extends({
      ref,
      onClick: clickHandler,
      onMouseDown: mouseDownHandler
    }, props, {
      className: styled_jsx_es_default.dynamic([["3282295248", [disabled ? "not-allowed" : "pointer", border, theme.layout.radius, disabled ? theme.palette.accents_1 : theme.palette.background, SCALES.font(0.875), SCALES.height(2.25), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0.334), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0.334), SCALES.pr(0.334), SCALES.pb(0.334), SCALES.pl(0.667), disabled ? theme.palette.border : borderActive, disabled ? theme.palette.accents_5 : borderActive, disabled ? theme.palette.accents_4 : theme.palette.foreground, placeholderColor, theme.layout.gapQuarter, visible ? "180" : "0", iconBorder]]]) + " " + (props && props.className != null && props.className || classes || "")
    }), /* @__PURE__ */ bn.createElement(select_input_default, {
      ref: inputRef,
      visible,
      onBlur: onInputBlur,
      onFocus: function onFocus() {
        return setSelectFocus(true);
      }
    }), isEmpty && /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["3282295248", [disabled ? "not-allowed" : "pointer", border, theme.layout.radius, disabled ? theme.palette.accents_1 : theme.palette.background, SCALES.font(0.875), SCALES.height(2.25), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0.334), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0.334), SCALES.pr(0.334), SCALES.pb(0.334), SCALES.pl(0.667), disabled ? theme.palette.border : borderActive, disabled ? theme.palette.accents_5 : borderActive, disabled ? theme.palette.accents_4 : theme.palette.foreground, placeholderColor, theme.layout.gapQuarter, visible ? "180" : "0", iconBorder]]]) + " value placeholder"
    }, /* @__PURE__ */ bn.createElement(ellipsis_default, {
      height: "var(--select-height)"
    }, placeholder)), value && !multiple && /* @__PURE__ */ bn.createElement("span", {
      className: styled_jsx_es_default.dynamic([["3282295248", [disabled ? "not-allowed" : "pointer", border, theme.layout.radius, disabled ? theme.palette.accents_1 : theme.palette.background, SCALES.font(0.875), SCALES.height(2.25), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0.334), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0.334), SCALES.pr(0.334), SCALES.pb(0.334), SCALES.pl(0.667), disabled ? theme.palette.border : borderActive, disabled ? theme.palette.accents_5 : borderActive, disabled ? theme.palette.accents_4 : theme.palette.foreground, placeholderColor, theme.layout.gapQuarter, visible ? "180" : "0", iconBorder]]]) + " value"
    }, selectedChild), value && multiple && /* @__PURE__ */ bn.createElement(grid_default2.Container, {
      gap: 0.5
    }, selectedChild), /* @__PURE__ */ bn.createElement(select_dropdown_default, {
      ref: dropdownRef,
      visible,
      className: dropdownClassName,
      dropdownStyle,
      disableMatchWidth,
      getPopupContainer
    }, children), !pure && /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["3282295248", [disabled ? "not-allowed" : "pointer", border, theme.layout.radius, disabled ? theme.palette.accents_1 : theme.palette.background, SCALES.font(0.875), SCALES.height(2.25), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0.334), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0.334), SCALES.pr(0.334), SCALES.pb(0.334), SCALES.pl(0.667), disabled ? theme.palette.border : borderActive, disabled ? theme.palette.accents_5 : borderActive, disabled ? theme.palette.accents_4 : theme.palette.foreground, placeholderColor, theme.layout.gapQuarter, visible ? "180" : "0", iconBorder]]]) + " icon"
    }, /* @__PURE__ */ bn.createElement(Icon, {
      className: styled_jsx_es_default.dynamic([["3282295248", [disabled ? "not-allowed" : "pointer", border, theme.layout.radius, disabled ? theme.palette.accents_1 : theme.palette.background, SCALES.font(0.875), SCALES.height(2.25), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0.334), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0.334), SCALES.pr(0.334), SCALES.pb(0.334), SCALES.pl(0.667), disabled ? theme.palette.border : borderActive, disabled ? theme.palette.accents_5 : borderActive, disabled ? theme.palette.accents_4 : theme.palette.foreground, placeholderColor, theme.layout.gapQuarter, visible ? "180" : "0", iconBorder]]])
    })), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3282295248",
      dynamic: [disabled ? "not-allowed" : "pointer", border, theme.layout.radius, disabled ? theme.palette.accents_1 : theme.palette.background, SCALES.font(0.875), SCALES.height(2.25), SCALES.width(1, "initial"), SCALES.pt(0), SCALES.pr(0.334), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), SCALES.pt(0.334), SCALES.pr(0.334), SCALES.pb(0.334), SCALES.pl(0.667), disabled ? theme.palette.border : borderActive, disabled ? theme.palette.accents_5 : borderActive, disabled ? theme.palette.accents_4 : theme.palette.foreground, placeholderColor, theme.layout.gapQuarter, visible ? "180" : "0", iconBorder]
    }, ".select.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;white-space:nowrap;position:relative;cursor:".concat(disabled ? "not-allowed" : "pointer", ";max-width:90vw;overflow:hidden;-webkit-transition:border 150ms ease-in 0s,color 200ms ease-out 0s, box-shadow 200ms ease 0s;transition:border 150ms ease-in 0s,color 200ms ease-out 0s, box-shadow 200ms ease 0s;border:1px solid ").concat(border, ";border-radius:").concat(theme.layout.radius, ";background-color:").concat(disabled ? theme.palette.accents_1 : theme.palette.background, ";--select-font-size:").concat(SCALES.font(0.875), ";--select-height:").concat(SCALES.height(2.25), ";min-width:11.5em;width:").concat(SCALES.width(1, "initial"), ";height:var(--select-height);padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0.334), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0.667), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.multiple.__jsx-style-dynamic-selector{height:auto;min-height:var(--select-height);padding:").concat(SCALES.pt(0.334), " ").concat(SCALES.pr(0.334), " ").concat(SCALES.pb(0.334), " ").concat(SCALES.pl(0.667), ";}.select.active.__jsx-style-dynamic-selector,.select.__jsx-style-dynamic-selector:hover{border-color:").concat(disabled ? theme.palette.border : borderActive, ";}.select.active.icon.__jsx-style-dynamic-selector,.select.__jsx-style-dynamic-selector:hover .icon.__jsx-style-dynamic-selector{color:").concat(disabled ? theme.palette.accents_5 : borderActive, ";}.value.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-flex:1;-ms-flex:1;flex:1;height:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;line-height:1;padding:0;margin-right:1.25em;font-size:var(--select-font-size);color:").concat(disabled ? theme.palette.accents_4 : theme.palette.foreground, ";width:calc(100% - 1.25em);}.value.__jsx-style-dynamic-selector>div,.value.__jsx-style-dynamic-selector>div:hover{border-radius:0;background-color:transparent;padding:0;margin:0;color:inherit;}.placeholder.__jsx-style-dynamic-selector{color:").concat(placeholderColor, ";}.icon.__jsx-style-dynamic-selector{position:absolute;right:").concat(theme.layout.gapQuarter, ";font-size:var(--select-font-size);top:50%;bottom:0;-webkit-transform:translateY(-50%) rotate(").concat(visible ? "180" : "0", "deg);-ms-transform:translateY(-50%) rotate(").concat(visible ? "180" : "0", "deg);transform:translateY(-50%) rotate(").concat(visible ? "180" : "0", "deg);pointer-events:none;-webkit-transition:-webkit-transform 200ms ease;-webkit-transition:transform 200ms ease;transition:transform 200ms ease;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:").concat(iconBorder, ";}"))));
  });
  SelectComponent.defaultProps = defaultProps15;
  SelectComponent.displayName = "GeistSelect";
  var Select = with_scale_default(SelectComponent);
  var select_default = Select;

  // node_modules/@geist-ui/core/esm/select/select-option.js
  init_react();
  var _excluded17 = ["value", "className", "children", "disabled", "divider", "label", "preventAllEvents"];
  var defaultProps16 = {
    disabled: false,
    divider: false,
    label: false,
    className: "",
    preventAllEvents: false
  };
  var SelectOptionComponent = function SelectOptionComponent2(_ref) {
    var identValue = _ref.value, className = _ref.className, children = _ref.children, disabled = _ref.disabled, divider = _ref.divider, label = _ref.label, preventAllEvents = _ref.preventAllEvents, props = _objectWithoutProperties(_ref, _excluded17);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var _useSelectContext = useSelectContext(), updateValue = _useSelectContext.updateValue, value = _useSelectContext.value, disableAll = _useSelectContext.disableAll;
    var isDisabled = F(function() {
      return disabled || disableAll;
    }, [disabled, disableAll]);
    var isLabel = F(function() {
      return label || divider;
    }, [label, divider]);
    var classes = use_classes_default2("option", {
      divider,
      label
    }, className);
    if (!isLabel && identValue === void 0) {
      use_warning_default('The props "value" is required.', "Select Option");
    }
    var selected = F(function() {
      if (!value)
        return false;
      if (typeof value === "string") {
        return identValue === value;
      }
      return value.includes("".concat(identValue));
    }, [identValue, value]);
    var bgColor = F(function() {
      if (isDisabled)
        return theme.palette.accents_1;
      return selected ? theme.palette.accents_2 : theme.palette.background;
    }, [selected, isDisabled, theme.palette]);
    var hoverBgColor = F(function() {
      if (isDisabled || isLabel || selected)
        return bgColor;
      return theme.palette.accents_1;
    }, [selected, isDisabled, theme.palette, isLabel, bgColor]);
    var color = F(function() {
      if (isDisabled)
        return theme.palette.accents_4;
      return selected ? theme.palette.foreground : theme.palette.accents_5;
    }, [selected, isDisabled, theme.palette]);
    var clickHandler = function clickHandler2(event) {
      if (preventAllEvents)
        return;
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
      event.preventDefault();
      if (isDisabled || isLabel)
        return;
      updateValue && updateValue(identValue);
    };
    return /* @__PURE__ */ bn.createElement("div", _extends({
      onClick: clickHandler
    }, props, {
      className: styled_jsx_es_default.dynamic([["199367556", [bgColor, color, isDisabled ? "not-allowed" : "pointer", SCALES.font(0.75), SCALES.width(1, "100%"), SCALES.height(2.25), SCALES.pt(0), SCALES.pr(0.667), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hoverBgColor, theme.palette.accents_7, theme.palette.border, SCALES.width(1, "100%"), SCALES.height(1, 0), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0.5), SCALES.mr(0), SCALES.mb(0.5), SCALES.ml(0), theme.palette.accents_7, theme.palette.border, SCALES.font(0.875), SCALES.width(1, "100%")]]]) + " " + (props && props.className != null && props.className || classes || "")
    }), /* @__PURE__ */ bn.createElement(ellipsis_default, {
      height: SCALES.height(2.25)
    }, children), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "199367556",
      dynamic: [bgColor, color, isDisabled ? "not-allowed" : "pointer", SCALES.font(0.75), SCALES.width(1, "100%"), SCALES.height(2.25), SCALES.pt(0), SCALES.pr(0.667), SCALES.pb(0), SCALES.pl(0.667), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), hoverBgColor, theme.palette.accents_7, theme.palette.border, SCALES.width(1, "100%"), SCALES.height(1, 0), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0.5), SCALES.mr(0), SCALES.mb(0.5), SCALES.ml(0), theme.palette.accents_7, theme.palette.border, SCALES.font(0.875), SCALES.width(1, "100%")]
    }, ".option.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;max-width:100%;box-sizing:border-box;-webkit-box-pack:start;-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-weight:normal;background-color:".concat(bgColor, ";color:").concat(color, ";-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:0;cursor:").concat(isDisabled ? "not-allowed" : "pointer", ";-webkit-transition:background 0.2s ease 0s,border-color 0.2s ease 0s;transition:background 0.2s ease 0s,border-color 0.2s ease 0s;--select-font-size:").concat(SCALES.font(0.75), ";font-size:var(--select-font-size);width:").concat(SCALES.width(1, "100%"), ";height:").concat(SCALES.height(2.25), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0.667), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0.667), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.option.__jsx-style-dynamic-selector:hover{background-color:").concat(hoverBgColor, ";color:").concat(theme.palette.accents_7, ";}.divider.__jsx-style-dynamic-selector{line-height:0;overflow:hidden;border-top:1px solid ").concat(theme.palette.border, ";width:").concat(SCALES.width(1, "100%"), ";height:").concat(SCALES.height(1, 0), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0.5), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0.5), " ").concat(SCALES.ml(0), ";}.label.__jsx-style-dynamic-selector{color:").concat(theme.palette.accents_7, ";border-bottom:1px solid ").concat(theme.palette.border, ";text-transform:capitalize;cursor:default;font-size:").concat(SCALES.font(0.875), ";width:").concat(SCALES.width(1, "100%"), ";font-weight:500;}")));
  };
  SelectOptionComponent.defaultProps = defaultProps16;
  SelectOptionComponent.displayName = "GeistSelectOption";
  var SelectOption = with_scale_default(SelectOptionComponent);
  var select_option_default = SelectOption;

  // node_modules/@geist-ui/core/esm/select/index.js
  select_default.Option = select_option_default;
  var select_default2 = select_default;

  // node_modules/@geist-ui/core/esm/use-toasts/use-toast.js
  init_react();
  var defaultToast = {
    delay: 2e3,
    type: "default"
  };
  var useToasts = function useToasts2(layout3) {
    var _useGeistUIContext = useGeistUIContext(), updateToasts2 = _useGeistUIContext.updateToasts, toasts = _useGeistUIContext.toasts, updateToastLayout2 = _useGeistUIContext.updateToastLayout, updateLastToastId2 = _useGeistUIContext.updateLastToastId;
    h2(function() {
      if (!layout3)
        return;
      updateToastLayout2(function() {
        return layout3 ? _extends({}, defaultToastLayout, layout3) : defaultToastLayout;
      });
    }, []);
    var cancel = function cancel2(internalId) {
      updateToasts2(function(currentToasts) {
        return currentToasts.map(function(item) {
          if (item._internalIdent !== internalId)
            return item;
          return _extends({}, item, {
            visible: false
          });
        });
      });
      updateLastToastId2(function() {
        return internalId;
      });
    };
    var removeAll = function removeAll2() {
      updateToasts2(function(last) {
        return last.map(function(toast) {
          return _extends({}, toast, {
            visible: false
          });
        });
      });
    };
    var findToastOneByID = function findToastOneByID2(id) {
      return toasts.find(function(t3) {
        return t3.id === id;
      });
    };
    var removeToastOneByID = function removeToastOneByID2(id) {
      updateToasts2(function(last) {
        return last.map(function(toast) {
          if (toast.id !== id)
            return toast;
          return _extends({}, toast, {
            visible: false
          });
        });
      });
    };
    var setToast = function setToast2(toast) {
      var internalIdent = "toast-".concat(getId());
      var delay = toast.delay || defaultToast.delay;
      if (toast.id) {
        var hasIdent = toasts.find(function(t3) {
          return t3.id === toast.id;
        });
        if (hasIdent) {
          throw new Error('Toast: Already have the same key: "ident"');
        }
      }
      updateToasts2(function(last) {
        var newToast = {
          delay,
          text: toast.text,
          visible: true,
          type: toast.type || defaultToast.type,
          id: toast.id || internalIdent,
          actions: toast.actions || [],
          _internalIdent: internalIdent,
          _timeout: window.setTimeout(function() {
            cancel(internalIdent);
            if (newToast._timeout) {
              window.clearTimeout(newToast._timeout);
              newToast._timeout = null;
            }
          }, delay),
          cancel: function(_cancel) {
            function cancel2() {
              return _cancel.apply(this, arguments);
            }
            cancel2.toString = function() {
              return _cancel.toString();
            };
            return cancel2;
          }(function() {
            return cancel(internalIdent);
          })
        };
        return [].concat(_toConsumableArray(last), [newToast]);
      });
    };
    return {
      toasts,
      setToast,
      removeAll,
      findToastOneByID,
      removeToastOneByID
    };
  };
  var use_toast_default = useToasts;

  // node_modules/@geist-ui/core/esm/use-toasts/index.js
  var use_toasts_default = use_toast_default;

  // node_modules/@geist-ui/core/esm/spinner/spinner.js
  init_react();
  var _excluded18 = ["className"];
  var defaultProps17 = {
    className: ""
  };
  var getSpans = function getSpans2(theme) {
    return _toConsumableArray(new Array(12)).map(function(_4, index) {
      return /* @__PURE__ */ bn.createElement("span", {
        key: "spinner-".concat(index),
        className: styled_jsx_es_default.dynamic([["3296107463", [theme.palette.foreground, theme.layout.radius]]])
      }, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
        id: "3296107463",
        dynamic: [theme.palette.foreground, theme.layout.radius]
      }, "span.__jsx-style-dynamic-selector{background-color:".concat(theme.palette.foreground, ";position:absolute;top:-3.9%;width:24%;height:8%;left:-10%;border-radius:").concat(theme.layout.radius, ";-webkit-animation:spinner-__jsx-style-dynamic-selector 1.2s linear 0s infinite normal none running;animation:spinner-__jsx-style-dynamic-selector 1.2s linear 0s infinite normal none running;}span.__jsx-style-dynamic-selector:nth-child(1){-webkit-animation-delay:-1.2s;animation-delay:-1.2s;-webkit-transform:rotate(0deg) translate(146%);-ms-transform:rotate(0deg) translate(146%);transform:rotate(0deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(2){-webkit-animation-delay:-1.1s;animation-delay:-1.1s;-webkit-transform:rotate(30deg) translate(146%);-ms-transform:rotate(30deg) translate(146%);transform:rotate(30deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(3){-webkit-animation-delay:-1s;animation-delay:-1s;-webkit-transform:rotate(60deg) translate(146%);-ms-transform:rotate(60deg) translate(146%);transform:rotate(60deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(4){-webkit-animation-delay:-0.9s;animation-delay:-0.9s;-webkit-transform:rotate(90deg) translate(146%);-ms-transform:rotate(90deg) translate(146%);transform:rotate(90deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(5){-webkit-animation-delay:-0.8s;animation-delay:-0.8s;-webkit-transform:rotate(120deg) translate(146%);-ms-transform:rotate(120deg) translate(146%);transform:rotate(120deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(6){-webkit-animation-delay:-0.7s;animation-delay:-0.7s;-webkit-transform:rotate(150deg) translate(146%);-ms-transform:rotate(150deg) translate(146%);transform:rotate(150deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(7){-webkit-animation-delay:-0.6s;animation-delay:-0.6s;-webkit-transform:rotate(180deg) translate(146%);-ms-transform:rotate(180deg) translate(146%);transform:rotate(180deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(8){-webkit-animation-delay:-0.5s;animation-delay:-0.5s;-webkit-transform:rotate(210deg) translate(146%);-ms-transform:rotate(210deg) translate(146%);transform:rotate(210deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(9){-webkit-animation-delay:-0.4s;animation-delay:-0.4s;-webkit-transform:rotate(240deg) translate(146%);-ms-transform:rotate(240deg) translate(146%);transform:rotate(240deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(10){-webkit-animation-delay:-0.3s;animation-delay:-0.3s;-webkit-transform:rotate(270deg) translate(146%);-ms-transform:rotate(270deg) translate(146%);transform:rotate(270deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(11){-webkit-animation-delay:-0.2s;animation-delay:-0.2s;-webkit-transform:rotate(300deg) translate(146%);-ms-transform:rotate(300deg) translate(146%);transform:rotate(300deg) translate(146%);}span.__jsx-style-dynamic-selector:nth-child(12){-webkit-animation-delay:-0.1s;animation-delay:-0.1s;-webkit-transform:rotate(330deg) translate(146%);-ms-transform:rotate(330deg) translate(146%);transform:rotate(330deg) translate(146%);}@-webkit-keyframes spinner-__jsx-style-dynamic-selector{0%{opacity:1;}100%{opacity:0.15;}}@keyframes spinner-__jsx-style-dynamic-selector{0%{opacity:1;}100%{opacity:0.15;}}")));
    });
  };
  var SpinnerComponent = function SpinnerComponent2(_ref) {
    var className = _ref.className, props = _objectWithoutProperties(_ref, _excluded18);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var classes = use_classes_default2("spinner", className);
    return /* @__PURE__ */ bn.createElement("div", _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["1153799566", [SCALES.width(1.25), SCALES.height(1.25), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0)]]]) + " " + (props && props.className != null && props.className || classes || "")
    }), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["1153799566", [SCALES.width(1.25), SCALES.height(1.25), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0)]]]) + " container"
    }, getSpans(theme)), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1153799566",
      dynamic: [SCALES.width(1.25), SCALES.height(1.25), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0)]
    }, ".spinner.__jsx-style-dynamic-selector{display:block;box-sizing:border-box;width:".concat(SCALES.width(1.25), ";height:").concat(SCALES.height(1.25), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}.container.__jsx-style-dynamic-selector{width:100%;height:100%;position:relative;left:50%;top:50%;}")));
  };
  SpinnerComponent.defaultProps = defaultProps17;
  SpinnerComponent.displayName = "GeistSpinner";
  var Spinner = with_scale_default(SpinnerComponent);
  var spinner_default = Spinner;

  // node_modules/@geist-ui/core/esm/spinner/index.js
  var spinner_default2 = spinner_default;

  // node_modules/@geist-ui/core/esm/tabs/tabs.js
  init_react();

  // node_modules/@geist-ui/core/esm/tabs/tabs-context.js
  init_react();
  var defaultContext5 = {
    inGroup: false
  };
  var TabsContext = /* @__PURE__ */ bn.createContext(defaultContext5);
  var useTabsContext = function useTabsContext2() {
    return bn.useContext(TabsContext);
  };

  // node_modules/@geist-ui/core/esm/shared/highlight.js
  init_react();

  // node_modules/@geist-ui/core/esm/utils/use-previous.js
  init_react();
  var usePrevious = function usePrevious2(state) {
    var ref = _2(null);
    h2(function() {
      ref.current = state;
    });
    return ref ? ref.current : null;
  };
  var use_previous_default = usePrevious;

  // node_modules/@geist-ui/core/esm/shared/highlight.js
  var _excluded19 = ["rect", "visible", "hoverHeightRatio", "hoverWidthRatio", "activeOpacity", "className"];
  var Highlight = function Highlight2(_ref) {
    var rect = _ref.rect, visible = _ref.visible, _ref$hoverHeightRatio = _ref.hoverHeightRatio, hoverHeightRatio = _ref$hoverHeightRatio === void 0 ? 1 : _ref$hoverHeightRatio, _ref$hoverWidthRatio = _ref.hoverWidthRatio, hoverWidthRatio = _ref$hoverWidthRatio === void 0 ? 1 : _ref$hoverWidthRatio, _ref$activeOpacity = _ref.activeOpacity, activeOpacity = _ref$activeOpacity === void 0 ? 0.8 : _ref$activeOpacity, className = _ref.className, props = _objectWithoutProperties(_ref, _excluded19);
    var theme = use_theme_default();
    var ref = _2(null);
    var isFirstVisible = use_previous_default(isUnplacedRect(rect));
    var position = F(function() {
      var width = rect.width * hoverWidthRatio;
      var height = rect.height * hoverHeightRatio;
      return {
        width: "".concat(width, "px"),
        left: "".concat(rect.left + (rect.width - width) / 2, "px"),
        height: "".concat(height, "px"),
        top: "".concat(rect.elementTop + (rect.height - height) / 2, "px"),
        transition: isFirstVisible ? "opacity" : "opacity, width, left, top"
      };
    }, [rect, hoverWidthRatio, hoverHeightRatio]);
    return /* @__PURE__ */ bn.createElement("div", _extends({
      ref
    }, props, {
      className: styled_jsx_es_default.dynamic([["603024321", [theme.palette.accents_2, position.width, position.left, position.height, position.top, visible ? activeOpacity : 0, position.transition]]]) + " " + (props && props.className != null && props.className || use_classes_default2("highlight", className) || "")
    }), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "603024321",
      dynamic: [theme.palette.accents_2, position.width, position.left, position.height, position.top, visible ? activeOpacity : 0, position.transition]
    }, ".highlight.__jsx-style-dynamic-selector{background:".concat(theme.palette.accents_2, ";position:absolute;border-radius:5px;width:").concat(position.width, ";left:").concat(position.left, ";height:").concat(position.height, ";top:").concat(position.top, ";opacity:").concat(visible ? activeOpacity : 0, ";-webkit-transition:0.15s ease;transition:0.15s ease;-webkit-transition-property:").concat(position.transition, ";transition-property:").concat(position.transition, ";}")));
  };
  var highlight_default = Highlight;

  // node_modules/@geist-ui/core/esm/tabs/tabs.js
  var _excluded20 = ["initialValue", "value", "hideDivider", "hideBorder", "children", "onChange", "className", "leftSpace", "highlight", "hoverHeightRatio", "hoverWidthRatio", "activeClassName", "activeStyle", "align"];
  var defaultProps18 = {
    className: "",
    hideDivider: false,
    highlight: true,
    leftSpace: "12px",
    hoverHeightRatio: 0.7,
    hoverWidthRatio: 1.15,
    activeClassName: "",
    activeStyle: {},
    align: "left"
  };
  var TabsComponent = function TabsComponent2(_ref) {
    var userCustomInitialValue = _ref.initialValue, value = _ref.value, hideDivider = _ref.hideDivider, hideBorder = _ref.hideBorder, children = _ref.children, onChange = _ref.onChange, className = _ref.className, leftSpace = _ref.leftSpace, highlight = _ref.highlight, hoverHeightRatio = _ref.hoverHeightRatio, hoverWidthRatio = _ref.hoverWidthRatio, activeClassName = _ref.activeClassName, activeStyle = _ref.activeStyle, align = _ref.align, props = _objectWithoutProperties(_ref, _excluded20);
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var _useState = p2([]), _useState2 = _slicedToArray(_useState, 2), tabs = _useState2[0], setTabs = _useState2[1];
    var _useState3 = p2(userCustomInitialValue), _useState4 = _slicedToArray(_useState3, 2), selfValue = _useState4[0], setSelfValue = _useState4[1];
    var ref = _2(null);
    var _useState5 = p2(false), _useState6 = _slicedToArray(_useState5, 2), displayHighlight = _useState6[0], setDisplayHighlight = _useState6[1];
    var _useRect = useRect(), rect = _useRect.rect, setRect = _useRect.setRect;
    var register = function register2(next) {
      setTabs(function(last) {
        var hasItem = last.find(function(item) {
          return item.value === next.value;
        });
        if (!hasItem)
          return [].concat(_toConsumableArray(last), [next]);
        return last.map(function(item) {
          if (item.value !== next.value)
            return item;
          return _extends({}, item, next);
        });
      });
    };
    var initialValue = F(function() {
      return {
        register,
        currentValue: selfValue,
        inGroup: true,
        leftSpace
      };
    }, [selfValue, leftSpace]);
    h2(function() {
      if (typeof value === "undefined")
        return;
      setSelfValue(value);
    }, [value]);
    var clickHandler = function clickHandler2(value2) {
      setSelfValue(value2);
      onChange && onChange(value2);
    };
    var tabItemMouseOverHandler = function tabItemMouseOverHandler2(event) {
      if (!isGeistElement(event.target))
        return;
      setRect(event, function() {
        return ref.current;
      });
      if (highlight) {
        setDisplayHighlight(true);
      }
    };
    return /* @__PURE__ */ bn.createElement(TabsContext.Provider, {
      value: initialValue
    }, /* @__PURE__ */ bn.createElement("div", _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["1340018565", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), align, theme.palette.border, leftSpace]]]) + " " + (props && props.className != null && props.className || use_classes_default2("tabs", className) || "")
    }), /* @__PURE__ */ bn.createElement("header", {
      ref,
      onMouseLeave: function onMouseLeave() {
        return setDisplayHighlight(false);
      },
      className: styled_jsx_es_default.dynamic([["1340018565", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), align, theme.palette.border, leftSpace]]])
    }, /* @__PURE__ */ bn.createElement(highlight_default, {
      rect,
      visible: displayHighlight,
      hoverHeightRatio,
      hoverWidthRatio
    }), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["1340018565", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), align, theme.palette.border, leftSpace]]]) + " " + (use_classes_default2("scroll-container", {
        "hide-divider": hideDivider
      }) || "")
    }, tabs.map(function(_ref2) {
      var Cell = _ref2.cell, value2 = _ref2.value;
      return /* @__PURE__ */ bn.createElement(Cell, {
        key: value2,
        onClick: clickHandler,
        onMouseOver: tabItemMouseOverHandler,
        activeClassName,
        activeStyle,
        hideBorder,
        className: styled_jsx_es_default.dynamic([["1340018565", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), align, theme.palette.border, leftSpace]]])
      });
    }))), /* @__PURE__ */ bn.createElement("div", {
      className: styled_jsx_es_default.dynamic([["1340018565", [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), align, theme.palette.border, leftSpace]]]) + " content"
    }, children), /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1340018565",
      dynamic: [SCALES.font(1), SCALES.width(1, "initial"), SCALES.height(1, "auto"), SCALES.pt(0), SCALES.pr(0), SCALES.pb(0), SCALES.pl(0), SCALES.mt(0), SCALES.mr(0), SCALES.mb(0), SCALES.ml(0), align, theme.palette.border, leftSpace]
    }, ".tabs.__jsx-style-dynamic-selector{font-size:".concat(SCALES.font(1), ";width:").concat(SCALES.width(1, "initial"), ";height:").concat(SCALES.height(1, "auto"), ";padding:").concat(SCALES.pt(0), " ").concat(SCALES.pr(0), " ").concat(SCALES.pb(0), " ").concat(SCALES.pl(0), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0), ";}header.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-wrap:nowrap;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;overflow-y:hidden;overflow-x:scroll;-webkit-scrollbar-width:none;-moz-scrollbar-width:none;-ms-scrollbar-width:none;scrollbar-width:none;position:relative;}.scroll-container.__jsx-style-dynamic-selector{width:100%;height:100%;-webkit-flex:1;-ms-flex:1;flex:1;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-wrap:nowrap;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:").concat(align, ";-webkit-justify-content:").concat(align, ";-ms-flex-pack:").concat(align, ";justify-content:").concat(align, ";border-bottom:1px solid ").concat(theme.palette.border, ";padding-left:").concat(leftSpace, ";}header.__jsx-style-dynamic-selector::-webkit-scrollbar{display:none;}.hide-divider.__jsx-style-dynamic-selector{border-color:transparent;}.content.__jsx-style-dynamic-selector{padding-top:0.625rem;}"))));
  };
  TabsComponent.defaultProps = defaultProps18;
  TabsComponent.displayName = "GeistTabs";
  var Tabs = with_scale_default(TabsComponent);
  var tabs_default = Tabs;

  // node_modules/@babel/runtime/helpers/esm/toPrimitive.js
  function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null)
      return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== void 0) {
      var res = prim.call(input, hint || "default");
      if (_typeof(res) !== "object")
        return res;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
  }

  // node_modules/@babel/runtime/helpers/esm/toPropertyKey.js
  function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
  }

  // node_modules/@babel/runtime/helpers/esm/defineProperty.js
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }

  // node_modules/@geist-ui/core/esm/tabs/tabs-item.js
  init_react();
  var defaultProps19 = {
    disabled: false
  };
  var TabsItemComponent = function TabsItemComponent2(_ref) {
    var children = _ref.children, value = _ref.value, label = _ref.label, disabled = _ref.disabled;
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES;
    var _useTabsContext = useTabsContext(), register = _useTabsContext.register, currentValue = _useTabsContext.currentValue;
    var isActive = F(function() {
      return currentValue === value;
    }, [currentValue, value]);
    var TabsInternalCell = function TabsInternalCell2(_ref2) {
      var _useClasses;
      var onClick = _ref2.onClick, onMouseOver = _ref2.onMouseOver, activeClassName = _ref2.activeClassName, activeStyle = _ref2.activeStyle, hideBorder = _ref2.hideBorder;
      var theme = use_theme_default();
      var ref = _2(null);
      var _useTabsContext2 = useTabsContext(), currentValue2 = _useTabsContext2.currentValue;
      var active = currentValue2 === value;
      var classes = use_classes_default2("tab", (_useClasses = {
        active,
        disabled
      }, _defineProperty(_useClasses, activeClassName, active), _defineProperty(_useClasses, "hide-border", hideBorder), _useClasses));
      var clickHandler = function clickHandler2() {
        if (disabled)
          return;
        onClick && onClick(value);
      };
      return /* @__PURE__ */ bn.createElement("div", {
        ref,
        role: "button",
        key: value,
        onMouseOver,
        onClick: clickHandler,
        style: active ? activeStyle : {},
        "data-geist": "tab-item",
        className: styled_jsx_es_default.dynamic([["2444688710", [theme.palette.accents_5, SCALES.font(0.875), SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.pt(0.875), SCALES.pr(0.55), SCALES.pb(0.875), SCALES.pl(0.55), SCALES.mt(0), SCALES.mr(0.2), SCALES.mb(0), SCALES.ml(0.2), SCALES.pl(0.28), SCALES.pr(0.28), theme.palette.foreground, theme.palette.foreground, theme.palette.foreground, theme.palette.accents_3, label]]]) + " " + (classes || "")
      }, label, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
        id: "2444688710",
        dynamic: [theme.palette.accents_5, SCALES.font(0.875), SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.pt(0.875), SCALES.pr(0.55), SCALES.pb(0.875), SCALES.pl(0.55), SCALES.mt(0), SCALES.mr(0.2), SCALES.mb(0), SCALES.ml(0.2), SCALES.pl(0.28), SCALES.pr(0.28), theme.palette.foreground, theme.palette.foreground, theme.palette.foreground, theme.palette.accents_3, label]
      }, ".tab.__jsx-style-dynamic-selector{position:relative;box-sizing:border-box;cursor:pointer;outline:0;text-transform:capitalize;white-space:nowrap;background-color:transparent;color:".concat(theme.palette.accents_5, ";-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-size:").concat(SCALES.font(0.875), ";line-height:normal;width:").concat(SCALES.width(1, "auto"), ";height:").concat(SCALES.height(1, "auto"), ";padding:").concat(SCALES.pt(0.875), " ").concat(SCALES.pr(0.55), " ").concat(SCALES.pb(0.875), " ").concat(SCALES.pl(0.55), ";margin:").concat(SCALES.mt(0), " ").concat(SCALES.mr(0.2), " ").concat(SCALES.mb(0), " ").concat(SCALES.ml(0.2), ";z-index:1;--tabs-item-hover-left:calc(-1 * ").concat(SCALES.pl(0.28), ");--tabs-item-hover-right:calc(-1 * ").concat(SCALES.pr(0.28), ");}.tab.__jsx-style-dynamic-selector:hover{color:").concat(theme.palette.foreground, ";}.tab.__jsx-style-dynamic-selector:after{position:absolute;content:'';bottom:-1px;left:0;right:0;width:100%;height:2px;border-radius:4px;-webkit-transform:scaleX(0.75);-ms-transform:scaleX(0.75);transform:scaleX(0.75);background-color:").concat(theme.palette.foreground, ";-webkit-transition:opacity,-webkit-transform 200ms ease-in;-webkit-transition:opacity,transform 200ms ease-in;transition:opacity,transform 200ms ease-in;opacity:0;}.active.__jsx-style-dynamic-selector:after{opacity:1;-webkit-transform:scaleX(1);-ms-transform:scaleX(1);transform:scaleX(1);}.tab.__jsx-style-dynamic-selector svg{max-height:1em;margin-right:5px;}.tab.__jsx-style-dynamic-selector:first-of-type{margin-left:0;}.active.__jsx-style-dynamic-selector{color:").concat(theme.palette.foreground, ";}.disabled.__jsx-style-dynamic-selector{color:").concat(theme.palette.accents_3, ";cursor:not-allowed;}.hide-border.__jsx-style-dynamic-selector:before{display:block;content:").concat(label, ";font-weight:500;height:0;overflow:hidden;visibility:hidden;}.hide-border.__jsx-style-dynamic-selector:after{display:none;}.hide-border.active.__jsx-style-dynamic-selector{font-weight:500;}")));
    };
    TabsInternalCell.displayName = "GeistTabsInternalCell";
    h2(function() {
      register && register({
        value,
        cell: TabsInternalCell
      });
    }, [value, label, disabled]);
    return isActive ? /* @__PURE__ */ bn.createElement(bn.Fragment, null, children) : null;
  };
  TabsItemComponent.defaultProps = defaultProps19;
  TabsItemComponent.displayName = "GeistTabsItem";
  var TabsItem = with_scale_default(TabsItemComponent);
  var tabs_item_default = TabsItem;

  // node_modules/@geist-ui/core/esm/tabs/index.js
  tabs_default.Item = tabs_item_default;
  tabs_default.Tab = tabs_item_default;
  var tabs_default2 = tabs_default;

  // node_modules/@geist-ui/core/esm/text/text.js
  init_react();

  // node_modules/@geist-ui/core/esm/text/child.js
  init_react();
  var _excluded21 = ["children", "tag", "className", "type"];
  var defaultProps20 = {
    type: "default",
    className: ""
  };
  var getTypeColor = function getTypeColor2(type, palette3) {
    var colors = {
      "default": "inherit",
      secondary: palette3.secondary,
      success: palette3.success,
      warning: palette3.warning,
      error: palette3.error
    };
    return colors[type] || colors["default"];
  };
  var TextChild = function TextChild2(_ref) {
    var children = _ref.children, tag = _ref.tag, className = _ref.className, type = _ref.type, props = _objectWithoutProperties(_ref, _excluded21);
    var Component = tag;
    var theme = use_theme_default();
    var _useScale = use_scale_default(), SCALES = _useScale.SCALES, getScaleProps2 = _useScale.getScaleProps;
    var font3 = getScaleProps2("font");
    var mx = getScaleProps2(["margin", "marginLeft", "marginRight", "mx", "ml", "mr"]);
    var my = getScaleProps2(["margin", "marginTop", "marginBottom", "my", "mt", "mb"]);
    var px = getScaleProps2(["padding", "paddingLeft", "paddingRight", "pl", "pr", "px"]);
    var py = getScaleProps2(["padding", "paddingTop", "paddingBottom", "pt", "pb", "py"]);
    var color = F(function() {
      return getTypeColor(type, theme.palette);
    }, [type, theme.palette]);
    var classNames = F(function() {
      var keys = [{
        value: mx,
        className: "mx"
      }, {
        value: my,
        className: "my"
      }, {
        value: px,
        className: "px"
      }, {
        value: py,
        className: "py"
      }, {
        value: font3,
        className: "font"
      }];
      var scaleClassNames = keys.reduce(function(pre, next) {
        if (typeof next.value === "undefined")
          return pre;
        return "".concat(pre, " ").concat(next.className);
      }, "");
      return "".concat(scaleClassNames, " ").concat(className).trim();
    }, [mx, my, px, py, font3, className]);
    return /* @__PURE__ */ bn.createElement(Component, _extends({}, props, {
      className: styled_jsx_es_default.dynamic([["3155699851", [tag, color, SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.font(1, "inherit"), SCALES.ml(0, "revert"), SCALES.mr(0, "revert"), SCALES.mt(0, "revert"), SCALES.mb(0, "revert"), SCALES.pl(0, "revert"), SCALES.pr(0, "revert"), SCALES.pt(0, "revert"), SCALES.pb(0, "revert")]]]) + " " + (props && props.className != null && props.className || classNames || "")
    }), children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "3155699851",
      dynamic: [tag, color, SCALES.width(1, "auto"), SCALES.height(1, "auto"), SCALES.font(1, "inherit"), SCALES.ml(0, "revert"), SCALES.mr(0, "revert"), SCALES.mt(0, "revert"), SCALES.mb(0, "revert"), SCALES.pl(0, "revert"), SCALES.pr(0, "revert"), SCALES.pt(0, "revert"), SCALES.pb(0, "revert")]
    }, "".concat(tag, ".__jsx-style-dynamic-selector{color:").concat(color, ";width:").concat(SCALES.width(1, "auto"), ";height:").concat(SCALES.height(1, "auto"), ";}.font.__jsx-style-dynamic-selector{font-size:").concat(SCALES.font(1, "inherit"), ";}.mx.__jsx-style-dynamic-selector{margin-left:").concat(SCALES.ml(0, "revert"), ";margin-right:").concat(SCALES.mr(0, "revert"), ";}.my.__jsx-style-dynamic-selector{margin-top:").concat(SCALES.mt(0, "revert"), ";margin-bottom:").concat(SCALES.mb(0, "revert"), ";}.px.__jsx-style-dynamic-selector{padding-left:").concat(SCALES.pl(0, "revert"), ";padding-right:").concat(SCALES.pr(0, "revert"), ";}.py.__jsx-style-dynamic-selector{padding-top:").concat(SCALES.pt(0, "revert"), ";padding-bottom:").concat(SCALES.pb(0, "revert"), ";}")));
  };
  TextChild.defaultProps = defaultProps20;
  TextChild.displayName = "GeistTextChild";
  var child_default = TextChild;

  // node_modules/@geist-ui/core/esm/text/text.js
  var _excluded22 = ["h1", "h2", "h3", "h4", "h5", "h6", "p", "b", "small", "i", "span", "del", "em", "blockquote", "children", "className"];
  var defaultProps21 = {
    h1: false,
    h2: false,
    h3: false,
    h4: false,
    h5: false,
    h6: false,
    p: false,
    b: false,
    small: false,
    i: false,
    span: false,
    del: false,
    em: false,
    blockquote: false,
    className: "",
    type: "default"
  };
  var getModifierChild = function getModifierChild2(tags, children) {
    if (!tags.length)
      return children;
    var nextTag = tags.slice(1, tags.length);
    return /* @__PURE__ */ bn.createElement(child_default, {
      tag: tags[0]
    }, getModifierChild2(nextTag, children));
  };
  var TextComponent = function TextComponent2(_ref) {
    var h1 = _ref.h1, h22 = _ref.h2, h3 = _ref.h3, h4 = _ref.h4, h5 = _ref.h5, h6 = _ref.h6, p3 = _ref.p, b3 = _ref.b, small = _ref.small, i3 = _ref.i, span = _ref.span, del = _ref.del, em = _ref.em, blockquote = _ref.blockquote, children = _ref.children, className = _ref.className, props = _objectWithoutProperties(_ref, _excluded22);
    var elements = {
      h1,
      h2: h22,
      h3,
      h4,
      h5,
      h6,
      p: p3,
      blockquote
    };
    var inlineElements = {
      span,
      small,
      b: b3,
      em,
      i: i3,
      del
    };
    var names = Object.keys(elements).filter(function(name) {
      return elements[name];
    });
    var inlineNames = Object.keys(inlineElements).filter(function(name) {
      return inlineElements[name];
    });
    var tag = F(function() {
      if (names[0])
        return names[0];
      if (inlineNames[0])
        return inlineNames[0];
      return "p";
    }, [names, inlineNames]);
    var renderableChildElements = inlineNames.filter(function(name) {
      return name !== tag;
    });
    var modifers = F(function() {
      if (!renderableChildElements.length)
        return children;
      return getModifierChild(renderableChildElements, children);
    }, [renderableChildElements, children]);
    return /* @__PURE__ */ bn.createElement(child_default, _extends({
      className,
      tag
    }, props), modifers);
  };
  TextComponent.defaultProps = defaultProps21;
  TextComponent.displayName = "GeistText";
  var Text = with_scale_default(TextComponent);
  var text_default = Text;

  // node_modules/@geist-ui/core/esm/text/index.js
  var text_default2 = text_default;

  // node_modules/@geist-ui/core/esm/use-input/use-input.js
  var useInput = function useInput2(initialValue) {
    var _useCurrentState = use_current_state_default3(initialValue), _useCurrentState2 = _slicedToArray(_useCurrentState, 3), state = _useCurrentState2[0], setState = _useCurrentState2[1], currentRef = _useCurrentState2[2];
    return {
      state,
      setState,
      currentRef,
      reset: function reset() {
        return setState(initialValue);
      },
      bindings: {
        value: state,
        onChange: function onChange(event) {
          if (_typeof(event) === "object" && event.target) {
            setState(event.target.value);
          } else {
            setState(event);
          }
        }
      }
    };
  };
  var use_input_default = useInput;

  // node_modules/@geist-ui/core/esm/use-input/index.js
  var use_input_default2 = use_input_default;

  // node_modules/@geist-ui/core/esm/css-baseline/css-baseline.js
  init_react();

  // node_modules/@geist-ui/core/esm/styled-jsx-server.es.js
  var { flushToHTML } = _server;
  var styled_jsx_server_es_default = _server;

  // node_modules/@geist-ui/core/esm/css-baseline/css-baseline.js
  var CssBaseline = function CssBaseline2(_ref) {
    var children = _ref.children;
    var theme = use_theme_default();
    return /* @__PURE__ */ bn.createElement(bn.Fragment, null, children, /* @__PURE__ */ bn.createElement(styled_jsx_es_default, {
      id: "1357910706",
      dynamic: [theme.palette.background, theme.palette.foreground, theme.palette.background, theme.font.sans, theme.font.sans, theme.palette.link, theme.expressiveness.linkStyle, theme.expressiveness.linkHoverStyle, theme.layout.gapHalf, theme.layout.gapHalf, theme.layout.gapHalf, theme.layout.gap, theme.palette.foreground, theme.palette.accents_4, theme.palette.code, theme.font.mono, theme.layout.gap, theme.layout.gap, theme.layout.gap, theme.palette.accents_2, theme.layout.radius, theme.font.mono, theme.palette.foreground, theme.palette.accents_2, theme.palette.accents_1, theme.layout.gap, theme.layout.gap, theme.palette.accents_5, theme.palette.accents_1, theme.layout.radius, theme.palette.border, theme.palette.selection, theme.palette.foreground]
    }, "html,body{background-color:".concat(theme.palette.background, ";color:").concat(theme.palette.foreground, ";}html{font-size:16px;--geist-icons-background:").concat(theme.palette.background, ";}body{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility;font-size:1rem;line-height:1.5;margin:0;padding:0;min-height:100%;position:relative;overflow-x:hidden;font-family:").concat(theme.font.sans, ";}#__next{overflow-x:hidden;}*,*:before,*:after{box-sizing:inherit;text-rendering:geometricPrecision;-webkit-tap-highlight-color:transparent;}p,small{font-weight:400;color:inherit;-webkit-letter-spacing:-0.005625em;-moz-letter-spacing:-0.005625em;-ms-letter-spacing:-0.005625em;letter-spacing:-0.005625em;font-family:").concat(theme.font.sans, ";}p{margin:1em 0;font-size:1em;line-height:1.625em;}small{margin:0;line-height:1.5;font-size:0.875em;}b{font-weight:600;}span{font-size:inherit;color:inherit;font-weight:inherit;}img{max-width:100%;}a{cursor:pointer;font-size:inherit;-webkit-touch-callout:none;-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-box-align:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:").concat(theme.palette.link, ";-webkit-text-decoration:").concat(theme.expressiveness.linkStyle, ";text-decoration:").concat(theme.expressiveness.linkStyle, ";}a:hover{-webkit-text-decoration:").concat(theme.expressiveness.linkHoverStyle, ";text-decoration:").concat(theme.expressiveness.linkHoverStyle, ";}ul,ol{padding:0;list-style-type:none;margin:").concat(theme.layout.gapHalf, " ").concat(theme.layout.gapHalf, " ").concat(theme.layout.gapHalf, " ").concat(theme.layout.gap, ";color:").concat(theme.palette.foreground, ";}ol{list-style-type:decimal;}li{margin-bottom:0.625em;font-size:1em;line-height:1.625em;}ul li:before{content:'\u2013';display:inline-block;color:").concat(theme.palette.accents_4, ";position:absolute;margin-left:-0.9375em;}h1,h2,h3,h4,h5,h6{color:inherit;margin:0 0 0.7rem 0;}h1{font-size:3rem;-webkit-letter-spacing:-0.02em;-moz-letter-spacing:-0.02em;-ms-letter-spacing:-0.02em;letter-spacing:-0.02em;line-height:1.5;font-weight:700;}h2{font-size:2.25rem;-webkit-letter-spacing:-0.02em;-moz-letter-spacing:-0.02em;-ms-letter-spacing:-0.02em;letter-spacing:-0.02em;font-weight:600;}h3{font-size:1.5rem;-webkit-letter-spacing:-0.02em;-moz-letter-spacing:-0.02em;-ms-letter-spacing:-0.02em;letter-spacing:-0.02em;font-weight:600;}h4{font-size:1.25rem;-webkit-letter-spacing:-0.02em;-moz-letter-spacing:-0.02em;-ms-letter-spacing:-0.02em;letter-spacing:-0.02em;font-weight:600;}h5{font-size:1rem;-webkit-letter-spacing:-0.01em;-moz-letter-spacing:-0.01em;-ms-letter-spacing:-0.01em;letter-spacing:-0.01em;font-weight:600;}h6{font-size:0.875rem;-webkit-letter-spacing:-0.005em;-moz-letter-spacing:-0.005em;-ms-letter-spacing:-0.005em;letter-spacing:-0.005em;font-weight:600;}button,input,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit;color:inherit;margin:0;}button:focus,input:focus,select:focus,textarea:focus{outline:none;}code{color:").concat(theme.palette.code, ";font-family:").concat(theme.font.mono, ";font-size:0.9em;white-space:pre-wrap;}code:before,code:after{content:'\\`';}pre{padding:calc(").concat(theme.layout.gap, " * 0.9) ").concat(theme.layout.gap, ";margin:").concat(theme.layout.gap, " 0;border:1px solid ").concat(theme.palette.accents_2, ";border-radius:").concat(theme.layout.radius, ";font-family:").concat(theme.font.mono, ";white-space:pre;overflow:auto;line-height:1.5;text-align:left;font-size:14px;-webkit-overflow-scrolling:touch;}pre code{color:").concat(theme.palette.foreground, ";font-size:1em;line-height:1.25em;white-space:pre;}pre code:before,pre code:after{display:none;}pre p{margin:0;}pre::-webkit-scrollbar{display:none;width:0;height:0;background:transparent;}hr{border-color:").concat(theme.palette.accents_2, ";}details{background-color:").concat(theme.palette.accents_1, ";border:none;}details:focus,details:hover,details:active{outline:none;}summary{cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;list-style:none;outline:none;}summary::marker,summary::before,summary::-webkit-details-marker{display:none;}summary::-moz-list-bullet{font-size:0;}summary:focus,summary:hover,summary:active{outline:none;list-style:none;}blockquote{padding:calc(0.667 * ").concat(theme.layout.gap, ") ").concat(theme.layout.gap, ";color:").concat(theme.palette.accents_5, ";background-color:").concat(theme.palette.accents_1, ";border-radius:").concat(theme.layout.radius, ";margin:1.5em 0;border:1px solid ").concat(theme.palette.border, ";}blockquote *:first-child{margin-top:0;}blockquote *:last-child{margin-bottom:0;}::selection{background-color:").concat(theme.palette.selection, ";color:").concat(theme.palette.foreground, ";}")));
  };
  var MemoCssBaseline = /* @__PURE__ */ bn.memo(CssBaseline);
  MemoCssBaseline.flush = styled_jsx_server_es_default;
  MemoCssBaseline.flushToHTML = flushToHTML;
  var css_baseline_default = MemoCssBaseline;

  // node_modules/lodash-es/_freeGlobal.js
  var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
  var freeGlobal_default = freeGlobal;

  // node_modules/lodash-es/_root.js
  var freeSelf = typeof self == "object" && self && self.Object === Object && self;
  var root = freeGlobal_default || freeSelf || Function("return this")();
  var root_default = root;

  // node_modules/lodash-es/_Symbol.js
  var Symbol2 = root_default.Symbol;
  var Symbol_default = Symbol2;

  // node_modules/lodash-es/_getRawTag.js
  var objectProto = Object.prototype;
  var hasOwnProperty = objectProto.hasOwnProperty;
  var nativeObjectToString = objectProto.toString;
  var symToStringTag = Symbol_default ? Symbol_default.toStringTag : void 0;
  function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
    try {
      value[symToStringTag] = void 0;
      var unmasked = true;
    } catch (e3) {
    }
    var result = nativeObjectToString.call(value);
    if (unmasked) {
      if (isOwn) {
        value[symToStringTag] = tag;
      } else {
        delete value[symToStringTag];
      }
    }
    return result;
  }
  var getRawTag_default = getRawTag;

  // node_modules/lodash-es/_objectToString.js
  var objectProto2 = Object.prototype;
  var nativeObjectToString2 = objectProto2.toString;
  function objectToString(value) {
    return nativeObjectToString2.call(value);
  }
  var objectToString_default = objectToString;

  // node_modules/lodash-es/_baseGetTag.js
  var nullTag = "[object Null]";
  var undefinedTag = "[object Undefined]";
  var symToStringTag2 = Symbol_default ? Symbol_default.toStringTag : void 0;
  function baseGetTag(value) {
    if (value == null) {
      return value === void 0 ? undefinedTag : nullTag;
    }
    return symToStringTag2 && symToStringTag2 in Object(value) ? getRawTag_default(value) : objectToString_default(value);
  }
  var baseGetTag_default = baseGetTag;

  // node_modules/lodash-es/isObjectLike.js
  function isObjectLike(value) {
    return value != null && typeof value == "object";
  }
  var isObjectLike_default = isObjectLike;

  // node_modules/lodash-es/isSymbol.js
  var symbolTag = "[object Symbol]";
  function isSymbol(value) {
    return typeof value == "symbol" || isObjectLike_default(value) && baseGetTag_default(value) == symbolTag;
  }
  var isSymbol_default = isSymbol;

  // node_modules/lodash-es/_arrayMap.js
  function arrayMap(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length, result = Array(length);
    while (++index < length) {
      result[index] = iteratee(array[index], index, array);
    }
    return result;
  }
  var arrayMap_default = arrayMap;

  // node_modules/lodash-es/isArray.js
  var isArray = Array.isArray;
  var isArray_default = isArray;

  // node_modules/lodash-es/_baseToString.js
  var INFINITY = 1 / 0;
  var symbolProto = Symbol_default ? Symbol_default.prototype : void 0;
  var symbolToString = symbolProto ? symbolProto.toString : void 0;
  function baseToString(value) {
    if (typeof value == "string") {
      return value;
    }
    if (isArray_default(value)) {
      return arrayMap_default(value, baseToString) + "";
    }
    if (isSymbol_default(value)) {
      return symbolToString ? symbolToString.call(value) : "";
    }
    var result = value + "";
    return result == "0" && 1 / value == -INFINITY ? "-0" : result;
  }
  var baseToString_default = baseToString;

  // node_modules/lodash-es/isObject.js
  function isObject3(value) {
    var type = typeof value;
    return value != null && (type == "object" || type == "function");
  }
  var isObject_default = isObject3;

  // node_modules/lodash-es/identity.js
  function identity(value) {
    return value;
  }
  var identity_default = identity;

  // node_modules/lodash-es/isFunction.js
  var asyncTag = "[object AsyncFunction]";
  var funcTag = "[object Function]";
  var genTag = "[object GeneratorFunction]";
  var proxyTag = "[object Proxy]";
  function isFunction(value) {
    if (!isObject_default(value)) {
      return false;
    }
    var tag = baseGetTag_default(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
  }
  var isFunction_default = isFunction;

  // node_modules/lodash-es/_coreJsData.js
  var coreJsData = root_default["__core-js_shared__"];
  var coreJsData_default = coreJsData;

  // node_modules/lodash-es/_isMasked.js
  var maskSrcKey = function() {
    var uid = /[^.]+$/.exec(coreJsData_default && coreJsData_default.keys && coreJsData_default.keys.IE_PROTO || "");
    return uid ? "Symbol(src)_1." + uid : "";
  }();
  function isMasked(func) {
    return !!maskSrcKey && maskSrcKey in func;
  }
  var isMasked_default = isMasked;

  // node_modules/lodash-es/_toSource.js
  var funcProto = Function.prototype;
  var funcToString = funcProto.toString;
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString.call(func);
      } catch (e3) {
      }
      try {
        return func + "";
      } catch (e3) {
      }
    }
    return "";
  }
  var toSource_default = toSource;

  // node_modules/lodash-es/_baseIsNative.js
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  var funcProto2 = Function.prototype;
  var objectProto3 = Object.prototype;
  var funcToString2 = funcProto2.toString;
  var hasOwnProperty2 = objectProto3.hasOwnProperty;
  var reIsNative = RegExp(
    "^" + funcToString2.call(hasOwnProperty2).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
  );
  function baseIsNative(value) {
    if (!isObject_default(value) || isMasked_default(value)) {
      return false;
    }
    var pattern = isFunction_default(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource_default(value));
  }
  var baseIsNative_default = baseIsNative;

  // node_modules/lodash-es/_getValue.js
  function getValue(object, key) {
    return object == null ? void 0 : object[key];
  }
  var getValue_default = getValue;

  // node_modules/lodash-es/_getNative.js
  function getNative(object, key) {
    var value = getValue_default(object, key);
    return baseIsNative_default(value) ? value : void 0;
  }
  var getNative_default = getNative;

  // node_modules/lodash-es/_apply.js
  function apply(func, thisArg, args) {
    switch (args.length) {
      case 0:
        return func.call(thisArg);
      case 1:
        return func.call(thisArg, args[0]);
      case 2:
        return func.call(thisArg, args[0], args[1]);
      case 3:
        return func.call(thisArg, args[0], args[1], args[2]);
    }
    return func.apply(thisArg, args);
  }
  var apply_default = apply;

  // node_modules/lodash-es/_shortOut.js
  var HOT_COUNT = 800;
  var HOT_SPAN = 16;
  var nativeNow = Date.now;
  function shortOut(func) {
    var count = 0, lastCalled = 0;
    return function() {
      var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
      lastCalled = stamp;
      if (remaining > 0) {
        if (++count >= HOT_COUNT) {
          return arguments[0];
        }
      } else {
        count = 0;
      }
      return func.apply(void 0, arguments);
    };
  }
  var shortOut_default = shortOut;

  // node_modules/lodash-es/constant.js
  function constant(value) {
    return function() {
      return value;
    };
  }
  var constant_default = constant;

  // node_modules/lodash-es/_defineProperty.js
  var defineProperty = function() {
    try {
      var func = getNative_default(Object, "defineProperty");
      func({}, "", {});
      return func;
    } catch (e3) {
    }
  }();
  var defineProperty_default = defineProperty;

  // node_modules/lodash-es/_baseSetToString.js
  var baseSetToString = !defineProperty_default ? identity_default : function(func, string) {
    return defineProperty_default(func, "toString", {
      "configurable": true,
      "enumerable": false,
      "value": constant_default(string),
      "writable": true
    });
  };
  var baseSetToString_default = baseSetToString;

  // node_modules/lodash-es/_setToString.js
  var setToString = shortOut_default(baseSetToString_default);
  var setToString_default = setToString;

  // node_modules/lodash-es/_isIndex.js
  var MAX_SAFE_INTEGER = 9007199254740991;
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  function isIndex(value, length) {
    var type = typeof value;
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
  }
  var isIndex_default = isIndex;

  // node_modules/lodash-es/eq.js
  function eq(value, other) {
    return value === other || value !== value && other !== other;
  }
  var eq_default = eq;

  // node_modules/lodash-es/_overRest.js
  var nativeMax = Math.max;
  function overRest(func, start, transform) {
    start = nativeMax(start === void 0 ? func.length - 1 : start, 0);
    return function() {
      var args = arguments, index = -1, length = nativeMax(args.length - start, 0), array = Array(length);
      while (++index < length) {
        array[index] = args[start + index];
      }
      index = -1;
      var otherArgs = Array(start + 1);
      while (++index < start) {
        otherArgs[index] = args[index];
      }
      otherArgs[start] = transform(array);
      return apply_default(func, this, otherArgs);
    };
  }
  var overRest_default = overRest;

  // node_modules/lodash-es/_baseRest.js
  function baseRest(func, start) {
    return setToString_default(overRest_default(func, start, identity_default), func + "");
  }
  var baseRest_default = baseRest;

  // node_modules/lodash-es/isLength.js
  var MAX_SAFE_INTEGER2 = 9007199254740991;
  function isLength(value) {
    return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER2;
  }
  var isLength_default = isLength;

  // node_modules/lodash-es/isArrayLike.js
  function isArrayLike(value) {
    return value != null && isLength_default(value.length) && !isFunction_default(value);
  }
  var isArrayLike_default = isArrayLike;

  // node_modules/lodash-es/_isIterateeCall.js
  function isIterateeCall(value, index, object) {
    if (!isObject_default(object)) {
      return false;
    }
    var type = typeof index;
    if (type == "number" ? isArrayLike_default(object) && isIndex_default(index, object.length) : type == "string" && index in object) {
      return eq_default(object[index], value);
    }
    return false;
  }
  var isIterateeCall_default = isIterateeCall;

  // node_modules/lodash-es/_isPrototype.js
  var objectProto4 = Object.prototype;
  function isPrototype(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto4;
    return value === proto;
  }
  var isPrototype_default = isPrototype;

  // node_modules/lodash-es/_baseTimes.js
  function baseTimes(n2, iteratee) {
    var index = -1, result = Array(n2);
    while (++index < n2) {
      result[index] = iteratee(index);
    }
    return result;
  }
  var baseTimes_default = baseTimes;

  // node_modules/lodash-es/_baseIsArguments.js
  var argsTag = "[object Arguments]";
  function baseIsArguments(value) {
    return isObjectLike_default(value) && baseGetTag_default(value) == argsTag;
  }
  var baseIsArguments_default = baseIsArguments;

  // node_modules/lodash-es/isArguments.js
  var objectProto5 = Object.prototype;
  var hasOwnProperty3 = objectProto5.hasOwnProperty;
  var propertyIsEnumerable = objectProto5.propertyIsEnumerable;
  var isArguments = baseIsArguments_default(function() {
    return arguments;
  }()) ? baseIsArguments_default : function(value) {
    return isObjectLike_default(value) && hasOwnProperty3.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
  };
  var isArguments_default = isArguments;

  // node_modules/lodash-es/stubFalse.js
  function stubFalse() {
    return false;
  }
  var stubFalse_default = stubFalse;

  // node_modules/lodash-es/isBuffer.js
  var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var Buffer2 = moduleExports ? root_default.Buffer : void 0;
  var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
  var isBuffer = nativeIsBuffer || stubFalse_default;
  var isBuffer_default = isBuffer;

  // node_modules/lodash-es/_baseIsTypedArray.js
  var argsTag2 = "[object Arguments]";
  var arrayTag = "[object Array]";
  var boolTag = "[object Boolean]";
  var dateTag = "[object Date]";
  var errorTag = "[object Error]";
  var funcTag2 = "[object Function]";
  var mapTag = "[object Map]";
  var numberTag = "[object Number]";
  var objectTag = "[object Object]";
  var regexpTag = "[object RegExp]";
  var setTag = "[object Set]";
  var stringTag = "[object String]";
  var weakMapTag = "[object WeakMap]";
  var arrayBufferTag = "[object ArrayBuffer]";
  var dataViewTag = "[object DataView]";
  var float32Tag = "[object Float32Array]";
  var float64Tag = "[object Float64Array]";
  var int8Tag = "[object Int8Array]";
  var int16Tag = "[object Int16Array]";
  var int32Tag = "[object Int32Array]";
  var uint8Tag = "[object Uint8Array]";
  var uint8ClampedTag = "[object Uint8ClampedArray]";
  var uint16Tag = "[object Uint16Array]";
  var uint32Tag = "[object Uint32Array]";
  var typedArrayTags = {};
  typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
  typedArrayTags[argsTag2] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag2] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
  function baseIsTypedArray(value) {
    return isObjectLike_default(value) && isLength_default(value.length) && !!typedArrayTags[baseGetTag_default(value)];
  }
  var baseIsTypedArray_default = baseIsTypedArray;

  // node_modules/lodash-es/_baseUnary.js
  function baseUnary(func) {
    return function(value) {
      return func(value);
    };
  }
  var baseUnary_default = baseUnary;

  // node_modules/lodash-es/_nodeUtil.js
  var freeExports2 = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule2 = freeExports2 && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports2 = freeModule2 && freeModule2.exports === freeExports2;
  var freeProcess = moduleExports2 && freeGlobal_default.process;
  var nodeUtil = function() {
    try {
      var types = freeModule2 && freeModule2.require && freeModule2.require("util").types;
      if (types) {
        return types;
      }
      return freeProcess && freeProcess.binding && freeProcess.binding("util");
    } catch (e3) {
    }
  }();
  var nodeUtil_default = nodeUtil;

  // node_modules/lodash-es/isTypedArray.js
  var nodeIsTypedArray = nodeUtil_default && nodeUtil_default.isTypedArray;
  var isTypedArray = nodeIsTypedArray ? baseUnary_default(nodeIsTypedArray) : baseIsTypedArray_default;
  var isTypedArray_default = isTypedArray;

  // node_modules/lodash-es/_arrayLikeKeys.js
  var objectProto6 = Object.prototype;
  var hasOwnProperty4 = objectProto6.hasOwnProperty;
  function arrayLikeKeys(value, inherited) {
    var isArr = isArray_default(value), isArg = !isArr && isArguments_default(value), isBuff = !isArr && !isArg && isBuffer_default(value), isType = !isArr && !isArg && !isBuff && isTypedArray_default(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes_default(value.length, String) : [], length = result.length;
    for (var key in value) {
      if ((inherited || hasOwnProperty4.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
      (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
      isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
      isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
      isIndex_default(key, length)))) {
        result.push(key);
      }
    }
    return result;
  }
  var arrayLikeKeys_default = arrayLikeKeys;

  // node_modules/lodash-es/_nativeKeysIn.js
  function nativeKeysIn(object) {
    var result = [];
    if (object != null) {
      for (var key in Object(object)) {
        result.push(key);
      }
    }
    return result;
  }
  var nativeKeysIn_default = nativeKeysIn;

  // node_modules/lodash-es/_baseKeysIn.js
  var objectProto7 = Object.prototype;
  var hasOwnProperty5 = objectProto7.hasOwnProperty;
  function baseKeysIn(object) {
    if (!isObject_default(object)) {
      return nativeKeysIn_default(object);
    }
    var isProto = isPrototype_default(object), result = [];
    for (var key in object) {
      if (!(key == "constructor" && (isProto || !hasOwnProperty5.call(object, key)))) {
        result.push(key);
      }
    }
    return result;
  }
  var baseKeysIn_default = baseKeysIn;

  // node_modules/lodash-es/keysIn.js
  function keysIn(object) {
    return isArrayLike_default(object) ? arrayLikeKeys_default(object, true) : baseKeysIn_default(object);
  }
  var keysIn_default = keysIn;

  // node_modules/lodash-es/toString.js
  function toString(value) {
    return value == null ? "" : baseToString_default(value);
  }
  var toString_default = toString;

  // node_modules/lodash-es/_baseSlice.js
  function baseSlice(array, start, end) {
    var index = -1, length = array.length;
    if (start < 0) {
      start = -start > length ? 0 : length + start;
    }
    end = end > length ? length : end;
    if (end < 0) {
      end += length;
    }
    length = start > end ? 0 : end - start >>> 0;
    start >>>= 0;
    var result = Array(length);
    while (++index < length) {
      result[index] = array[index + start];
    }
    return result;
  }
  var baseSlice_default = baseSlice;

  // node_modules/lodash-es/_castSlice.js
  function castSlice(array, start, end) {
    var length = array.length;
    end = end === void 0 ? length : end;
    return !start && end >= length ? array : baseSlice_default(array, start, end);
  }
  var castSlice_default = castSlice;

  // node_modules/lodash-es/_hasUnicode.js
  var rsAstralRange = "\\ud800-\\udfff";
  var rsComboMarksRange = "\\u0300-\\u036f";
  var reComboHalfMarksRange = "\\ufe20-\\ufe2f";
  var rsComboSymbolsRange = "\\u20d0-\\u20ff";
  var rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange;
  var rsVarRange = "\\ufe0e\\ufe0f";
  var rsZWJ = "\\u200d";
  var reHasUnicode = RegExp("[" + rsZWJ + rsAstralRange + rsComboRange + rsVarRange + "]");
  function hasUnicode(string) {
    return reHasUnicode.test(string);
  }
  var hasUnicode_default = hasUnicode;

  // node_modules/lodash-es/_asciiToArray.js
  function asciiToArray(string) {
    return string.split("");
  }
  var asciiToArray_default = asciiToArray;

  // node_modules/lodash-es/_unicodeToArray.js
  var rsAstralRange2 = "\\ud800-\\udfff";
  var rsComboMarksRange2 = "\\u0300-\\u036f";
  var reComboHalfMarksRange2 = "\\ufe20-\\ufe2f";
  var rsComboSymbolsRange2 = "\\u20d0-\\u20ff";
  var rsComboRange2 = rsComboMarksRange2 + reComboHalfMarksRange2 + rsComboSymbolsRange2;
  var rsVarRange2 = "\\ufe0e\\ufe0f";
  var rsAstral = "[" + rsAstralRange2 + "]";
  var rsCombo = "[" + rsComboRange2 + "]";
  var rsFitz = "\\ud83c[\\udffb-\\udfff]";
  var rsModifier = "(?:" + rsCombo + "|" + rsFitz + ")";
  var rsNonAstral = "[^" + rsAstralRange2 + "]";
  var rsRegional = "(?:\\ud83c[\\udde6-\\uddff]){2}";
  var rsSurrPair = "[\\ud800-\\udbff][\\udc00-\\udfff]";
  var rsZWJ2 = "\\u200d";
  var reOptMod = rsModifier + "?";
  var rsOptVar = "[" + rsVarRange2 + "]?";
  var rsOptJoin = "(?:" + rsZWJ2 + "(?:" + [rsNonAstral, rsRegional, rsSurrPair].join("|") + ")" + rsOptVar + reOptMod + ")*";
  var rsSeq = rsOptVar + reOptMod + rsOptJoin;
  var rsSymbol = "(?:" + [rsNonAstral + rsCombo + "?", rsCombo, rsRegional, rsSurrPair, rsAstral].join("|") + ")";
  var reUnicode = RegExp(rsFitz + "(?=" + rsFitz + ")|" + rsSymbol + rsSeq, "g");
  function unicodeToArray(string) {
    return string.match(reUnicode) || [];
  }
  var unicodeToArray_default = unicodeToArray;

  // node_modules/lodash-es/_stringToArray.js
  function stringToArray(string) {
    return hasUnicode_default(string) ? unicodeToArray_default(string) : asciiToArray_default(string);
  }
  var stringToArray_default = stringToArray;

  // node_modules/lodash-es/_createCaseFirst.js
  function createCaseFirst(methodName) {
    return function(string) {
      string = toString_default(string);
      var strSymbols = hasUnicode_default(string) ? stringToArray_default(string) : void 0;
      var chr = strSymbols ? strSymbols[0] : string.charAt(0);
      var trailing = strSymbols ? castSlice_default(strSymbols, 1).join("") : string.slice(1);
      return chr[methodName]() + trailing;
    };
  }
  var createCaseFirst_default = createCaseFirst;

  // node_modules/lodash-es/upperFirst.js
  var upperFirst = createCaseFirst_default("toUpperCase");
  var upperFirst_default = upperFirst;

  // node_modules/lodash-es/capitalize.js
  function capitalize(string) {
    return upperFirst_default(toString_default(string).toLowerCase());
  }
  var capitalize_default = capitalize;

  // node_modules/lodash-es/defaults.js
  var objectProto8 = Object.prototype;
  var hasOwnProperty6 = objectProto8.hasOwnProperty;
  var defaults = baseRest_default(function(object, sources) {
    object = Object(object);
    var index = -1;
    var length = sources.length;
    var guard = length > 2 ? sources[2] : void 0;
    if (guard && isIterateeCall_default(sources[0], sources[1], guard)) {
      length = 1;
    }
    while (++index < length) {
      var source = sources[index];
      var props = keysIn_default(source);
      var propsIndex = -1;
      var propsLength = props.length;
      while (++propsIndex < propsLength) {
        var key = props[propsIndex];
        var value = object[key];
        if (value === void 0 || eq_default(value, objectProto8[key]) && !hasOwnProperty6.call(object, key)) {
          object[key] = source[key];
        }
      }
    }
    return object;
  });
  var defaults_default = defaults;

  // src/options/Options.tsx
  init_hooks_module();

  // src/config.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TRIGGER_MODE_TEXT = {
    ["always" /* Always */]: { title: "\u603B\u662F", desc: "\u6BCF\u6B21\u641C\u7D22\u65F6\u603B\u662F\u53D1\u8D77AI\u8BE2\u95EE" },
    ["questionMark" /* QuestionMark */]: {
      title: "\u95EE\u53F7\u7ED3\u5C3E",
      desc: "\u5728\u95EE\u53F7\u7ED3\u5C3E\u7684\u65F6\u5019\u53D1\u8D77AI\u8BE2\u95EE"
    },
    ["manually" /* Manually */]: {
      title: "\u624B\u52A8",
      desc: "\u624B\u52A8\u70B9\u51FB\u6309\u94AE\u662F\u53D1\u8D77AI\u8BE2\u95EE"
    }
  };
  var Theme = /* @__PURE__ */ ((Theme2) => {
    Theme2["Auto"] = "auto";
    Theme2["Light"] = "light";
    Theme2["Dark"] = "dark";
    return Theme2;
  })(Theme || {});
  var THEME_TEXT = {
    ["auto" /* Auto */]: "\u81EA\u52A8",
    ["light" /* Light */]: "\u4EAE",
    ["dark" /* Dark */]: "\u6697"
  };
  var Language = /* @__PURE__ */ ((Language2) => {
    Language2["Auto"] = "auto";
    Language2["English"] = "english";
    Language2["Chinese"] = "chinese";
    return Language2;
  })(Language || {});
  var LANG_TEXT = {
    ["auto" /* Auto */]: "\u81EA\u52A8",
    ["english" /* English */]: "\u82F1\u8BED",
    ["chinese" /* Chinese */]: "\u7B80\u4F53\u4E2D\u6587"
  };
  var defaultUserConfig = {
    triggerMode: "always" /* Always */,
    theme: "auto" /* Auto */,
    language: "chinese" /* Chinese */
  };
  async function getUserConfig() {
    const result = await import_webextension_polyfill.default.storage.local.get(Object.keys(defaultUserConfig));
    return defaults_default(result, defaultUserConfig);
  }
  async function updateUserConfig(updates) {
    console.debug("update configs", updates);
    return import_webextension_polyfill.default.storage.local.set(updates);
  }
  async function getProviderConfigs() {
    const { provider = "aikit" /* AiKit */ } = await import_webextension_polyfill.default.storage.local.get("provider");
    const configKey = `provider:${"gpt3" /* OpenAI */}`;
    const result = await import_webextension_polyfill.default.storage.local.get(configKey);
    return {
      provider,
      configs: {
        ["gpt3" /* OpenAI */]: result[configKey]
      }
    };
  }
  async function saveProviderConfigs(provider, configs) {
    return import_webextension_polyfill.default.storage.local.set({
      provider,
      [`provider:${"gpt3" /* OpenAI */}`]: configs["gpt3" /* OpenAI */]
    });
  }

  // src/logo.png
  var logo_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAgKADAAQAAAABAAAAgAAAAABrRiZNAABAAElEQVR4AeWdabClVX3u3316YOoWaJAZxCC0DKKIBpRBBKUcrppIohLF3M+pMhU/3FiJlBxSWLcSP8S6t8ovt+6HBL3EDBhvytS9xgARUeYZoUEmReZuGhpooPucfZ/f86z/++7TNHTvpmnAu87Ze613rf/8/New51H3G1gO/d7sHuuem1k5Nz+/ctR1K0fj7m1dN9q968bLu9Fo+Xg8Xj7qRmrrmjIerRt343Wj0WhdNx6vEw31k6NR94u5rlu1aGZm1fKd51fd97uza3/TwqX4vLHLm/9+dtnGF0anjEbj0wXkCaNuvHJ+3O0jVLvFMzPCUf7JSwGuhmDWtYBO20Pi0F8CkXuu+YcM+jndmaXrHtXlKrWvGo9HlyxeOr78sc/MPi0xb9gSj99A5h/997NLH97YndzNj04XULp175UTi2eMVhwB4EUNMXpE0wCudsYNtMdGAnnedAU8fFXgn3cmwU+y9PQbpfsaXV/SzYwv2W9x95PbPjP7QvG9Eeo3TAKs+PbsiQLiHOH6OWG1gtmdMhbY1U4P1wVU1YyQJLUSmJIkMbCqiURrJxkC9CT/Rik2mUipWRkqpeBR5xptN3+n3gvXfGH2Sg2+7gt+vG7LfhfNHrphfuYLmn/nKNZHZFa32asog98k2DgSkNXowRVNJQt4NQSryTU4OhDVbhdz8zoBuKiDPhEGdGBfsBJ4mDGdLzrWEqm/U9ZcuGRm/tsPnz17X+S8/u7t6uvNrL0vmn2PJtRXtZd/avFoRpNqmOUYbJANMAkAONrHFfh+VWjoqqvvY9zOmg/Em+sQvURfgSn1/PdJsnFeK0HjT5vcEPDIEhX20nYfps2Pv79ocff1x8+evfb1FusWhdeHWXte+Bc6zM2fK2vOrNleM7qWec9mBzqzP6i0Nv0FrISEB1AouFowVt9L9S+krVkPdRUv+U3cnDI14ocVwuMirmRp1z8cj2cueOKcr11ecl7r+nWRAHt9+/wztIOe143nT8ksHvVLeQFf+3clBECTJDWzSYwB/4WHwMkgJ7HIE3gZqWQI6JsDG6oCtHQU3TDzI2neZ4FRgBdfnRsqETayrYxmLtep5fzVXzjv35H9WpbXNAF0sDtIzv+1br9XQANQgR1QtbRzyGuTsvbzWiEIe/FWIGtMopwgMOchYQO7yUoSZPZyOGTprnwA4El+9Ot5hVLhOkkQmZUQ0NADL319gjT+oiMhZkbdP4r2yzowPrBA8A68IBQ7vJx26eziWx+c+RPtlOeNxqNlAAHoAMdfD3yb1V4VFEwDTWQV4knQ0w4Qi2YWgVUDPq45aTwMqG3ml+c1pcNu4OCiu2Z9BEbWnJME4jwUTG+jdXfrlwBokeOUUCOrgVYHrRJeKSLj6ZnRzPnHHDD/zcs+OLux5O2ousKwo/R1e3xn9tSZ8ehbAvtoZkct+YBfQAbo2sOpYyYrATF2ohjIJELN5B5okcNB8D3z7R2HQGY5pbUhMG2b/eHSOJRQtcNcWLIiqM0sL50kSSVVJUzqIUF8LVVJniSLVwfJN7+0aew2Jcofrf387I9Rt6MKfu6Qwqy/5YHRBfOj8Z9ysi9QAdtLvgCdIfCyKHNYtR++kRiYmBWCVhKFVgMYHEUTfmZ4gIXOoLdrM2hInS7eWtSqmQkfciCpAn/2bZg0ov8CEjle0s3X6NS5aSLAT5LU9pDZH15o0cejBtkxViz+6h0HjM/dUatBC0W5++rUKy664OBufu4iAXsSs4rAF+iLBFufDO3xeq4DeI2BWu3jNdMnZ3clhQFvOvAGffCWo6U3YKvXmEKTkuW6rgb+WrKRh6w61MFZZwPPZgHNmIk0SF8SoiWGgK4Eoi7eBdtCN75CWfy5HXE2qLgMHm/n1p4Xnv9xxeRvNIv30l7nuADCYu3VrNH0ZRuomc2yXttB+pg98EDPHk899CnWGirZADIkTXCAgFWFsSamr3GXvioS7RLQBn4SxgBbzsKtgaSxbHEafIBtgqiRT7/BVjt1VgSvPiKgD/nISbtbreYfPnHOeT+wQa/S3YTr21fD7Hh25r9f1P1XvWjyXzjDM+s9S6URMLK8Vzug9n3Q6ojMX4CvvZzVY5HDXcs3AauVAQ+cTIVGc0nrTQDX9aYO10pAzehkMlQSMEQ/tcEGVP0VYAUw6gbg87QxAIMq/SVvqNsKINkkSL3ewLjppVEvcn3jS2d3fzY7ml34EARl26FsGo/tILLreMHmoRdGf6unwD4LqLXkF2j01YwEsFq+mbmsDIDR91UiAJ3+6cdoJ0az1n3qBKAhGaBixRjOAQZRvYDnOduAjZicHXyg06i5DVwd8rLqAFQlQwEJv5/5Ex/PCSHbY+YfVgDoCly3mfWirf7IzlnCZwKvCuKfGX13/yXjL74aLzTh53Yte3//L5ePn15/sWbdhxBcyzmAoQxAgMQzVXWNG6y2ShDgWtKLL3VWDhLEySS6ShT3SXYKmoYkoo8w00spWX1HA61mYKiGe2Yjf+EPQCQKJTNeBzgSQ39e0tWfmmteT8gSjwDPbL/GkBUk/KwAc15dJrcH0xb/eP5HM8t3+fTjn/rKOvRur1Ix2S7y9r14dp+N60f/KqHHT85UwAJ4UDDgmuXUFOiqXasBwS5gK0G85xNBlSSPxEmeXgdGrEeKB5oCOcCJT/+sOi5UMG1aClSBEZlZKWq5h5z+JAqS28yXIdg3mQzQBuwcCGuF4GljoIZ5wWpQy37bMkigWgUwy7K68XVLlyz56MOf+fPHkL89SovIKxe1x3cueMvMeO7fBPPhBZCXegBW4J0AUgOgjPNHFACNa8AcwM4KUHK8iMtSaAN6ZjogU7gP+AGlDpj9hi6m0m/UymsQpHDd2k4YwNSMnuSHLKd3EbbxYq+EYBWg5JyQmmv6ATsrhODHiYn+kgdNbQM+CMoo6lpVsiKM75ofLfrw2s+fe7+FvMK7CsUrEtNm/k8AHyAMlIznwAZIAOlZLr+TFCz9glVjjLstC0wLyGpXohTg1PQVD4Yb1MSytXWhAR5auritO/EZYWhpI8x9IXvxvcYbbRIh7AaiifJs79sBHgAxIImg84CEoIq671OH29LPQ8u0h9UiMnRN0jS+PmFET1u671qy6/jkRz49++iLbZ+uBxdeUWHPn1+3/lKBd3wd9sh0A121nGWMmPb9BmCgA7iBH7psEwSQZZ7AOomQYVntHKBrEoc//r3MW7YGVIqH8awPyJJQjKFJ2Uy76AvUEAJUwObMMQkM9Iwhqp4z8LU6BBugKRnCQyJByFbgRFI/dW6VTFxr3KuH2qI1D32+ja/TmeCDr/RMUCEo/6aqc9rvfiBAPlSzl6DWIS/15H5fgA+P/c3nLSArBglSB7os/QGewC4WsP2spw3QGkhflvkCLgnDfc4IhTLJQ5uVRDGfaHOhWam/9Lcx9RVgarpkVQjgAVK8jalmLaTM7pwN2kxXH0nDwbASJst7Vg2AHVaLYRVAH3SMw0cbObr/0X5Luo+/kkcHzaU4Ns09j/P/23dG/0sgfLZmWSWBZ7kCTbAZS9AzG73/T/T5gAgosgTAoQXX4gMW0ygxCHIlwCTosbslRHMiNuFegEW+H3oqmI899Ej31JNPdOvWrDVAy/fco9tdtxX77NPNLFrkmdjzNX6CT8G2LOe+bLRtZZAq04nGhz3xoJ0VwSuA22wBSQASASBDk60Bfq8Kok07126zGojaCahx7Jgfdd/94z8Y/8G2Pk+wWHK2qfAkj4L0WdmvN+NmiScBBvADiIFowWesB1mIQF83keQMoOV+SJjMVst0hmjMdZJirPcKDUAnacikHCoJKyXXL7zwQnf7Tbd0P7/u+u7ZZ57N0Cb3uy1b1h39nuO6lce+o1u0eEnAFD+gLxoPiVFJiu96D4OTl/R10pDMlBEJk7451exiNfvD745uo+YxgDt2KGIC6JokqThYLspYHQU6NPBAruvP/vfvjO6Xsq+gdtoiEdMXnt5VXP5FS7Jf1MHQAB/w6tRfQDA+OfPrPOC+BhBWWE5LCpY6ZNZ2UMEI4KENDy4EZAJFnJJ0SACCUffYI490P7z4n7vnnl0PyxbLLrvt1n3krN/p9tKKABBEGlk18wl8Le/Vl1mbfZsp7ZkqY2rfR0D28wDufhF6FmN0G/dS32a6VweNITs3eMPv5w3U7+1Ajqv7E9vytDF+TVV4YWe8ceMNOpjtBShkbi3jBJ7DG4c2Ao9X6VOC0BagAZ+Z25JC/U4UUbuvJRNI9jMfuUQdcCWD4usmX5XkZ7b5IaDGCTDAPXT/L7sf/vP/7jZu2GC+rb1bsnRpd+anPtHtd8jBEtMOkBLJoo5sAy69WY7beUBjc8GyTxyDLi5sr707ycMSPyQAYxABevXXFkAcN90C+kQQn1eW+fHq0eJFx605+9xfba2P0LX1autYeEnXr+oZ/PYQrwFmsAQOwBB7gk8bcAHW4Fd7E/AL+CTSRNIgo8k0zaLIWuokW9QtbfJ2mlksOnTFJielxtY/ta77v5r504JPNDZoy/g/3/t+99y6p9vyTMJyoI0vO+ldniT1UunGR2xapIe9+Ozl3Ndlf+wu/opJbYflYx42t0nVfGOsSviG+ExOvsUz3V5gY4yKYSvqQfpWEPN6/sy4O6mAogZostul1QTBM55gcVOgoMVhjjwVgKoTsDjuYIjOMsRTupCTgCWoFWRkVCCqhneJALjysv/o5uZ4KnbbytzGjd0Vl1xqcG1/gYst+Cgd1i/x8QW78Xmwv/wvv8xnmqyAk/yOTeOP/MStYuHwtslFzBV5TxDOF46PsLnlwdEF03irl+G2rvBOHi2F/0O+6bUJ3UnpjLM0gNhIXScQrZ4Yp5+lFEPttNoBF1gTMF/DoxuvBVQw0QcPoEJrWTI7Mz7OYw+zEJuQ+NCvHuh+qgR4pWXtmie6Aw48qNtjxZ4BXYr8J33UBF+VfSMo2FbXjLuowgfG3aOaTRtbKQyxajI6htYeWExWU7jMb3I4dIMhZyRyIo83eGjYnbTTWadd+tzFl91f1C9Xb9UKwLKioH5Ls98v6wYQLXcyhGAHqAacr9sy2MbioE66ujb41AsyPbyeJSYG1CRFEoalPWExv8aqruSo5EEHiXLTdde9nN9Tjd107bVJrrLf+ie2G9mGfm7YM8QlsXFSSGNNEsb9RJdq08OrZHDiq4+VAFA9pn6PNbk1KeqJsp5GMhgDI92+tbVbwVY9DLzpgdGXdbA7mn22lrJalgag4nhAJBhkaTK+B74ZOckLEr4mKDgpGjWtBxkATzQquEitVwqh15vLMoMaPxfPPftsd/ddv0D0din33ntv98y6dd1uy5dJniyIa90iPWeQA50A0xQGNHuMCz4IqYPDnR6s2y+Pi4ppp34Oe/g1x0dfOAMyfwU4jyD1PgAfMEkHQF4ME6rVD1nu3KFHHBInGgsWmQ6IR9/6UPdldXxDt5ctmPKyhbduz8yMv+ZTtSjrdI231RcBGGAbGXAwWB5tvJxyEhgwBYNsV5uAVbtPnDY2OYtqtlcScM0sJxFqduwkMLgm0D+/+VYeH9ue7XInf267+RbLxp+lOgDiT3zSAVBJmANe+ZaVgHFZ1duYhE0yeBWQrRTa8a3NYuKEfMeLVsU9tbpTCCAXqvtHKqIm9+bnx19rb7tvxJuvtpgAkvxNubNsAAiX4midagm6Zy9AyyBAwSHGqT1uYNMfl+rg1MbFBx1jBhUZ4u9le5yx6LeOJtN86BU/jwxuvunGzXv7CnpvufEmydaJHxsV8+iXfdigm+3GV+xX7Rv2s2rSz63R8ibXvq0+QHTcTBcfe/ktLqZHbtPVy2tye/3EAT2jGd5u/80tufyyCcAndjSTzmI+s7QZ5ALIhpVzqqU0jmcm4pBncaNjDKMtiwD4usl0OydqkSuYopUey1BHZnqSoU+QJtc2iZ+HUNjwwAO/7lav5u1027esfXJtd5+2AvRZ1wL7W9AJvG7YXbaTrrQBhZmKX3m4SDxox1e57eUzQIu/4q3x4ofe/egxb8Wv9CcGLAzeksbjs8Dw5SLxsgkgQedNzkIvN700m4yqfhlqSmV6K2pkaRquKxHiKI4kq+Mc4Jcz6Y/+5qgc50mmJA+BaYGogIj3puuvL+3bvb7xxhui2/oKhPhQ4JT99tP2ZnwAsflbNgNkyZP9ta2q26VqlnWfL4gpI228UaVi69XNE7HJBMMMbv7+JROAD2oK3FNKYDlYGcp1W2qcjW43h5P9zXFZGtAnsld95m8AVnBIMC/xqhkHaOvHGfFkViA3Y6XfT8KIRs9Qdrf+/LbNe7odem+//Y5uo54gwpalOnPUSbwSEntik2yV7RT7Zj+VsOLjP37E1/DKH3zchJ+xSih89tbT+hibnJyWs4A/GaKHm6cEy80H4CUTYEaf0jVIEuoiAxYknWa+HcFwjZSjBWYFokCqJ03K0DgUIFlE9O9EKTnDzAdwgpMtwm2uSQLpdeCodX3Lrbd2G6Z8ynfzYdl879zcRp0vbpbOptt6my3YAzitLv9jb5ssACQasdnhJMJCfrYMeIq/4jeArfGKefM71hJBiU3lldcxEi1YhubF95tNAH8+Xx/RRpiVyanK2h4AAVKOsMxX8ZLfjPASjbEERQQGrNEmncJnJ5sztBPE6KxAkP2WU+Ajt8mu4FyzHR/7lz+b1tdcf+0AkPWXHfg5OSsnZ2/asT/Jg1+On1K/4leAVYwrmbChtoayxzwt7IlR4jy0E0firLchngmmxTtZbzYB9Jj0qxiDsFJs3Bp4NhDAlBbQ1KylnlyysK/4Wd5xGIPgr/27DC45A79ayNNtQWAJOjcSoZfFK36Pdg/8+oFJ316V9sN6ZfHBXz/Y29/bYpsCrm2T3RU/aMpP0+va/st++91mfQzW7EngVLWHyk2W5TbfHZfiJ0bq78sEv7HRGJj24xONCa708rUsyslPtUmc/RulUpYMhq5lrRQVwANQDRzPVDlO3fPjeGayA6J+AIc3CTEECrlOwkl+y2n86ufxeGwadVdft+O+fOMa6SpA84JUxSZA2F9AkY3QUSqxqd3f/Mr1BD/9/U0J0uQUkEXvFVRjjj9g6VaxmOS3ct3Nj0efAtu6rvpFCcB38tRTvjjiROBOyih+CNOAK3Cpma2NpE8K+Wp+G8RjYjuWvRzFk/wEysuadOFUBdiJRdBaIHPwSiIVDel93c3TP/Y/9u1H6nnTF4XAfr7c3fW33KTD4IbeRvzKw9C8tOLtTnKxOROD2CQYRBG760AHDdfZxlqMyl/xOP7iMeDUElArY8WvZICNC3s3ikRcScF7N/J9SyGp+814P/4iCqxYdwGPrEzmWjCDKGgFGjIz2RmHTK8+jEyBiZUDgNWkMVEA3fx9MDITeifRL3nlEDop1Dffdlv3rJ7+nbb87pkf69515FHTsnXPP/98d9NtPDMYH6hrZcMegylv6Lf96guN7Jd/+FqAEmhHxkGhRWgSpEl+r5L2P7FmzJxhaZMu77PwJGmxskBT6iHi/Pw5dV11oeNrPXV4op5C1Fu7y/BhVkNgd6XQTsqpApwBxmx4UkeOtmyWw8irwGRGKEjwt35nsANXtAmU+Ro/+uuwF1lNv8avvPYahqcqB+67X7fyLW/tzjjxpKn4ivhn0ln+10qEXdjMk1345BO97ae/ZnnajNt/1X2SmzZbYuI3xGGIbywg1pvyN4REIJA0TlUxQ4dAOgKMywfqBQkg+nNwRvWCUo4GsKCNkwV8zdxJukzzJqYJJPM9izVdkIVRXg4lyAGhbkEMXTNP/PSX/gQvvGufWNvd8Yu7Fti7NRcfet9JHW/qOOHoY7s93qRvkZ2y3H3fvd3qxx/v7U8SlP3YnfgMdic5iJFpqfG/+UWNzwGRgLWgtVbFpfip8ydKryjEaNBPu4qx0kWSs1uwCvQJwFu8JfFzMMHqDCYjUVOyWsPGYrwzNiJsRKPzOGMeD7i0oUc6fy5Uzfie30O6a7oqEZBZ+qI/zv7suqsja4r7xYsXd2f89vtt35JFS9R+3xTcA+kV112ToMuvSv6FNsrf5l/vcnPd8PaBBW4SpiUHLy6REC0pKp7W3PhpJ76JM5ODMohscZdi+FNM8zlj3XpqpOPrV/VK4woEWZgM13+T2DJLwlBaGcc4huN0Od6yjAE7jx6MAsg+e9WBUVx7Vk/yVx+6uLUx26Vr9PTZLwNYiqctJ77jnd2ey98U+bLlzPfrSc9tKGw9+lIPWRW7yjZiUA9zWcodG3xRf60IRYtfxKJuALIghhoXq2NZtBVHcODPsDYbGIPfyAAQzQm9ulzhr9pVN6VPAL16ejoKTM89bVUxmt4Ut9wfo3GIgq6UyHB2tnMARllw7opwImkWLu8O2ERSlMOV8YjBrjvuurNboxdppi0fef8HxD+sUIfss1937OErpxXTPfXM092td/zctuC/AZLdyMYHQMVO+st2J3Trt59q44/nC/cEXSXxC78BVX8i25MM8ZMuADAGZk+isf+7NHAYwrZ5fc9yBiYSQIeK022F1JBVnn1Y1pcgbDC0RJXBUNB2Rk84Wi7BzoElsznBKFrsqoNjOaeesEqqA4fjujUf1JsXOxj78dXTfx3vPiv26t575DEGplYYZH3k/adi6tTlctkAPz5NFmZn7KcfnxK/vlZvraSJaUuclhyhazziR0pNRkD07J8QmWSqJBkGykfiRrHOUbcwAfjKdQ2810DZGWUOyKpdpWZMwIgw07dMp8cgGtVkWhlFIFICM0YwlvE4XsGykxpDH/Ip5ThPinjrUM2HO268ffoXfj76vlM8u3htfyedBTgI8q7i04777W7ZLrvGzCnub1l1R/fUuqeSBLK5koEZvNB++YRfupWvPqHrmjgAEN66ln/Q1Qke/xM5DGOCZsLBhw7zGQASBd428zVWGBq/FlOwBnOkOW39ffuSCZGLAKqEreDbGSlpGWRQUEYp47m0kyimH6MoquNMrQAykDEThAg3hoRgCWvOOKgJBvtqBfinOvxN+45ffPioZjrvHir5+IDMZTvv3H34hPfb3GnuiMdPrrk6yz2gNRuZeQEaXwpMtdU/gBnfCYO3iwl+4pP4hSZxHRIFGxm3H8Q7/8FbA4Ub9iGrkhGbRLoYzJFhxPmxBQYAkj+kFBiWbGXKUHHakJZ5CHBCSKQzTLUVokKF+8iJ7KE3g/X0byWNHfZduJ3d6JRibsjKvjrT/cc1V0E0VTnhqGO7g/fe17aWfwEnK84nT+pXxqnksg0gp5KpwMTfBL7F1RGRL/LD9C1ZiKui7tjhPhBBg40VfxskupKdfslt4EZeiz+KrYv4J9lNaCHEU5byAxsqToD80kby0sphDhqNJQDjILJrCMML4KbPDgcwZit7lUyBED7d/EZPEceI9HtANP2bTsVXoEcnCZQAoWfVPXd3Dz7yMCKnKp84+TTbi0z02/YGBu0jD31rt/KQQ6eSCfGja1Z3t961yiEgQthKMSi6nlzKAbbAwHtuZQvgEipPQgmhrlhSWzAMCirXyOWSftfIAnDD2qwIANaBPLPDoF9XgbUlwHilldKBIqioWwEYX070QUfOU6yKO/U1kxp7jLCD7bEtAzaiZRFjdjJKLY87ksYrhAFaOPt/fM30h789ly/XPv9eBwKwSQJ8qISs9idP/mBvwzSNH1/9M8/ayEly0QbwhkEvLisASZgY1zJNbCb5E9iwETUnT4tTIqtEwBfxOfyQWllmvjkLRtUkGMVd47Ef9szwA0vq2QcJgOHZGulGlmAxFiMzgOHYzo0eBBrE6tQ1dlRmk1z1p6E46aUJg0QInyVh+DD7EYLj6EA/9Qa9CPOzG6Z/29fH3veBbpclS20nAfMBUIc/3l1MO/bPdJ/UQ8Sd9LnAacvVeoFo/frnHD9baqOH2GTVwU8VgmOfSQKSRXOWa/xVDSsFmxijVPwrzpEk2sZDP3yFH236YkFU6sL6UA/mYD/Dr2sxQOBjuEabncleqJtg9ScL3RXlIsYJO2TS0Fu56G04/LpBR7+NLDd1TV899x3jcCw6hxmRZ8eu0BsyXtgw/c/ynHXqGZ7t2O/PEkqnZbeE49EA17vvulv34fcseLo8zm7hfqPejvaTa6/yCpgkzipg/+V8fGbFUQyaTkWnSQ3wPuQqUsQKLJwMCkTiq04GWqGvaKCGtvoiANmJLSwaTlHtSa0rsJ+Zmxu/3dnXxqtK9jQecQMIxhegCEdpeDUoAieQ+mupUYcKDoXOjiHIAzHYW4bpkBF9LMtOirJajBXIS6+8IkRT3L9LT/IcdsBBWS5lSxKxLdNca0OoPuqzTv3QFNIH0ku1DUicCrMxzgA28WAFoFT8uELXwtgLSPrFQ2nhMHjQWq7j52aPB12Rm2SJJiSkmNfCwDGW0adPLq/kVUz9th4sAQqW2sfDHuFZIegRnRNiUpn41ZfDTjkfOoDESXjM7ToAW21EWnvNDBwKPTzSo1H0P/jwQ93dv7rfcqa5+/QppzfbAnrpIQierZ6RQ/u9K4/u3rLvAdOoMO0vH/x1d98Dv/LJqGYZKBJ73M5KV0CmEw8DbnyGFpBImppIXIcuMbYwgqSCHmQTL/4oTjb3cWWJLamQEypkyh5N/m58WMgyg519BoneFPpgoKDCBqqPkl53MqCGFJg/z4RBUzyM4myf9T1zO3xKmh0RfzMwwZEARP/7lT9F3FRlNz2+/9gJJzuJCEw+xp1VgPZwXWNJBLaMbSmsUPiAvfhK7OJ/pNEmEdw5RM99UPb+iy7xgoNJ1Tpcc0V/4oIe4sWfqSWfVc1wpMeEbDHm0R0m6HWMw+jZg86ooZcrCj0ytgHNZXInjjGGUlPpbkgcmSEZToJWR2RmMXyRjKqsIpXpjCCTBGE1gc861fBHtfXq27Tl4yeeoid5dpV9kWlQJH94O5nOBH5rWW0DWZ0+ferp4skBbBqdP73hOp9RnATyAF9r5qcv0vB505WWcacLcTNZJkTpd0wtT7CJwPFpwUQesaKv+p1oTQ6I63+i+GIPcfmnVD3gmUm/UwcxBYBFSnD+SlDVvSPmg0sgYmEpFLubqgG4ipdJDfSJJD73iYY/F41j13W33dw9/ewzxbrV9e+fdqZtKeANRgs+ScsNW92WntDNdPvuvqceNm72jbQvq3v9c891V/EBEsl08ooal/HfMWl+2T/01QQTheNAPAbvrauANE8TFvkMhw8FjKMHhZBV6dvqI5amES3YswIsC3MDCS4RcVVLC+30pA+SABlRXCMPPv54bxrZyqjp1LCjqsOR+7qiE3b0uTQ5UCVoo+6yq3TAmrIcftAh3TGHHpZ9HtBbsAtsz8LWX0lMAlYSfOYDH55SY8htq4xn1cGv5rTD2vtI/BdIH2Z7ZjPjDVzRxXZxLGSyBK8skhfZ0IgTOt1IHrehZMgc4OLGshkBxA8pZwBKDQRcKEKV7uQllDBnOWr7PARNsrNUfMgo8C3d1xhBULT0AwaCuDXmcoS+/GXk8bWru1vuvMMWT3MHgF5ReuOiF7DrsbfblQSyafC96z7wjnd3++651zQqTbvq3ru7hx59xK4RFsdMtV0tW4hDc79PikZDRHyDQHSOtZnpDUb0A27sNZnpiBuCe3LrCzju07WlhFcrwFi/oq3i5R8K0QZcN6LP3RHicRhaab2x2KIzIPmWg/PZWpwGHjQPVgxXvTPw4Rx/tUX8x5XTP/O3VF/z9sn3n4Yw3RrwAtqz3rOcQ9/ifMRL+kgEbw9tBRCTP//PWWBbymV6fYA4Ai6g2GcJwr8ecLXdr7uAwyqQPq8CXKgE5LTdkV7dN2LThM5UTUhwhDjBzlgeztOrGC/XwXC8PAYmMxjo0werAF+cGGFnWpJwTdNGtL7osRqPmaY5byeaHPM0oxIBBIUPiTD7T7XepNr9eBte+PmQnsx5k77uDQcc8GYjdpBcJKUBF0BJUJP2VhTPWSdv23MCPCnEk0N9bNGPCvTbVV23PurE2CSODNSOmRo9fQT04YtsPCwaJVe/sjb+jEbWBH+LsM8ADkgJm5RWGYQCCnbTh93UHk9nnLGlzWL1F7+Z2134bTIE1as6WnrZ6oH2Vr3evkbf6jltOUszd0v6GfcNz2xSfOvt0vhB+q7AE/Uq4rTlSX2jyE16txDJVr7RRJ+BRaDa0TXEFDtiU+oyrdc/wQ+dqKIBPv1V/OiscfRD6bvGb07dsQWsqyyNQSJECv+6uSBcjHyX3ZDBkISuaW3Eklr89DQSG0NbY7Z7UwWyDhrGoLFu0V929fSP/Q988z7dCUcGNOTwnXqT+gkEfXzZIt/j5+/oU5/+cycmxjEeW35vG58TuOyqnyIBTxfqjybHJncVk+i3/8WJA/q3/RomMJNtBh1TxuSAv1wSBtHRb2aPadDdJIM91fMAo3X6ENB4HR04bMXwgAL/0PkuYorRgwhFIHdGjWtrgIlR32Osg8lYycyIacyj60n9dlC0a59+qrtxGz7u/Tsna/ZHukxLi+/yqW/vJEjcXtBXyD0/ry9rVRv9poEOW11ISL1/6vgTut138xtoWv/WVbxbaPXavGcRic0U60t0iNcwkPgHYGwg3mV/TCKATbeEwUo/NGlXMkDXeEspbI09/nExXqdHWaP+J0iQbfoWAFfWADdQx6hkFrR88tSqLdzMCLE5uYeWrjI2hG2GoawZaDZY1Sj5P9MTP9O+64evXvvESad5VgfUOaSqyALZUkD7WzvVRzDcbmOhzX3R8jZy3ko2beF7iq649mq5ZKeS62p70iCs+V7fNko8DaZsqeL4OTixPwHSqGiIfROxoLZ8yJvPLagv0i9d6/Tb7ON1FXCkWLeltpnbLLETahMU7AlPDDVP2aza2dtbFgF8j1110TMYZ2GYaj43RMjf5Xqr1bTlxKPfqYduK6SLoOM6fgB0k69+fPDS79k+tDHQY4zbKYfOcrb1qeErdBhEgO1RK78lQJcMwmmabuSCbgMru9Of2e3vAXQiiCGumdf8Yiq+SJHXBqn5jHx1mF13HgrDOn1N3Gids06SCApffWZppm6Gi9/GWGrsjkMmal9SGHvKUQLp59j8MAiRMbKML2AWYRsvSbWCo4tEe/f993YP67H0tOXuB37ZnfP1P5eayMSekk5d9r2UXNvZBhe0ZRery7xiNE15fM2a7nZ9cunw3zrMyRWAJKEhRMyxKRMq3QHeQTfZ3Fy2516vhpwQ6kCefQJQ2nir2G9aSj76ep5RRwKMn2xsGtAQowbEDR+UeN68D5zkAy5flBZDUag+faoE4PgKd+ShEGBdG4TMrnzBWpmnmcmX3omFr1qjAb1+Xlazf/r3/CH1kSdW+1YaXg/1FVrJDvut37IpDfesNCQTHe3DJXx7qL93kPjpz4nhhBMNwBIoFeJPM5FOP7ByPfBlezOD7vokEbkhYmA8flKHwO7usIbUwtPs71mSDKR5UIMRMpBrX+le11Xop+CMidS2Ye7TyRsHTKQ72HSb1Munb/kI9m9KufHWW7pn/FX1mRD4WjEirhT6+v42SMyynU5EouIsGsjgJ86RM2AwGU9Tig5Z0BWVcu8X+iHv7o4sktxHs4FboFOzUmxhFJU4EVRJYAXqyym7KEPnvRaHyXSV1PmJlD4KdoYVIjKv1ff88QMPvyllo75b6Nqbrpd/dbYgfg6GQ1BgOa7qJrZMOm4Urome4wMKxLKNEW0u4R3w08HXfeZGgrGhLirjp/fXzuiZo1UYALyGGEG6AVxfmj7vV4hrBjHeJwsG2V5/Jw1UkacWSp2lMKgUP/LKeevWmFRt0+f9kPt6Lj+7hpeyA6jBk6OZHOkjJoSQ2GtHcIwatfjyHIwJcBJC9dWMTlfi7QOkZKDKZI3O1xCqwA3iYD+zfOf5VXRyOnUGwRVLGjgRBo0TQ3QudIsOXQWiBKjEEIxDEzwFLkqHxBr6a+ZT8yLKL/Wumt+0wruZfq13DE36SlwcMiJv4HMGcH8DcWF8Q01sPGmJsSWkH9n5o5u+rKhquKCDUniB/cx9vzu7VnSPIsizWUSIbenTE6PHwjVoRQ1c+KBn+c9qECWIQBG0ENicNJ19jHmJwyg7Ep1X6nHzb2rxKoCvLRhMOOLjZyQVD414CP+JdR8/j6SXGDum0EpOwte2C4tu8ZTcomOilk74PdH1cQaw9wvw+qbpVShEGEqpc4fS1qfajChtfaWAa0Csfi7dp3uUQ8etfwxs8rhb24BrPSt3g76T9ze13HjLzd2GjRscY4PLIyDHnThVXAN8JgdhTZyICTFMXOGikEDZRn1dgwKQCZky8BivRqNer/xOAH1M6KqWFVaYmSz2JoOlgz4yFf4kS8BN9kKoETJHzextGJZn4dINF1tNVorkO32NV2O3/vz27tn103/Xj1jfEMXfLaQvs4zLiRX4AuLw03LqyH9iKQJiZvAIlQoxqzjCX0s72HiFEFbOKFPrjoRQH3zQZOse+3F2VoDx6BKARD6JAFEyNBr7JUQjGFLGAGwVnk6dkwwz9wOhn1h2PF5sJQtd8F9//fb7kYey6/VWX6/3DDq2AsS1/KYQ6cRfDQWIhMgkoT84QAdKXh0gq0DS32Lo+EPYGo4xCSHiIJvVYSzMoXICLF46vlxP2mwkS+CzOluU5agA95gSAEEAZmBtRcssCewVIt2SNCaZtc85Q9VP5joTTdd1Tz75ZPeLe+5pV7+51f36FbM1T6yxg/3sVSwyy0kKxZzZ2uKTSLACt+dPGFAhKYifgRe9c0FDlRNOLvCEHkwbH3KEx0YwR44T4LHPzD4tedewlKDcGYYkgwtZWxFQpL4SZnobkRx1hjWFOMLDGeqNNFySg/BXhtthJdMN2/Bxryb0DVddp280ByBmuIEKnAaPSFZc+3HRJnK4qvjrHowYhxaodGm8PMF8kevC0HqQA6bC2piLxAmgGgVeEmhTIiiZyLUZWz+KKUmEZGL2MGWwxrySyIikBbQY25aplmAbGY8YW3+LvoT5/5dyq3z1L5q0AGR2kwxMjHo01eLjGGmMuDJG4jQ+VxqHJFtDA9g9RDOywKPwA7NJrPVaQCsz40s2zo2/OsN74ZUkZBWlsnDRWK8cT75oI0NMpYr31VMwxEmhF00wtqWlR3iXv3PVgpO1ZCWZce9993VPPfUUIqYqJ777+O6Itx6mly7y1m6YEc+7cSn0UrKQVR/XzKIWORPoDuNVktzQDgnKXPWYaCr49NG+Qe9XuGXKbyp55plnujvvuqs79G1v8wqQaKAvN5zIbw834PPMkJ3rn8eXQTWrY1PszaTk7MWWwQrRYGj+0SeIL7FDuusTYL/F3U8eGndrFIAVZNnCrx0FUMDys0d60UcBlOTKKo852CxVCrqUtKhLBZqzteCY37OmfPXiI+BGknvzjdN/zStf8fo7H/lP3Yrdd+/f6Ile5PNeP9TSjna1pats8TjG6L9PUrW9cqmLEp/CUQFmVSRBcI8+aA4+8MCpEwD5N99wY3fI23iFsG2HyJPsfgWFCOtRZjuzKqOXFQM7HH9+Z462/gr0st0SYFc8vMqwEsx0a8C6flOl3wL4CXJl199liVAAMEYMnslWgDiUSVEbq/0GG1OyP8FjGgUIY7hhMDUSKLDAt14vktxz5/Rf9Hj0ESu7ZfoVL7aeHEiT8djEO33Q/wKBsn50103j6n9ez8+Xf7Rf4LrJis2h34As9b8A+E2GQdAMQ+/++x/QHaLfFZy28PMzT+t9gw1bWQuIScIkRdmrGhzaOHq8gil2tU1Tc8ukKzAy6ey/xkgQ5gUYg3XZ2ycAHWK90BneLixKTBhUyjxLNIARGEyBp8YTnCyZtRxBk7aMBhAZBB3G/fyWW6Z+jR1573vPe82P3gIGoGwLOnqbE8Dn5/QEjGirHzoS4QXeEtbbnz34+Qa6Z43G4KNdtlOzKluvxk6ULdMWzgA/1y+RRVbTIbme1RLm2MuHCjJ+Wr9o7LMoKv7FU/4lgfFKBdRVSDAO4+q70B3tbkECrPnC7JWiuDMBTWDhcGmCqFCAMQm+wMZO9QfkIZNJg8EoOWnQUxc/QZi2LNfPvK884og+EAYewHubElD8wMYkRhK5aO2Dx7CnJQ7XuvGXGv6sLEOShb74CfO7jn1Xt2TJkmnd6G4n+ZvdyEFn2evlvPURN2AMlE2NYo6/k/wtbXpKMIn9odPlncZ4wtIFCUC/9lZnSOGOo745EDJTxpjOd1rymyExnODULUGEd7JM8j/y4EPdWr1jZtpy3LuO0xEipqOXWy3pteQTHHQzy1k+CQRt03ssK1DxJ1EbvXyA31uJ/UnCI9tyvEIkEfBnydIl3bFHHzOtG91Ta5/sfv3LXxo3iZkogkrXZRN+xJ8hof1GGnE4nqKtuBor/FNMuNU6zXhhO6GoHZMnepbMzH9byvQXIG0Xd20FKIAJnIPNfJFCbwktRcsYUhbWGJWAmd+AzHerNAO2pRyvBIj+SjaBKZnceHgJSBsAHh9aIGqm0M/NM0P02MYYyeF+gm3fmmy1n9dY+NVXelpf4jHfHX/88dviimJwq2TKBtsSe3hGFT3E3PGX5AISGIj1Ahsn+G2E/PFy0ejso0SB7aZGvmgFePjs2fv0KOr7AbEZhHEtkDgcWNu9LunBIG5Wph5nbLt2AkzwI4vnxe9dNf3h75BDDu723GuF9QCMZRu0zG5AZM0pWxj3zFdtH2S/Z7fomOG+6RxAXwUVsL2iwKNbZj4rQt5C7uQpOT48jruDDjq423vvvTeN7xav77/rbn+30GBvkmwy3sQcnaFJexAcAMCr/OMxlmkVZyeC7jSjvw+2A19aL0oAuvVQ4euZTW0JkXAX0o9k0LUz1gCzlNKXmVSK6aM4cxt7VpHQ3nvnnd3GbfiFr3dq9mfW4XASIPpjF/oJlu1Xu/zobQZU+mXfsAqENzwKNL6QxMWv2v61PsvCZ/fDm/F3sTVNWfjeg3v0c3TISJmMdfCL/BfHvBIRW7HJYFPrVgfDwkZP1Xx9c6ZtNgEeP3uWH+D5IXAj2LO5Bc4Aq01NISe8v5Bl+gNwXMCOCswkP0Gj3HPr7a6nuVuqb+864siVtsnBb45XIAJIwMA+7/8yhH5mL322X3xV1+zua40VLfZHBjIbj2QkJlmmSbWy5ahjj9GTLJsN6cu6mVjkYdugp1Y3RVW6K84+x0uaazp1sy9lH741rIak6n7YMH2RHS9p7Xg8c0GMyUu6tgB9FpH7ydm1sT3z5P1MxjCHemd0TZt9jXrt42u61Q9P/5bvtx91VLdIn/qtxLJMnEU2wKBV7Txmpz+rATX9bA/VrpqHRqELfSVNzaoKbvUbcAc4vuQZO/FK/8677NK97fAjXhTkLXWs1Q9PrNavkcWfWlEjv09u2Z/Z3GrZ7WvpTRlmvdHRHfLgB8uXsuElE+CJc752uSbx5SwlPObFwZo1WXonZkQDG4OgIRlcq00gY/gAxj23TT/7ceCoY4+NUxOgo6dmKbVtpDZIjAG+9kRdc4OG/b1srWfP6B/442ueHBrsx29oiMULJLzafeI3m45+5/QfJMW3exUTTxDLHJLX8WNWS6d9ajH25MOWmnjqJ5GNU6uzcsxcDpbo2Fx5yQSAWE/Unu/ZYSWcB1ph6ZFRVbLPsyixBVDUIxqT+Tq00OHkQ3ff495p7lbsvVe33wH728lKqJrFsTHOZ4a22SldjOVAl3bxcoA06BwECaQCDK1nodLWfY3fSVVjE4GuGZuZlqR5y1sP7Za/6U3TuGbah+6+zwnl2LknMaSZLdadia+CnK2AaCfi3nMd5nxcD5tIEo2eH87N379sAqz+wnn/LrZ/BDhk2+EKFLXbWWaSvS3wCpYzVuMJXlst1L9+3dPd+qen/66ftx9zjAEqMEp+QMsSz0PAgCIAOZ2XjQDp2VJ2cI39At5jalcN0GwLxaua2V5+lM9OOo0loUg7dCNH37v3jqM3H+2X6X1+/fruWT01bLmbxG9YrWK/dWIf+uom/V4hbEklSPePDcOX1PyyCdC4viw3n47jKGxBxGE7jeMtYM3wmmV9UMpIxnXqnbbwkay3HX2U9VQwkB350Q9AHORq2bZNZR8gOgEAqJKSdktq9fXAQlvL6gQ/ennauPdf14N/AzDYsVLJOrH8bbW7fAQMQNGl+yYf/9LvWjZNngvsJ3G1/8EBfv09LcVf3pLyLSaAnjp8QC8gnl8PK7zMs7azJEhRGqjJkpUhr0Vt1jTjRIGxi3bZuRtNeVI++LC3dkvFV/s4DvJ8fWZl5G8o0DRGoBjzab5tX+jmMT988DuYtfSL1uOire3As0n9w/MB8CT41qUx6280kSngpHvn5bt1B77lEIKy1WVGn8lcsuuuTUdkl3yi6fj3MW/LvkHQoPrd07oNv5Z+sNuSAVtMAAQce8D8NzXbbyMAuSlg0uoltwUvQS9QEmC2Dv7MYzqdWOXoigOn+xbOle96p8HvgZMdBBqdPtBhSwOkZketDhvob7TY4VVCwHM4JBn4fgDazO6SgdyiQ46BmJBhf9RvHtMSC0CL/9i58rh3bin2C8ZXHHJgNy800FW2gycTitUJ+bXi0OpjqrFaict+Rfm2Yw/ovrlAwUtc6N0fWy73/c1l8zudddqtOoz8Z+a5M1JstSoIY66aoIm6NXn9HUcIDPWyFXt0D6+6u60gje0lqoMPP6w78j3vbgsNuU1hieSAowOPrlDDy+Ku1SZYFKijU2cYgx9+wPVkMk3oNr2GDypqBPsZRtrqQz7N0KRmBCBcC5Tddn9Tt+bRx7p1+l3DLRVm/1FnnNot2mmpZSIFOdjp5NPV5Bbs1UsGBPiWDKKFfl6uyrrfv+OTs/duSS/jW5UAED538WX373bWB3dR0E/mS5UAUo8SbCrGch0IUvfJwaUK1/xBu1SPl3fdfXm3+r5f64qezZe9D9ive99H9UWPChD8OF56ABRgEqoGhvpKGvQGXT0EBkbGHFw1AI9x/l7UFl3espYkKDmozEwUv/iwB37AIeXQQ6Kgh5H9tA08pl8af7lDL29sOfIMfZvpvm82j+VJETb1h1qNRB86c/NKgV9NV3zjYvxXT3xh9n96YCvutjoBkHXCl0677OF13RkKyCEBON+2NaMXD9hLSAxuOAE4rnTtgoWMawBnlu21Z7f3IQd1z+oVsec3eVSwRDPhbe9+Z3fcB0/VK21LI6/dR3BkIZnH+NhSs9F9ogUMVGKHn8fQdRIotEkexmJrJQHvDiC4dFuC+NlGIj/AmMe6uYYucrzFWHdA4vB64BGH24anVq/u5rXlTJY999+vO+rMU7s37b9vbGuxwU508CgF2XVAhRef+Bg5Kx5tkgQbnBCj7opjD+y+yIoN7dYU4jVVWXHRBQeP5+Zu0Fe67wXYw7dttu/ak9O8/SpvweKtWOpXH3SmV5vgTl6/sO6Z7hktlfMbNnbLtHTu8ea9dFTQjzggC6SQoRuF7w6Ev97i5Wv6JZ+ZCk9WmmwR6CwnCRhtatOrVaOZzRpQKRpqAktHyXSiqB96BHm+U3Nd/X1dT+8q+QT+2sdWd0/r7e8zSxZ3u2kbXLLbrgIYoEkYp5trdKAX+AEf7YznBn3aXo1E21aF1QracWvOPvdX2LG1BR+nLnteeP7HFe9/0fKh94m2L19UoN0GNPUZeNVEyd/KKScKUIMkzYALD/TgC3QAyjgo90lEn8acCK4nEyEuFC3OVJJA6vOHGiRHbQsR0VaqygoYW7vApgtwsA3+Apt+4FKXgs+sDkDwZwOALyBBG74AZWBtS2gAEQBNZ9CzehUdRgXg0NHP6oZMdCRRMKb7xBPnnPcDC5ribqotoOQ+973L7tr106ftqtz0T28bAmaaIwWVHAounvUsUdkyNASdKrI8LXfZg6IhHA6JaEMXPkCA32NF02roNGg5arRvKkmQyxaDxqCKzwWufWmZSGC+1fbhJV1yLVt6CTg0NfNqvx7q6EuyBCR4ucHHDEYC9+5XOzoil/tKHPql0jxJgIwZfI2VDYzpXb7f0EO+b0nF1IUpuk3lS5/v/kwWfteeSQKZ6IdgOKHrSUdQ4LGWvdBS+mVNGRL+ZDkHKc8M0U06n9mivr6f8dwyxnPjetGHx/6i8ezQeB7/55lBApj+BBF+eEs/4xt083MI1hMbhucDBp3WXbZQc7P/Dcgak03wlz1VV4ycVO0hJPxJh7YNeHuIvPgYu9v8Ikm++6WzhcU2lpKzTez8CvVDL3Q/0PL7oWHJH/Z9luXcooalmT2ZHzPIMp09u5bsOhdA7e2CKaDpW/t/30fELAezs7XQKjrak3y5Nos0Z1vqtwMoJcuri2QB6qal+mprADj0c0hDTy3x8DkpBHi1Pd4SDD1OTF2r2emzeOLNey42Te7izwQYkosJBy0riHT9aP+l3ccn3+VrxVPcBZkpGDYl3fv7f7l8ft36SwX08bWHs+ABpsEHdAUJkCmVKIypuz8MElw+z7FYXxYFP+PFAz8Bo4/QIrtkMZDzgZZ9BYXzhjfn5pk/3wAg7doCqm0pXCBV9SSdxwBUY+4PHbPXW5W6nRjSz+pGn8fER404QKJwnW3AoEWm+pHt7UZkzHqvko2nEom6+HtZolXSXTezbOcPPv6pr/Tf88j4tAWvXnHZ9+LZfTY8O/rJolF3OAH3TJRkZnoAZ5bmuDEkAKAC+sQML9AVkJrtxAMeaJMASS5C6wShoWKdNCbkub+QV38KDGojeLLP3UXTSFV5tnOpoclk8OyHX3xOBGgFFoST16jhuk+G1iZZDTo8jSazHUNIlCQL4MPPBKFm9ovirsW7jE9+5NOz+mKPV1Ze7PE2ytvjOxe8ZVE39296mlBJoDkryX7Yp3b9JBxBD7D0aRZz7fHM6NoC8LASAAOdPKL1QzoJzoqQxCFcppGcFOigcFxd90lRxBM1q41ndONGN32ZsZFtZ6Sf4ANEjcOCqIAb0HwAFC0lwKkWlVcF94nOq0hWBmgqaQy6VpOSOSz19ESGHv/fNdct+vDaz597vzpfcSFO262wEmxcP/pXQXE8wFIMsEAL4AOwwzjbg5b9FyUDpgXkzQFv4brzGKCIv7YMxiy/ssAhjawCUyxBD2LZB7+DoTse+rn0NAE3nQE2qRFQSKACXk2DTR9AA3ABWonjZGh6kgDoDG3OE0ma6it+Jch1S3Ydf2x7zPzyBRe3a2lngosFzIfwHOBrZqPMCaE+L9ltPMt3AAJEJpA/4NnG4QPoSgiCmzmebUBkBq9WBs9q8xRVsEYCtNk6oIKP3pTM8IW0jDIznSC6gMerA0ZWu6+zrFcyMJ5VIOcEEg1QSYmi6RNA8gx4G0MH9hS/6h/NLN/l0690z8emyTJ4P9n7Ctt+dLBh9Lfy8rOAC+gA6MNbA69mqxNCfZS+bZ5AMwk8NMgAupIVPmagwJQYZEyWSi54oqXNdl+kB/oCOLz0Jz0KoIxnH7YuUWSxDocPgtJQScRTtEjhmgK4rtU/PHlEO/056E3SAH6SQAn/3f2XjL/4Sk77Vr6Zu216ImgzchZ0PfYPl8195Z9Ou/jq27pd9CXN79egYYeIUy8zmPgS1JqABkjdOJ3g194KHQLyGgIyKIS3ZiIc9KQOX40ZiKjzOPrRCa1p1Jrsq37PQGarlHPDA+oCjFlcK0P6o9/0jHmmB3j8hJ7XFKDii6td65ok8rjsSjtJY37lqtL5G3/8+e6P/uGY2enfSeO4vPydQvHqFp42loa/WTwz2ovZSICZ/cxUHGcm+3ygfs9WEeQAqOVb1nGgIwPow1hWhFq2szokh0xn6cjPmcKJJh7rET9FopKADry7rIf+KuhlRk7yoxPwIWMcgIoF0Pnj3wkiAsbh9wqgcZKlkjt1dEAPHfShVWJKkBJ3tao/3Jand8uPramJ6ateeAFJr4ZcJAhOwtlhOxDYCuyQXfcJxAAABPhJREFUAAEpy3aW81rCia6Xd1nMw0uyobYDLqqNQwADbdqsFUk8Rup5BieRCEiOyXbATEgm+WspL/mAWOPVHg53WcqxC4B74AUy2QPYMNPvttSFDj54xlfohZ2zp31hJ1ZPd48PO6Scduns4lseHF0gcP5U+47gyQwHqMxqgdYOgMP5IOYVmJ7l6vITP81qJ48CSeDgA1CCDGetEJAmCQo0dYisEq8AgQdJlKKnXQBHS9vXm07PeIhUeqA1JhMWPPTzeAGvGlnZOtJGjuAfj/R6/jsO6s697IOvzpKPHZMFn3do2eM7s6fqK8q/JVD91tmAz6qQGU3k6pk95jArxuTWgLG+JsKAqBoagAdQHGo54D5vBxAScYr5ACius3Qb7MYU/owjE3gYigCN6p+EsU6N9W0RJQEymyGsZwihQUTOGukHfAorC/qVALfp3Tx/tPbzsz/2wA66SxR2kLJSw2pw60OjL+sn4b6mRPCP8QBkJUPN6tTDTDXwIKBwsipUcdvdwzbhiId0M4khzjbmfKjLPknUobbfjtH3iWFBQhTQsaJmP1cLEgE5ApnEq5WGGhoSTL+v8LSS6S+O2X/81ztq1sfi3BOG16ys+PbsQQr0NxWjs3RI9EzzAbG2gjZLKxEAzauCLM5Ty+LUv8fthS5EVAk0iXKtKk4MqCTb24X5Ft4xxuyd5Me4AWRWnbbER2UPaOa6WNVf24PBVgezvs4JtKXnn2TDn2zNu3cXWrj9rl7TBCg39vr2+WcoXucpaqcwyxWbPFkjMNkaWCIL1B5s0fRtCRpWBA0sGNOF+KssoANFlKGhNQu0orcwjQ/gM8JsVoLApDLJMyz3kqthXvGDrPhTjy5X1/lb+tCGhb/Kd/HgVVayteL3vPAvTpkZzZ+r0J1Z+38dEOtA1z/Ek1ASAPwIcH8wbKAwkKQRoftEqP++baPEaAG+mBjnGuJUeXq2XSNLPAaysXtvD6lnuYHnnKC+ejiZuvshH9R8uc/qoXJHFmx83ZW9L5p9j7bNr86PR5/Sew8Jc5vhmDvs8yzh/TOCk4DjUUgXrBK9owY9W4DF9wNqtLHq6me3kye92cvD78Nc0wVtkZEg/Plk342/ryPL11/qI9ql67WoMf11W/a7aPbQDfMzX9C7YL8oI/Uq4+T2ELNZ0gk02wT15AphCvFkNdGV0DFADTAnCUQNtcLetboNvnUiP6VO7e3SNAX6MNt5f8DMXUquv+VrWTb3zRzF/1rX5ddrbccW9evAeKKMPUcz6nOqV9QWAaMTQ3WcaQ8buTDgwMPYcI5gG2D1aItLCE0F4XBa35R/coYjtR7KkXh+BVFfwqiHuH+nsQt1sJv+J8/Lhh1YJ2Y7UOErVcULTQ9v7E7WR2BOV6B1G79XTiyuw12d7P2kkJRVUpANgNbyIluHruklOWqphwZC5UFPDxcv4GSFaEu/ObuNIrtG/Jd0+qpdvoHz1XjBBpNerZL4vFrSd4DcN//97LKNL4xO0S+gnq6vrz1BG8JK4bcPqvukaCAX2JPQ1krgxFE0SIbJceS0AxzdjyozVunrNq/i+/b5yvX61m3o3ojlDZ8Amwv6od+b3WPdczMr5+bGb5eDKzVnDxPdHgJvuWbxMn26cbl+OXu5gFzuma5f0R7N8BO6Hb+iqq/OH/M+u7VKJP2m4mjVokWjO/iBJf++0uYUvoH7/h/+/mnI0PTxNgAAAABJRU5ErkJggg==";

  // src/utils.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  function detectSystemColorScheme() {
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      return "dark" /* Dark */;
    }
    return "light" /* Light */;
  }
  function getExtensionVersion() {
    return import_webextension_polyfill2.default.runtime.getManifest().version;
  }

  // src/options/ProviderSelect.tsx
  init_react();

  // node_modules/swr/core/dist/index.mjs
  init_react();
  var import_shim = __toESM(require_shim(), 1);

  // node_modules/swr/_internal/dist/index.mjs
  init_react();
  var SWRGlobalState = /* @__PURE__ */ new WeakMap();
  var EMPTY_CACHE = {};
  var noop = () => {
  };
  var UNDEFINED = (
    /*#__NOINLINE__*/
    noop()
  );
  var OBJECT = Object;
  var isUndefined = (v3) => v3 === UNDEFINED;
  var isFunction2 = (v3) => typeof v3 == "function";
  var mergeObjects = (a3, b3) => ({
    ...a3,
    ...b3
  });
  var STR_UNDEFINED = "undefined";
  var isWindowDefined = typeof window != STR_UNDEFINED;
  var isDocumentDefined = typeof document != STR_UNDEFINED;
  var hasRequestAnimationFrame = () => isWindowDefined && typeof window["requestAnimationFrame"] != STR_UNDEFINED;
  var createCacheHelper = (cache2, key) => {
    const state = SWRGlobalState.get(cache2);
    return [
      // Getter
      () => cache2.get(key) || EMPTY_CACHE,
      // Setter
      (info) => {
        const prev = cache2.get(key);
        state[5](key, mergeObjects(prev, info), prev || EMPTY_CACHE);
      },
      // Subscriber
      state[6]
    ];
  };
  var table = /* @__PURE__ */ new WeakMap();
  var counter = 0;
  var stableHash = (arg) => {
    const type = typeof arg;
    const constructor = arg && arg.constructor;
    const isDate = constructor == Date;
    let result;
    let index;
    if (OBJECT(arg) === arg && !isDate && constructor != RegExp) {
      result = table.get(arg);
      if (result)
        return result;
      result = ++counter + "~";
      table.set(arg, result);
      if (constructor == Array) {
        result = "@";
        for (index = 0; index < arg.length; index++) {
          result += stableHash(arg[index]) + ",";
        }
        table.set(arg, result);
      }
      if (constructor == OBJECT) {
        result = "#";
        const keys = OBJECT.keys(arg).sort();
        while (!isUndefined(index = keys.pop())) {
          if (!isUndefined(arg[index])) {
            result += index + ":" + stableHash(arg[index]) + ",";
          }
        }
        table.set(arg, result);
      }
    } else {
      result = isDate ? arg.toJSON() : type == "symbol" ? arg.toString() : type == "string" ? JSON.stringify(arg) : "" + arg;
    }
    return result;
  };
  var online = true;
  var isOnline = () => online;
  var [onWindowEvent, offWindowEvent] = isWindowDefined && window.addEventListener ? [
    window.addEventListener.bind(window),
    window.removeEventListener.bind(window)
  ] : [
    noop,
    noop
  ];
  var isVisible = () => {
    const visibilityState = isDocumentDefined && document.visibilityState;
    return isUndefined(visibilityState) || visibilityState !== "hidden";
  };
  var initFocus = (callback) => {
    if (isDocumentDefined) {
      document.addEventListener("visibilitychange", callback);
    }
    onWindowEvent("focus", callback);
    return () => {
      if (isDocumentDefined) {
        document.removeEventListener("visibilitychange", callback);
      }
      offWindowEvent("focus", callback);
    };
  };
  var initReconnect = (callback) => {
    const onOnline = () => {
      online = true;
      callback();
    };
    const onOffline = () => {
      online = false;
    };
    onWindowEvent("online", onOnline);
    onWindowEvent("offline", onOffline);
    return () => {
      offWindowEvent("online", onOnline);
      offWindowEvent("offline", onOffline);
    };
  };
  var preset = {
    isOnline,
    isVisible
  };
  var defaultConfigOptions = {
    initFocus,
    initReconnect
  };
  var IS_REACT_LEGACY = !bn.useId;
  var IS_SERVER = !isWindowDefined || "Deno" in window;
  var rAF = (f3) => hasRequestAnimationFrame() ? window["requestAnimationFrame"](f3) : setTimeout(f3, 1);
  var useIsomorphicLayoutEffect = IS_SERVER ? h2 : s2;
  var navigatorConnection = typeof navigator !== "undefined" && navigator.connection;
  var slowConnection = !IS_SERVER && navigatorConnection && ([
    "slow-2g",
    "2g"
  ].includes(navigatorConnection.effectiveType) || navigatorConnection.saveData);
  var serialize = (key) => {
    if (isFunction2(key)) {
      try {
        key = key();
      } catch (err) {
        key = "";
      }
    }
    const args = key;
    key = typeof key == "string" ? key : (Array.isArray(key) ? key.length : key) ? stableHash(key) : "";
    return [
      key,
      args
    ];
  };
  var __timestamp = 0;
  var getTimestamp = () => ++__timestamp;
  var FOCUS_EVENT = 0;
  var RECONNECT_EVENT = 1;
  var MUTATE_EVENT = 2;
  var constants = {
    __proto__: null,
    FOCUS_EVENT,
    RECONNECT_EVENT,
    MUTATE_EVENT
  };
  async function internalMutate(...args) {
    const [cache2, _key, _data, _opts] = args;
    const options = mergeObjects({
      populateCache: true,
      throwOnError: true
    }, typeof _opts === "boolean" ? {
      revalidate: _opts
    } : _opts || {});
    let populateCache = options.populateCache;
    const rollbackOnErrorOption = options.rollbackOnError;
    let optimisticData = options.optimisticData;
    const revalidate = options.revalidate !== false;
    const rollbackOnError = (error) => {
      return typeof rollbackOnErrorOption === "function" ? rollbackOnErrorOption(error) : rollbackOnErrorOption !== false;
    };
    const throwOnError = options.throwOnError;
    if (isFunction2(_key)) {
      const keyFilter = _key;
      const matchedKeys = [];
      const it = cache2.keys();
      for (let keyIt = it.next(); !keyIt.done; keyIt = it.next()) {
        const key = keyIt.value;
        if (
          // Skip the special useSWRInfinite keys.
          !key.startsWith("$inf$") && keyFilter(cache2.get(key)._k)
        ) {
          matchedKeys.push(key);
        }
      }
      return Promise.all(matchedKeys.map(mutateByKey));
    }
    return mutateByKey(_key);
    async function mutateByKey(_k) {
      const [key] = serialize(_k);
      if (!key)
        return;
      const [get, set] = createCacheHelper(cache2, key);
      const [EVENT_REVALIDATORS, MUTATION, FETCH] = SWRGlobalState.get(cache2);
      const revalidators = EVENT_REVALIDATORS[key];
      const startRevalidate = () => {
        if (revalidate) {
          delete FETCH[key];
          if (revalidators && revalidators[0]) {
            return revalidators[0](MUTATE_EVENT).then(() => get().data);
          }
        }
        return get().data;
      };
      if (args.length < 3) {
        return startRevalidate();
      }
      let data = _data;
      let error;
      const beforeMutationTs = getTimestamp();
      MUTATION[key] = [
        beforeMutationTs,
        0
      ];
      const hasOptimisticData = !isUndefined(optimisticData);
      const state = get();
      const displayedData = state.data;
      const currentData = state._c;
      const committedData = isUndefined(currentData) ? displayedData : currentData;
      if (hasOptimisticData) {
        optimisticData = isFunction2(optimisticData) ? optimisticData(committedData) : optimisticData;
        set({
          data: optimisticData,
          _c: committedData
        });
      }
      if (isFunction2(data)) {
        try {
          data = data(committedData);
        } catch (err) {
          error = err;
        }
      }
      if (data && isFunction2(data.then)) {
        data = await data.catch((err) => {
          error = err;
        });
        if (beforeMutationTs !== MUTATION[key][0]) {
          if (error)
            throw error;
          return data;
        } else if (error && hasOptimisticData && rollbackOnError(error)) {
          populateCache = true;
          data = committedData;
          set({
            data,
            _c: UNDEFINED
          });
        }
      }
      if (populateCache) {
        if (!error) {
          if (isFunction2(populateCache)) {
            data = populateCache(data, committedData);
          }
          set({
            data,
            _c: UNDEFINED
          });
        }
      }
      MUTATION[key][1] = getTimestamp();
      const res = await startRevalidate();
      set({
        _c: UNDEFINED
      });
      if (error) {
        if (throwOnError)
          throw error;
        return;
      }
      return populateCache ? res : data;
    }
  }
  var revalidateAllKeys = (revalidators, type) => {
    for (const key in revalidators) {
      if (revalidators[key][0])
        revalidators[key][0](type);
    }
  };
  var initCache = (provider, options) => {
    if (!SWRGlobalState.has(provider)) {
      const opts = mergeObjects(defaultConfigOptions, options);
      const EVENT_REVALIDATORS = {};
      const mutate2 = internalMutate.bind(UNDEFINED, provider);
      let unmount = noop;
      const subscriptions = {};
      const subscribe = (key, callback) => {
        const subs = subscriptions[key] || [];
        subscriptions[key] = subs;
        subs.push(callback);
        return () => subs.splice(subs.indexOf(callback), 1);
      };
      const setter = (key, value, prev) => {
        provider.set(key, value);
        const subs = subscriptions[key];
        if (subs) {
          for (let i3 = subs.length; i3--; ) {
            subs[i3](prev, value);
          }
        }
      };
      const initProvider = () => {
        if (!SWRGlobalState.has(provider)) {
          SWRGlobalState.set(provider, [
            EVENT_REVALIDATORS,
            {},
            {},
            {},
            mutate2,
            setter,
            subscribe
          ]);
          if (!IS_SERVER) {
            const releaseFocus = opts.initFocus(setTimeout.bind(UNDEFINED, revalidateAllKeys.bind(UNDEFINED, EVENT_REVALIDATORS, FOCUS_EVENT)));
            const releaseReconnect = opts.initReconnect(setTimeout.bind(UNDEFINED, revalidateAllKeys.bind(UNDEFINED, EVENT_REVALIDATORS, RECONNECT_EVENT)));
            unmount = () => {
              releaseFocus && releaseFocus();
              releaseReconnect && releaseReconnect();
              SWRGlobalState.delete(provider);
            };
          }
        }
      };
      initProvider();
      return [
        provider,
        mutate2,
        initProvider,
        unmount
      ];
    }
    return [
      provider,
      SWRGlobalState.get(provider)[4]
    ];
  };
  var onErrorRetry = (_4, __, config, revalidate, opts) => {
    const maxRetryCount = config.errorRetryCount;
    const currentRetryCount = opts.retryCount;
    const timeout = ~~((Math.random() + 0.5) * (1 << (currentRetryCount < 8 ? currentRetryCount : 8))) * config.errorRetryInterval;
    if (!isUndefined(maxRetryCount) && currentRetryCount > maxRetryCount) {
      return;
    }
    setTimeout(revalidate, timeout, opts);
  };
  var compare = (currentData, newData) => stableHash(currentData) == stableHash(newData);
  var [cache, mutate] = initCache(/* @__PURE__ */ new Map());
  var defaultConfig = mergeObjects(
    {
      // events
      onLoadingSlow: noop,
      onSuccess: noop,
      onError: noop,
      onErrorRetry,
      onDiscarded: noop,
      // switches
      revalidateOnFocus: true,
      revalidateOnReconnect: true,
      revalidateIfStale: true,
      shouldRetryOnError: true,
      // timeouts
      errorRetryInterval: slowConnection ? 1e4 : 5e3,
      focusThrottleInterval: 5 * 1e3,
      dedupingInterval: 2 * 1e3,
      loadingTimeout: slowConnection ? 5e3 : 3e3,
      // providers
      compare,
      isPaused: () => false,
      cache,
      mutate,
      fallback: {}
    },
    // use web preset by default
    preset
  );
  var mergeConfigs = (a3, b3) => {
    const v3 = mergeObjects(a3, b3);
    if (b3) {
      const { use: u1, fallback: f1 } = a3;
      const { use: u22, fallback: f22 } = b3;
      if (u1 && u22) {
        v3.use = u1.concat(u22);
      }
      if (f1 && f22) {
        v3.fallback = mergeObjects(f1, f22);
      }
    }
    return v3;
  };
  var SWRConfigContext = B({});
  var SWRConfig = (props) => {
    const { value } = props;
    const parentConfig = q2(SWRConfigContext);
    const isFunctionalConfig = isFunction2(value);
    const config = F(() => isFunctionalConfig ? value(parentConfig) : value, [
      isFunctionalConfig,
      parentConfig,
      value
    ]);
    const extendedConfig = F(() => isFunctionalConfig ? config : mergeConfigs(parentConfig, config), [
      isFunctionalConfig,
      parentConfig,
      config
    ]);
    const provider = config && config.provider;
    const [cacheContext] = p2(() => provider ? initCache(provider(extendedConfig.cache || cache), config) : UNDEFINED);
    if (cacheContext) {
      extendedConfig.cache = cacheContext[0];
      extendedConfig.mutate = cacheContext[1];
    }
    useIsomorphicLayoutEffect(() => {
      if (cacheContext) {
        cacheContext[2] && cacheContext[2]();
        return cacheContext[3];
      }
    }, []);
    return h(SWRConfigContext.Provider, mergeObjects(props, {
      value: extendedConfig
    }));
  };
  var enableDevtools = isWindowDefined && window.__SWR_DEVTOOLS_USE__;
  var use = enableDevtools ? window.__SWR_DEVTOOLS_USE__ : [];
  var setupDevTools = () => {
    if (enableDevtools) {
      window.__SWR_DEVTOOLS_REACT__ = bn;
    }
  };
  var normalize = (args) => {
    return isFunction2(args[1]) ? [
      args[0],
      args[1],
      args[2] || {}
    ] : [
      args[0],
      null,
      (args[1] === null ? args[2] : args[1]) || {}
    ];
  };
  var useSWRConfig = () => {
    return mergeObjects(defaultConfig, q2(SWRConfigContext));
  };
  var middleware = (useSWRNext) => (key_, fetcher_, config) => {
    const fetcher = fetcher_ && ((...args) => {
      const key = serialize(key_)[0];
      const [, , , PRELOAD] = SWRGlobalState.get(cache);
      const req = PRELOAD[key];
      if (req) {
        delete PRELOAD[key];
        return req;
      }
      return fetcher_(...args);
    });
    return useSWRNext(key_, fetcher, config);
  };
  var BUILT_IN_MIDDLEWARE = use.concat(middleware);
  var withArgs = (hook) => {
    return function useSWRArgs(...args) {
      const fallbackConfig = useSWRConfig();
      const [key, fn2, _config] = normalize(args);
      const config = mergeConfigs(fallbackConfig, _config);
      let next = hook;
      const { use: use2 } = config;
      const middleware2 = (use2 || []).concat(BUILT_IN_MIDDLEWARE);
      for (let i3 = middleware2.length; i3--; ) {
        next = middleware2[i3](next);
      }
      return next(key, fn2 || config.fetcher || null, config);
    };
  };
  var subscribeCallback = (key, callbacks, callback) => {
    const keyedRevalidators = callbacks[key] || (callbacks[key] = []);
    keyedRevalidators.push(callback);
    return () => {
      const index = keyedRevalidators.indexOf(callback);
      if (index >= 0) {
        keyedRevalidators[index] = keyedRevalidators[keyedRevalidators.length - 1];
        keyedRevalidators.pop();
      }
    };
  };
  setupDevTools();

  // node_modules/swr/core/dist/index.mjs
  var WITH_DEDUPE = {
    dedupe: true
  };
  var useSWRHandler = (_key, fetcher, config) => {
    const { cache: cache2, compare: compare2, suspense, fallbackData, revalidateOnMount, refreshInterval, refreshWhenHidden, refreshWhenOffline, keepPreviousData } = config;
    const [EVENT_REVALIDATORS, MUTATION, FETCH] = SWRGlobalState.get(cache2);
    const [key, fnArg] = serialize(_key);
    const initialMountedRef = _2(false);
    const unmountedRef = _2(false);
    const keyRef = _2(key);
    const fetcherRef = _2(fetcher);
    const configRef = _2(config);
    const getConfig = () => configRef.current;
    const isActive = () => getConfig().isVisible() && getConfig().isOnline();
    const [getCache, setCache, subscribeCache] = createCacheHelper(cache2, key);
    const stateDependencies = _2({}).current;
    const fallback = isUndefined(fallbackData) ? config.fallback[key] : fallbackData;
    const isEqual = (prev, current) => {
      let equal = true;
      for (const _4 in stateDependencies) {
        const t3 = _4;
        if (!compare2(current[t3], prev[t3])) {
          if (t3 === "data" && isUndefined(prev[t3])) {
            if (!compare2(current[t3], returnedData)) {
              equal = false;
            }
          } else {
            equal = false;
          }
        }
      }
      return equal;
    };
    const getSnapshot = F(() => {
      const shouldStartRequest = (() => {
        if (!key)
          return false;
        if (!fetcher)
          return false;
        if (!isUndefined(revalidateOnMount))
          return revalidateOnMount;
        if (getConfig().isPaused())
          return false;
        if (suspense)
          return false;
        return true;
      })();
      const getSelectedCache = () => {
        const state = getCache();
        const snapshot = mergeObjects(state);
        delete snapshot._k;
        if (!shouldStartRequest) {
          return snapshot;
        }
        return {
          isValidating: true,
          isLoading: true,
          ...snapshot
        };
      };
      let memorizedSnapshot = getSelectedCache();
      return () => {
        const snapshot = getSelectedCache();
        return isEqual(snapshot, memorizedSnapshot) ? memorizedSnapshot : memorizedSnapshot = snapshot;
      };
    }, [
      cache2,
      key
    ]);
    const cached = (0, import_shim.useSyncExternalStore)(T2(
      (callback) => subscribeCache(key, (prev, current) => {
        if (!isEqual(prev, current))
          callback();
      }),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
        cache2,
        key
      ]
    ), getSnapshot, getSnapshot);
    const isInitialMount = !initialMountedRef.current;
    const cachedData = cached.data;
    const data = isUndefined(cachedData) ? fallback : cachedData;
    const error = cached.error;
    const laggyDataRef = _2(data);
    const returnedData = keepPreviousData ? isUndefined(cachedData) ? laggyDataRef.current : cachedData : data;
    const shouldDoInitialRevalidation = (() => {
      if (isInitialMount && !isUndefined(revalidateOnMount))
        return revalidateOnMount;
      if (getConfig().isPaused())
        return false;
      if (suspense)
        return isUndefined(data) ? false : config.revalidateIfStale;
      return isUndefined(data) || config.revalidateIfStale;
    })();
    const defaultValidatingState = !!(key && fetcher && isInitialMount && shouldDoInitialRevalidation);
    const isValidating = isUndefined(cached.isValidating) ? defaultValidatingState : cached.isValidating;
    const isLoading = isUndefined(cached.isLoading) ? defaultValidatingState : cached.isLoading;
    const revalidate = T2(
      async (revalidateOpts) => {
        const currentFetcher = fetcherRef.current;
        if (!key || !currentFetcher || unmountedRef.current || getConfig().isPaused()) {
          return false;
        }
        let newData;
        let startAt;
        let loading = true;
        const opts = revalidateOpts || {};
        const shouldStartNewRequest = !FETCH[key] || !opts.dedupe;
        const callbackSafeguard = () => {
          if (IS_REACT_LEGACY) {
            return !unmountedRef.current && key === keyRef.current && initialMountedRef.current;
          }
          return key === keyRef.current;
        };
        const finalState = {
          isValidating: false,
          isLoading: false
        };
        const finishRequestAndUpdateState = () => {
          setCache(finalState);
        };
        const cleanupState = () => {
          const requestInfo = FETCH[key];
          if (requestInfo && requestInfo[1] === startAt) {
            delete FETCH[key];
          }
        };
        const initialState = {
          isValidating: true
        };
        if (isUndefined(getCache().data)) {
          initialState.isLoading = true;
        }
        try {
          if (shouldStartNewRequest) {
            setCache(initialState);
            if (config.loadingTimeout && isUndefined(getCache().data)) {
              setTimeout(() => {
                if (loading && callbackSafeguard()) {
                  getConfig().onLoadingSlow(key, config);
                }
              }, config.loadingTimeout);
            }
            FETCH[key] = [
              currentFetcher(fnArg),
              getTimestamp()
            ];
          }
          [newData, startAt] = FETCH[key];
          newData = await newData;
          if (shouldStartNewRequest) {
            setTimeout(cleanupState, config.dedupingInterval);
          }
          if (!FETCH[key] || FETCH[key][1] !== startAt) {
            if (shouldStartNewRequest) {
              if (callbackSafeguard()) {
                getConfig().onDiscarded(key);
              }
            }
            return false;
          }
          finalState.error = UNDEFINED;
          const mutationInfo = MUTATION[key];
          if (!isUndefined(mutationInfo) && // case 1
          (startAt <= mutationInfo[0] || // case 2
          startAt <= mutationInfo[1] || // case 3
          mutationInfo[1] === 0)) {
            finishRequestAndUpdateState();
            if (shouldStartNewRequest) {
              if (callbackSafeguard()) {
                getConfig().onDiscarded(key);
              }
            }
            return false;
          }
          const cacheData = getCache().data;
          finalState.data = compare2(cacheData, newData) ? cacheData : newData;
          if (shouldStartNewRequest) {
            if (callbackSafeguard()) {
              getConfig().onSuccess(newData, key, config);
            }
          }
        } catch (err) {
          cleanupState();
          const currentConfig = getConfig();
          const { shouldRetryOnError } = currentConfig;
          if (!currentConfig.isPaused()) {
            finalState.error = err;
            if (shouldStartNewRequest && callbackSafeguard()) {
              currentConfig.onError(err, key, currentConfig);
              if (shouldRetryOnError === true || isFunction2(shouldRetryOnError) && shouldRetryOnError(err)) {
                if (isActive()) {
                  currentConfig.onErrorRetry(err, key, currentConfig, revalidate, {
                    retryCount: (opts.retryCount || 0) + 1,
                    dedupe: true
                  });
                }
              }
            }
          }
        }
        loading = false;
        finishRequestAndUpdateState();
        return true;
      },
      // `setState` is immutable, and `eventsCallback`, `fnArg`, and
      // `keyValidating` are depending on `key`, so we can exclude them from
      // the deps array.
      //
      // FIXME:
      // `fn` and `config` might be changed during the lifecycle,
      // but they might be changed every render like this.
      // `useSWR('key', () => fetch('/api/'), { suspense: true })`
      // So we omit the values from the deps array
      // even though it might cause unexpected behaviors.
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
        key,
        cache2
      ]
    );
    const boundMutate = T2(
      // Use callback to make sure `keyRef.current` returns latest result every time
      (...args) => {
        return internalMutate(cache2, keyRef.current, ...args);
      },
      // eslint-disable-next-line react-hooks/exhaustive-deps
      []
    );
    useIsomorphicLayoutEffect(() => {
      fetcherRef.current = fetcher;
      configRef.current = config;
      if (!isUndefined(cachedData)) {
        laggyDataRef.current = cachedData;
      }
    });
    useIsomorphicLayoutEffect(() => {
      if (!key)
        return;
      const softRevalidate = revalidate.bind(UNDEFINED, WITH_DEDUPE);
      let nextFocusRevalidatedAt = 0;
      const onRevalidate = (type) => {
        if (type == constants.FOCUS_EVENT) {
          const now = Date.now();
          if (getConfig().revalidateOnFocus && now > nextFocusRevalidatedAt && isActive()) {
            nextFocusRevalidatedAt = now + getConfig().focusThrottleInterval;
            softRevalidate();
          }
        } else if (type == constants.RECONNECT_EVENT) {
          if (getConfig().revalidateOnReconnect && isActive()) {
            softRevalidate();
          }
        } else if (type == constants.MUTATE_EVENT) {
          return revalidate();
        }
        return;
      };
      const unsubEvents = subscribeCallback(key, EVENT_REVALIDATORS, onRevalidate);
      unmountedRef.current = false;
      keyRef.current = key;
      initialMountedRef.current = true;
      setCache({
        _k: fnArg
      });
      if (shouldDoInitialRevalidation) {
        if (isUndefined(data) || IS_SERVER) {
          softRevalidate();
        } else {
          rAF(softRevalidate);
        }
      }
      return () => {
        unmountedRef.current = true;
        unsubEvents();
      };
    }, [
      key
    ]);
    useIsomorphicLayoutEffect(() => {
      let timer;
      function next() {
        const interval = isFunction2(refreshInterval) ? refreshInterval(data) : refreshInterval;
        if (interval && timer !== -1) {
          timer = setTimeout(execute, interval);
        }
      }
      function execute() {
        if (!getCache().error && (refreshWhenHidden || getConfig().isVisible()) && (refreshWhenOffline || getConfig().isOnline())) {
          revalidate(WITH_DEDUPE).then(next);
        } else {
          next();
        }
      }
      next();
      return () => {
        if (timer) {
          clearTimeout(timer);
          timer = -1;
        }
      };
    }, [
      refreshInterval,
      refreshWhenHidden,
      refreshWhenOffline,
      key
    ]);
    x2(returnedData);
    if (suspense && isUndefined(data) && key) {
      if (!IS_REACT_LEGACY && IS_SERVER) {
        throw new Error("Fallback data is required when using suspense in SSR.");
      }
      fetcherRef.current = fetcher;
      configRef.current = config;
      unmountedRef.current = false;
      throw isUndefined(error) ? revalidate(WITH_DEDUPE) : error;
    }
    return {
      mutate: boundMutate,
      get data() {
        stateDependencies.data = true;
        return returnedData;
      },
      get error() {
        stateDependencies.error = true;
        return error;
      },
      get isValidating() {
        stateDependencies.isValidating = true;
        return isValidating;
      },
      get isLoading() {
        stateDependencies.isLoading = true;
        return isLoading;
      }
    };
  };
  var SWRConfig2 = OBJECT.defineProperty(SWRConfig, "defaultValue", {
    value: defaultConfig
  });
  var useSWR = withArgs(useSWRHandler);

  // src/api.ts
  async function fetchExtensionConfigs() {
    return Promise.resolve({
      chatgpt_webapp_model_name: "text-davinci-002-render",
      openai_model_names: ["text-davinci-003"]
    });
  }

  // node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  init_preact_module();
  init_preact_module();
  var _3 = 0;
  function o3(o4, e3, n2, t3, f3) {
    var l3, s3, u3 = {};
    for (s3 in e3)
      "ref" == s3 ? l3 = e3[s3] : u3[s3] = e3[s3];
    var a3 = { type: o4, props: u3, key: n2, ref: l3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: --_3, __source: f3, __self: t3 };
    if ("function" == typeof o4 && (l3 = o4.defaultProps))
      for (s3 in l3)
        void 0 === u3[s3] && (u3[s3] = l3[s3]);
    return l.vnode && l.vnode(a3), a3;
  }

  // src/options/ProviderSelect.tsx
  async function loadModels() {
    const configs = await fetchExtensionConfigs();
    return configs.openai_model_names;
  }
  var ConfigPanel = ({ config, models }) => {
    var _a, _b, _c, _d;
    const [tab, setTab] = p2(config.provider);
    const { bindings: apiKeyBindings } = use_input_default2((_b = (_a = config.configs["gpt3" /* OpenAI */]) == null ? void 0 : _a.apiKey) != null ? _b : "");
    const [model, setModel] = p2((_d = (_c = config.configs["gpt3" /* OpenAI */]) == null ? void 0 : _c.model) != null ? _d : models[0]);
    const { setToast } = use_toasts_default();
    const save = T2(async () => {
      if (tab === "gpt3" /* OpenAI */) {
        if (!apiKeyBindings.value) {
          alert("Please enter your OpenAI API key");
          return;
        }
        if (!model || !models.includes(model)) {
          alert("\u8BF7\u9009\u62E9\u6A21\u578B");
          return;
        }
      }
      await saveProviderConfigs(tab, {
        ["gpt3" /* OpenAI */]: {
          model,
          apiKey: apiKeyBindings.value
        }
      });
      setToast({ text: "\u5DF2\u4FEE\u6539", type: "success" });
    }, [apiKeyBindings.value, model, models, setToast, tab]);
    return /* @__PURE__ */ o3("div", { className: "flex flex-col gap-3", children: [
      /* @__PURE__ */ o3(tabs_default2, { value: tab, onChange: (v3) => setTab(v3), children: [
        /* @__PURE__ */ o3(tabs_default2.Item, { label: "AiKit\u63A5\u53E3", value: "aikit" /* AiKit */, children: [
          "AiKit\u7F51\u7EDC\u670D\u52A1\uFF0C\u7A33\u5B9A\u9AD8\u901F\uFF0C\u514D\u8D393\u4E2A\u6708\uFF0C",
          /* @__PURE__ */ o3("span", { className: "font-semibold", children: "\u6309\u91CF\u6536\u8D39" }),
          "\uFF0C\u8BE6\u89C1",
          /* @__PURE__ */ o3(
            "a",
            {
              href: "https://www.yuque.com/wnow20/urfk3b/hu0ox2n4xx6fwp63",
              target: "_blank",
              rel: "noreferrer",
              children: "\u6536\u8D39\u653F\u7B56"
            }
          )
        ] }),
        /* @__PURE__ */ o3(tabs_default2.Item, { label: "ChatGPT", value: "chatgpt" /* ChatGPT */, children: "ChatGPT\u7F51\u7EDC\u670D\u52A1\uFF0C\u514D\u8D39\uFF0C\u9700\u79D1\u5B66\u4E0A\u7F51\uFF0C\u7F51\u7EDC\u4E0D\u7A33\u5B9A" }),
        /* @__PURE__ */ o3(tabs_default2.Item, { label: "OpenAI\u63A5\u53E3", value: "gpt3" /* OpenAI */, children: /* @__PURE__ */ o3("div", { className: "flex flex-col gap-2", children: [
          /* @__PURE__ */ o3("span", { children: [
            "OpenAI\u5B98\u65B9\u63A5\u53E3\uFF0C\u9700\u79D1\u5B66\u4E0A\u7F51\uFF0C\u7F51\u7EDC\u4E0D\u7A33\u5B9A\uFF0C",
            /* @__PURE__ */ o3("span", { className: "font-semibold", children: "\u6309\u91CF\u6536\u8D39" })
          ] }),
          /* @__PURE__ */ o3("div", { className: "flex flex-row gap-2", children: [
            /* @__PURE__ */ o3(
              select_default2,
              {
                scale: 2 / 3,
                value: model,
                onChange: (v3) => setModel(v3),
                placeholder: "model",
                children: models.map((m3) => /* @__PURE__ */ o3(select_default2.Option, { value: m3, children: m3 }, m3))
              }
            ),
            /* @__PURE__ */ o3(input_default2, { htmlType: "password", label: "API key", scale: 2 / 3, ...apiKeyBindings })
          ] }),
          /* @__PURE__ */ o3("span", { className: "italic text-xs", children: [
            "\u79D1\u5B66\u4E0A\u7F51\u5E76\u8BBF\u95EE",
            /* @__PURE__ */ o3(
              "a",
              {
                href: "https://platform.openai.com/account/api-keys",
                target: "_blank",
                rel: "noreferrer",
                children: "OpenAI\u8D26\u6237\u4E2D\u5FC3"
              }
            ),
            "\uFF0C\u6CE8\u518COpenAI"
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ o3(button_default2, { scale: 2 / 3, ghost: true, style: { width: 20 }, type: "success", onClick: save, children: "\u4FDD\u5B58" })
    ] });
  };
  function ProviderSelect() {
    const query = useSWR("provider-configs", async () => {
      const [config, models] = await Promise.all([getProviderConfigs(), loadModels()]);
      return { config, models };
    });
    if (query.isLoading) {
      return /* @__PURE__ */ o3(spinner_default2, {});
    }
    return /* @__PURE__ */ o3(ConfigPanel, { config: query.data.config, models: query.data.models });
  }
  var ProviderSelect_default = ProviderSelect;

  // src/options/Options.tsx
  function OptionsPage(props) {
    const [triggerMode, setTriggerMode] = p2("always" /* Always */);
    const [language, setLanguage] = p2("auto" /* Auto */);
    const { setToast } = use_toasts_default();
    h2(() => {
      getUserConfig().then((config) => {
        setTriggerMode(config.triggerMode);
        setLanguage(config.language);
      });
    }, []);
    const onTriggerModeChange = T2(
      (mode) => {
        setTriggerMode(mode);
        updateUserConfig({ triggerMode: mode });
        setToast({ text: "Changes saved", type: "success" });
      },
      [setToast]
    );
    const onThemeChange = T2(
      (theme) => {
        updateUserConfig({ theme });
        props.onThemeChange(theme);
        setToast({ text: "Changes saved", type: "success" });
      },
      [props, setToast]
    );
    const onLanguageChange = T2(
      (language2) => {
        updateUserConfig({ language: language2 });
        setToast({ text: "Changes saved", type: "success" });
      },
      [setToast]
    );
    return /* @__PURE__ */ o3("div", { className: "container mx-auto", children: [
      /* @__PURE__ */ o3("nav", { className: "flex flex-row justify-between items-center mt-5 px-2", children: [
        /* @__PURE__ */ o3("div", { className: "flex flex-row items-center gap-2", children: [
          /* @__PURE__ */ o3("img", { src: logo_default, className: "w-10 h-10 rounded-lg" }),
          /* @__PURE__ */ o3("span", { className: "font-semibold", children: [
            "AiKit (v",
            getExtensionVersion(),
            ")"
          ] })
        ] }),
        /* @__PURE__ */ o3("div", { className: "flex flex-row gap-3", children: [
          /* @__PURE__ */ o3(
            "a",
            {
              href: "https://www.yuque.com/wnow20/aikit/releases-notes",
              target: "_blank",
              rel: "noreferrer",
              children: "\u65E5\u5FD7"
            }
          ),
          /* @__PURE__ */ o3("a", { href: "https://www.yuque.com/wnow20/aikit/feedbacks", target: "_blank", rel: "noreferrer", children: "\u53CD\u9988" }),
          /* @__PURE__ */ o3("a", { href: "https://www.yuque.com/wnow20/aikit/about-us", target: "_blank", rel: "noreferrer", children: "\u5173\u4E8E" })
        ] })
      ] }),
      /* @__PURE__ */ o3("main", { className: "w-[500px] mx-auto mt-14", children: [
        /* @__PURE__ */ o3(text_default2, { h2: true, children: "\u914D\u7F6E" }),
        /* @__PURE__ */ o3(text_default2, { h3: true, className: "mt-5", children: "\u641C\u7D22\u89E6\u53D1\u65B9\u5F0F" }),
        /* @__PURE__ */ o3(
          radio_default2.Group,
          {
            value: triggerMode,
            onChange: (val) => onTriggerModeChange(val),
            children: Object.entries(TRIGGER_MODE_TEXT).map(([value, texts]) => {
              return /* @__PURE__ */ o3(radio_default2, { value, children: [
                texts.title,
                /* @__PURE__ */ o3(radio_default2.Description, { children: texts.desc })
              ] }, value);
            })
          }
        ),
        /* @__PURE__ */ o3(text_default2, { h3: true, className: "mt-5", children: "\u4E3B\u9898" }),
        /* @__PURE__ */ o3(radio_default2.Group, { value: props.theme, onChange: (val) => onThemeChange(val), useRow: true, children: Object.entries(Theme).map(([k4, v3]) => {
          return /* @__PURE__ */ o3(radio_default2, { value: v3, children: THEME_TEXT[v3] }, v3);
        }) }),
        /* @__PURE__ */ o3(text_default2, { h3: true, className: "mt-5 mb-0", children: "\u8BED\u8A00" }),
        /* @__PURE__ */ o3(text_default2, { className: "my-1", children: "AiKit\u5C06\u4F7F\u7528\u60A8\u7684\u8BED\u8A00\u504F\u597D\uFF0C\u56DE\u7B54\u60A8\u7684\u95EE\u9898" }),
        /* @__PURE__ */ o3(
          select_default2,
          {
            value: language,
            placeholder: "Choose one",
            onChange: (val) => onLanguageChange(val),
            children: Object.entries(Language).map(([k4, v3]) => /* @__PURE__ */ o3(select_default2.Option, { value: v3, children: capitalize_default(LANG_TEXT[v3]) }, k4))
          }
        ),
        /* @__PURE__ */ o3(text_default2, { h3: true, className: "mt-5 mb-0", children: "AI\u670D\u52A1\u5546" }),
        /* @__PURE__ */ o3(ProviderSelect_default, {})
      ] })
    ] });
  }
  function Options() {
    const [theme, setTheme] = p2("auto" /* Auto */);
    const themeType = F(() => {
      if (theme === "auto" /* Auto */) {
        return detectSystemColorScheme();
      }
      return theme;
    }, [theme]);
    h2(() => {
      getUserConfig().then((config) => setTheme(config.theme));
    }, []);
    return /* @__PURE__ */ o3(geist_provider_default2, { themeType, children: [
      /* @__PURE__ */ o3(css_baseline_default, {}),
      /* @__PURE__ */ o3(OptionsPage, { theme, onThemeChange: setTheme })
    ] });
  }
  var Options_default = Options;

  // src/options/index.tsx
  P(/* @__PURE__ */ o3(Options_default, {}), document.getElementById("optionsRoot"));
})();
