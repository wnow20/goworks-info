"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res) => function __init() {
    return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/preact/dist/preact.module.js
  function s(n2, l3) {
    for (var u3 in l3)
      n2[u3] = l3[u3];
    return n2;
  }
  function a(n2) {
    var l3 = n2.parentNode;
    l3 && l3.removeChild(n2);
  }
  function h(l3, u3, i3) {
    var t3, o4, r3, f3 = {};
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o4 = u3[r3] : f3[r3] = u3[r3];
    if (arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), "function" == typeof l3 && null != l3.defaultProps)
      for (r3 in l3.defaultProps)
        void 0 === f3[r3] && (f3[r3] = l3.defaultProps[r3]);
    return v(l3, f3, t3, o4, null);
  }
  function v(n2, i3, t3, o4, r3) {
    var f3 = { type: n2, props: i3, key: t3, ref: o4, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == r3 ? ++u : r3 };
    return null == r3 && null != l.vnode && l.vnode(f3), f3;
  }
  function y() {
    return { current: null };
  }
  function p(n2) {
    return n2.children;
  }
  function d(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function _(n2, l3) {
    if (null == l3)
      return n2.__ ? _(n2.__, n2.__.__k.indexOf(n2) + 1) : null;
    for (var u3; l3 < n2.__k.length; l3++)
      if (null != (u3 = n2.__k[l3]) && null != u3.__e)
        return u3.__e;
    return "function" == typeof n2.type ? _(n2) : null;
  }
  function k(n2) {
    var l3, u3;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l3 = 0; l3 < n2.__k.length; l3++)
        if (null != (u3 = n2.__k[l3]) && null != u3.__e) {
          n2.__e = n2.__c.base = u3.__e;
          break;
        }
      return k(n2);
    }
  }
  function b(n2) {
    (!n2.__d && (n2.__d = true) && t.push(n2) && !g.__r++ || o !== l.debounceRendering) && ((o = l.debounceRendering) || setTimeout)(g);
  }
  function g() {
    for (var n2; g.__r = t.length; )
      n2 = t.sort(function(n3, l3) {
        return n3.__v.__b - l3.__v.__b;
      }), t = [], n2.some(function(n3) {
        var l3, u3, i3, t3, o4, r3;
        n3.__d && (o4 = (t3 = (l3 = n3).__v).__e, (r3 = l3.__P) && (u3 = [], (i3 = s({}, t3)).__v = t3.__v + 1, j(r3, t3, i3, l3.__n, void 0 !== r3.ownerSVGElement, null != t3.__h ? [o4] : null, u3, null == o4 ? _(t3) : o4, t3.__h), z(u3, t3), t3.__e != o4 && k(t3)));
      });
  }
  function w(n2, l3, u3, i3, t3, o4, r3, c3, s3, a3) {
    var h3, y3, d3, k4, b3, g4, w4, x4 = i3 && i3.__k || e, C3 = x4.length;
    for (u3.__k = [], h3 = 0; h3 < l3.length; h3++)
      if (null != (k4 = u3.__k[h3] = null == (k4 = l3[h3]) || "boolean" == typeof k4 ? null : "string" == typeof k4 || "number" == typeof k4 || "bigint" == typeof k4 ? v(null, k4, null, null, k4) : Array.isArray(k4) ? v(p, { children: k4 }, null, null, null) : k4.__b > 0 ? v(k4.type, k4.props, k4.key, k4.ref ? k4.ref : null, k4.__v) : k4)) {
        if (k4.__ = u3, k4.__b = u3.__b + 1, null === (d3 = x4[h3]) || d3 && k4.key == d3.key && k4.type === d3.type)
          x4[h3] = void 0;
        else
          for (y3 = 0; y3 < C3; y3++) {
            if ((d3 = x4[y3]) && k4.key == d3.key && k4.type === d3.type) {
              x4[y3] = void 0;
              break;
            }
            d3 = null;
          }
        j(n2, k4, d3 = d3 || f, t3, o4, r3, c3, s3, a3), b3 = k4.__e, (y3 = k4.ref) && d3.ref != y3 && (w4 || (w4 = []), d3.ref && w4.push(d3.ref, null, k4), w4.push(y3, k4.__c || b3, k4)), null != b3 ? (null == g4 && (g4 = b3), "function" == typeof k4.type && k4.__k === d3.__k ? k4.__d = s3 = m(k4, s3, n2) : s3 = A(n2, k4, d3, x4, b3, s3), "function" == typeof u3.type && (u3.__d = s3)) : s3 && d3.__e == s3 && s3.parentNode != n2 && (s3 = _(d3));
      }
    for (u3.__e = g4, h3 = C3; h3--; )
      null != x4[h3] && N(x4[h3], x4[h3]);
    if (w4)
      for (h3 = 0; h3 < w4.length; h3++)
        M(w4[h3], w4[++h3], w4[++h3]);
  }
  function m(n2, l3, u3) {
    for (var i3, t3 = n2.__k, o4 = 0; t3 && o4 < t3.length; o4++)
      (i3 = t3[o4]) && (i3.__ = n2, l3 = "function" == typeof i3.type ? m(i3, l3, u3) : A(u3, i3, i3, t3, i3.__e, l3));
    return l3;
  }
  function x(n2, l3) {
    return l3 = l3 || [], null == n2 || "boolean" == typeof n2 || (Array.isArray(n2) ? n2.some(function(n3) {
      x(n3, l3);
    }) : l3.push(n2)), l3;
  }
  function A(n2, l3, u3, i3, t3, o4) {
    var r3, f3, e3;
    if (void 0 !== l3.__d)
      r3 = l3.__d, l3.__d = void 0;
    else if (null == u3 || t3 != o4 || null == t3.parentNode)
      n:
        if (null == o4 || o4.parentNode !== n2)
          n2.appendChild(t3), r3 = null;
        else {
          for (f3 = o4, e3 = 0; (f3 = f3.nextSibling) && e3 < i3.length; e3 += 1)
            if (f3 == t3)
              break n;
          n2.insertBefore(t3, o4), r3 = o4;
        }
    return void 0 !== r3 ? r3 : t3.nextSibling;
  }
  function C(n2, l3, u3, i3, t3) {
    var o4;
    for (o4 in u3)
      "children" === o4 || "key" === o4 || o4 in l3 || H(n2, o4, null, u3[o4], i3);
    for (o4 in l3)
      t3 && "function" != typeof l3[o4] || "children" === o4 || "key" === o4 || "value" === o4 || "checked" === o4 || u3[o4] === l3[o4] || H(n2, o4, l3[o4], u3[o4], i3);
  }
  function $(n2, l3, u3) {
    "-" === l3[0] ? n2.setProperty(l3, u3) : n2[l3] = null == u3 ? "" : "number" != typeof u3 || c.test(l3) ? u3 : u3 + "px";
  }
  function H(n2, l3, u3, i3, t3) {
    var o4;
    n:
      if ("style" === l3)
        if ("string" == typeof u3)
          n2.style.cssText = u3;
        else {
          if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3)
            for (l3 in i3)
              u3 && l3 in u3 || $(n2.style, l3, "");
          if (u3)
            for (l3 in u3)
              i3 && u3[l3] === i3[l3] || $(n2.style, l3, u3[l3]);
        }
      else if ("o" === l3[0] && "n" === l3[1])
        o4 = l3 !== (l3 = l3.replace(/Capture$/, "")), l3 = l3.toLowerCase() in n2 ? l3.toLowerCase().slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + o4] = u3, u3 ? i3 || n2.addEventListener(l3, o4 ? T : I, o4) : n2.removeEventListener(l3, o4 ? T : I, o4);
      else if ("dangerouslySetInnerHTML" !== l3) {
        if (t3)
          l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("href" !== l3 && "list" !== l3 && "form" !== l3 && "tabIndex" !== l3 && "download" !== l3 && l3 in n2)
          try {
            n2[l3] = null == u3 ? "" : u3;
            break n;
          } catch (n3) {
          }
        "function" == typeof u3 || (null == u3 || false === u3 && -1 == l3.indexOf("-") ? n2.removeAttribute(l3) : n2.setAttribute(l3, u3));
      }
  }
  function I(n2) {
    this.l[n2.type + false](l.event ? l.event(n2) : n2);
  }
  function T(n2) {
    this.l[n2.type + true](l.event ? l.event(n2) : n2);
  }
  function j(n2, u3, i3, t3, o4, r3, f3, e3, c3) {
    var a3, h3, v3, y3, _4, k4, b3, g4, m3, x4, A4, C3, $3, H3, I3, T4 = u3.type;
    if (void 0 !== u3.constructor)
      return null;
    null != i3.__h && (c3 = i3.__h, e3 = u3.__e = i3.__e, u3.__h = null, r3 = [e3]), (a3 = l.__b) && a3(u3);
    try {
      n:
        if ("function" == typeof T4) {
          if (g4 = u3.props, m3 = (a3 = T4.contextType) && t3[a3.__c], x4 = a3 ? m3 ? m3.props.value : a3.__ : t3, i3.__c ? b3 = (h3 = u3.__c = i3.__c).__ = h3.__E : ("prototype" in T4 && T4.prototype.render ? u3.__c = h3 = new T4(g4, x4) : (u3.__c = h3 = new d(g4, x4), h3.constructor = T4, h3.render = O), m3 && m3.sub(h3), h3.props = g4, h3.state || (h3.state = {}), h3.context = x4, h3.__n = t3, v3 = h3.__d = true, h3.__h = [], h3._sb = []), null == h3.__s && (h3.__s = h3.state), null != T4.getDerivedStateFromProps && (h3.__s == h3.state && (h3.__s = s({}, h3.__s)), s(h3.__s, T4.getDerivedStateFromProps(g4, h3.__s))), y3 = h3.props, _4 = h3.state, v3)
            null == T4.getDerivedStateFromProps && null != h3.componentWillMount && h3.componentWillMount(), null != h3.componentDidMount && h3.__h.push(h3.componentDidMount);
          else {
            if (null == T4.getDerivedStateFromProps && g4 !== y3 && null != h3.componentWillReceiveProps && h3.componentWillReceiveProps(g4, x4), !h3.__e && null != h3.shouldComponentUpdate && false === h3.shouldComponentUpdate(g4, h3.__s, x4) || u3.__v === i3.__v) {
              for (h3.props = g4, h3.state = h3.__s, u3.__v !== i3.__v && (h3.__d = false), h3.__v = u3, u3.__e = i3.__e, u3.__k = i3.__k, u3.__k.forEach(function(n3) {
                n3 && (n3.__ = u3);
              }), A4 = 0; A4 < h3._sb.length; A4++)
                h3.__h.push(h3._sb[A4]);
              h3._sb = [], h3.__h.length && f3.push(h3);
              break n;
            }
            null != h3.componentWillUpdate && h3.componentWillUpdate(g4, h3.__s, x4), null != h3.componentDidUpdate && h3.__h.push(function() {
              h3.componentDidUpdate(y3, _4, k4);
            });
          }
          if (h3.context = x4, h3.props = g4, h3.__v = u3, h3.__P = n2, C3 = l.__r, $3 = 0, "prototype" in T4 && T4.prototype.render) {
            for (h3.state = h3.__s, h3.__d = false, C3 && C3(u3), a3 = h3.render(h3.props, h3.state, h3.context), H3 = 0; H3 < h3._sb.length; H3++)
              h3.__h.push(h3._sb[H3]);
            h3._sb = [];
          } else
            do {
              h3.__d = false, C3 && C3(u3), a3 = h3.render(h3.props, h3.state, h3.context), h3.state = h3.__s;
            } while (h3.__d && ++$3 < 25);
          h3.state = h3.__s, null != h3.getChildContext && (t3 = s(s({}, t3), h3.getChildContext())), v3 || null == h3.getSnapshotBeforeUpdate || (k4 = h3.getSnapshotBeforeUpdate(y3, _4)), I3 = null != a3 && a3.type === p && null == a3.key ? a3.props.children : a3, w(n2, Array.isArray(I3) ? I3 : [I3], u3, i3, t3, o4, r3, f3, e3, c3), h3.base = u3.__e, u3.__h = null, h3.__h.length && f3.push(h3), b3 && (h3.__E = h3.__ = null), h3.__e = false;
        } else
          null == r3 && u3.__v === i3.__v ? (u3.__k = i3.__k, u3.__e = i3.__e) : u3.__e = L(i3.__e, u3, i3, t3, o4, r3, f3, c3);
      (a3 = l.diffed) && a3(u3);
    } catch (n3) {
      u3.__v = null, (c3 || null != r3) && (u3.__e = e3, u3.__h = !!c3, r3[r3.indexOf(e3)] = null), l.__e(n3, u3, i3);
    }
  }
  function z(n2, u3) {
    l.__c && l.__c(u3, n2), n2.some(function(u4) {
      try {
        n2 = u4.__h, u4.__h = [], n2.some(function(n3) {
          n3.call(u4);
        });
      } catch (n3) {
        l.__e(n3, u4.__v);
      }
    });
  }
  function L(l3, u3, i3, t3, o4, r3, e3, c3) {
    var s3, h3, v3, y3 = i3.props, p3 = u3.props, d3 = u3.type, k4 = 0;
    if ("svg" === d3 && (o4 = true), null != r3) {
      for (; k4 < r3.length; k4++)
        if ((s3 = r3[k4]) && "setAttribute" in s3 == !!d3 && (d3 ? s3.localName === d3 : 3 === s3.nodeType)) {
          l3 = s3, r3[k4] = null;
          break;
        }
    }
    if (null == l3) {
      if (null === d3)
        return document.createTextNode(p3);
      l3 = o4 ? document.createElementNS("http://www.w3.org/2000/svg", d3) : document.createElement(d3, p3.is && p3), r3 = null, c3 = false;
    }
    if (null === d3)
      y3 === p3 || c3 && l3.data === p3 || (l3.data = p3);
    else {
      if (r3 = r3 && n.call(l3.childNodes), h3 = (y3 = i3.props || f).dangerouslySetInnerHTML, v3 = p3.dangerouslySetInnerHTML, !c3) {
        if (null != r3)
          for (y3 = {}, k4 = 0; k4 < l3.attributes.length; k4++)
            y3[l3.attributes[k4].name] = l3.attributes[k4].value;
        (v3 || h3) && (v3 && (h3 && v3.__html == h3.__html || v3.__html === l3.innerHTML) || (l3.innerHTML = v3 && v3.__html || ""));
      }
      if (C(l3, p3, y3, o4, c3), v3)
        u3.__k = [];
      else if (k4 = u3.props.children, w(l3, Array.isArray(k4) ? k4 : [k4], u3, i3, t3, o4 && "foreignObject" !== d3, r3, e3, r3 ? r3[0] : i3.__k && _(i3, 0), c3), null != r3)
        for (k4 = r3.length; k4--; )
          null != r3[k4] && a(r3[k4]);
      c3 || ("value" in p3 && void 0 !== (k4 = p3.value) && (k4 !== l3.value || "progress" === d3 && !k4 || "option" === d3 && k4 !== y3.value) && H(l3, "value", k4, y3.value, false), "checked" in p3 && void 0 !== (k4 = p3.checked) && k4 !== l3.checked && H(l3, "checked", k4, y3.checked, false));
    }
    return l3;
  }
  function M(n2, u3, i3) {
    try {
      "function" == typeof n2 ? n2(u3) : n2.current = u3;
    } catch (n3) {
      l.__e(n3, i3);
    }
  }
  function N(n2, u3, i3) {
    var t3, o4;
    if (l.unmount && l.unmount(n2), (t3 = n2.ref) && (t3.current && t3.current !== n2.__e || M(t3, null, u3)), null != (t3 = n2.__c)) {
      if (t3.componentWillUnmount)
        try {
          t3.componentWillUnmount();
        } catch (n3) {
          l.__e(n3, u3);
        }
      t3.base = t3.__P = null, n2.__c = void 0;
    }
    if (t3 = n2.__k)
      for (o4 = 0; o4 < t3.length; o4++)
        t3[o4] && N(t3[o4], u3, i3 || "function" != typeof n2.type);
    i3 || null == n2.__e || a(n2.__e), n2.__ = n2.__e = n2.__d = void 0;
  }
  function O(n2, l3, u3) {
    return this.constructor(n2, u3);
  }
  function P(u3, i3, t3) {
    var o4, r3, e3;
    l.__ && l.__(u3, i3), r3 = (o4 = "function" == typeof t3) ? null : t3 && t3.__k || i3.__k, e3 = [], j(i3, u3 = (!o4 && t3 || i3).__k = h(p, null, [u3]), r3 || f, f, void 0 !== i3.ownerSVGElement, !o4 && t3 ? [t3] : r3 ? null : i3.firstChild ? n.call(i3.childNodes) : null, e3, !o4 && t3 ? t3 : r3 ? r3.__e : i3.firstChild, o4), z(e3, u3);
  }
  function S(n2, l3) {
    P(n2, l3, S);
  }
  function q(l3, u3, i3) {
    var t3, o4, r3, f3 = s({}, l3.props);
    for (r3 in u3)
      "key" == r3 ? t3 = u3[r3] : "ref" == r3 ? o4 = u3[r3] : f3[r3] = u3[r3];
    return arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), v(l3.type, f3, t3 || l3.key, o4 || l3.ref, null);
  }
  function B(n2, l3) {
    var u3 = { __c: l3 = "__cC" + r++, __: n2, Consumer: function(n3, l4) {
      return n3.children(l4);
    }, Provider: function(n3) {
      var u4, i3;
      return this.getChildContext || (u4 = [], (i3 = {})[l3] = this, this.getChildContext = function() {
        return i3;
      }, this.shouldComponentUpdate = function(n4) {
        this.props.value !== n4.value && u4.some(b);
      }, this.sub = function(n4) {
        u4.push(n4);
        var l4 = n4.componentWillUnmount;
        n4.componentWillUnmount = function() {
          u4.splice(u4.indexOf(n4), 1), l4 && l4.call(n4);
        };
      }), n3.children;
    } };
    return u3.Provider.__ = u3.Consumer.contextType = u3;
  }
  var n, l, u, i, t, o, r, f, e, c;
  var init_preact_module = __esm({
    "node_modules/preact/dist/preact.module.js"() {
      f = {};
      e = [];
      c = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
      n = e.slice, l = { __e: function(n2, l3, u3, i3) {
        for (var t3, o4, r3; l3 = l3.__; )
          if ((t3 = l3.__c) && !t3.__)
            try {
              if ((o4 = t3.constructor) && null != o4.getDerivedStateFromError && (t3.setState(o4.getDerivedStateFromError(n2)), r3 = t3.__d), null != t3.componentDidCatch && (t3.componentDidCatch(n2, i3 || {}), r3 = t3.__d), r3)
                return t3.__E = t3;
            } catch (l4) {
              n2 = l4;
            }
        throw n2;
      } }, u = 0, i = function(n2) {
        return null != n2 && void 0 === n2.constructor;
      }, d.prototype.setState = function(n2, l3) {
        var u3;
        u3 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n2 && (n2 = n2(s({}, u3), this.props)), n2 && s(u3, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), b(this));
      }, d.prototype.forceUpdate = function(n2) {
        this.__v && (this.__e = true, n2 && this.__h.push(n2), b(this));
      }, d.prototype.render = p, t = [], g.__r = 0, r = 0;
    }
  });

  // node_modules/preact/hooks/dist/hooks.module.js
  function d2(t3, u3) {
    l.__h && l.__h(r2, t3, o2 || u3), o2 = 0;
    var i3 = r2.__H || (r2.__H = { __: [], __h: [] });
    return t3 >= i3.__.length && i3.__.push({ __V: c2 }), i3.__[t3];
  }
  function p2(n2) {
    return o2 = 1, y2(B2, n2);
  }
  function y2(n2, u3, i3) {
    var o4 = d2(t2++, 2);
    if (o4.t = n2, !o4.__c && (o4.__ = [i3 ? i3(u3) : B2(void 0, u3), function(n3) {
      var t3 = o4.__N ? o4.__N[0] : o4.__[0], r3 = o4.t(t3, n3);
      t3 !== r3 && (o4.__N = [r3, o4.__[1]], o4.__c.setState({}));
    }], o4.__c = r2, !r2.u)) {
      r2.u = true;
      var f3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        if (!o4.__c.__H)
          return true;
        var u4 = o4.__c.__H.__.filter(function(n4) {
          return n4.__c;
        });
        if (u4.every(function(n4) {
          return !n4.__N;
        }))
          return !f3 || f3.call(this, n3, t3, r3);
        var i4 = false;
        return u4.forEach(function(n4) {
          if (n4.__N) {
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), !(!i4 && o4.__c.props === n3) && (!f3 || f3.call(this, n3, t3, r3));
      };
    }
    return o4.__N || o4.__;
  }
  function h2(u3, i3) {
    var o4 = d2(t2++, 3);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__H.__h.push(o4));
  }
  function s2(u3, i3) {
    var o4 = d2(t2++, 4);
    !l.__s && z2(o4.__H, i3) && (o4.__ = u3, o4.i = i3, r2.__h.push(o4));
  }
  function _2(n2) {
    return o2 = 5, F(function() {
      return { current: n2 };
    }, []);
  }
  function A2(n2, t3, r3) {
    o2 = 6, s2(function() {
      return "function" == typeof n2 ? (n2(t3()), function() {
        return n2(null);
      }) : n2 ? (n2.current = t3(), function() {
        return n2.current = null;
      }) : void 0;
    }, null == r3 ? r3 : r3.concat(n2));
  }
  function F(n2, r3) {
    var u3 = d2(t2++, 7);
    return z2(u3.__H, r3) ? (u3.__V = n2(), u3.i = r3, u3.__h = n2, u3.__V) : u3.__;
  }
  function T2(n2, t3) {
    return o2 = 8, F(function() {
      return n2;
    }, t3);
  }
  function q2(n2) {
    var u3 = r2.context[n2.__c], i3 = d2(t2++, 9);
    return i3.c = n2, u3 ? (null == i3.__ && (i3.__ = true, u3.sub(r2)), u3.props.value) : n2.__;
  }
  function x2(t3, r3) {
    l.useDebugValue && l.useDebugValue(r3 ? r3(t3) : t3);
  }
  function P2(n2) {
    var u3 = d2(t2++, 10), i3 = p2();
    return u3.__ = n2, r2.componentDidCatch || (r2.componentDidCatch = function(n3, t3) {
      u3.__ && u3.__(n3, t3), i3[1](n3);
    }), [i3[0], function() {
      i3[1](void 0);
    }];
  }
  function V() {
    var n2 = d2(t2++, 11);
    if (!n2.__) {
      for (var u3 = r2.__v; null !== u3 && !u3.__m && null !== u3.__; )
        u3 = u3.__;
      var i3 = u3.__m || (u3.__m = [0, 0]);
      n2.__ = "P" + i3[0] + "-" + i3[1]++;
    }
    return n2.__;
  }
  function b2() {
    for (var t3; t3 = f2.shift(); )
      if (t3.__P && t3.__H)
        try {
          t3.__H.__h.forEach(k2), t3.__H.__h.forEach(w2), t3.__H.__h = [];
        } catch (r3) {
          t3.__H.__h = [], l.__e(r3, t3.__v);
        }
  }
  function j2(n2) {
    var t3, r3 = function() {
      clearTimeout(u3), g2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u3 = setTimeout(r3, 100);
    g2 && (t3 = requestAnimationFrame(r3));
  }
  function k2(n2) {
    var t3 = r2, u3 = n2.__c;
    "function" == typeof u3 && (n2.__c = void 0, u3()), r2 = t3;
  }
  function w2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function z2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  function B2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }
  var t2, r2, u2, i2, o2, f2, c2, e2, a2, v2, l2, m2, g2;
  var init_hooks_module = __esm({
    "node_modules/preact/hooks/dist/hooks.module.js"() {
      init_preact_module();
      o2 = 0;
      f2 = [];
      c2 = [];
      e2 = l.__b;
      a2 = l.__r;
      v2 = l.diffed;
      l2 = l.__c;
      m2 = l.unmount;
      l.__b = function(n2) {
        r2 = null, e2 && e2(n2);
      }, l.__r = function(n2) {
        a2 && a2(n2), t2 = 0;
        var i3 = (r2 = n2.__c).__H;
        i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.forEach(function(n3) {
          n3.__N && (n3.__ = n3.__N), n3.__V = c2, n3.__N = n3.i = void 0;
        })) : (i3.__h.forEach(k2), i3.__h.forEach(w2), i3.__h = [])), u2 = r2;
      }, l.diffed = function(t3) {
        v2 && v2(t3);
        var o4 = t3.__c;
        o4 && o4.__H && (o4.__H.__h.length && (1 !== f2.push(o4) && i2 === l.requestAnimationFrame || ((i2 = l.requestAnimationFrame) || j2)(b2)), o4.__H.__.forEach(function(n2) {
          n2.i && (n2.__H = n2.i), n2.__V !== c2 && (n2.__ = n2.__V), n2.i = void 0, n2.__V = c2;
        })), u2 = r2 = null;
      }, l.__c = function(t3, r3) {
        r3.some(function(t4) {
          try {
            t4.__h.forEach(k2), t4.__h = t4.__h.filter(function(n2) {
              return !n2.__ || w2(n2);
            });
          } catch (u3) {
            r3.some(function(n2) {
              n2.__h && (n2.__h = []);
            }), r3 = [], l.__e(u3, t4.__v);
          }
        }), l2 && l2(t3, r3);
      }, l.unmount = function(t3) {
        m2 && m2(t3);
        var r3, u3 = t3.__c;
        u3 && u3.__H && (u3.__H.__.forEach(function(n2) {
          try {
            k2(n2);
          } catch (n3) {
            r3 = n3;
          }
        }), u3.__H = void 0, r3 && l.__e(r3, u3.__v));
      };
      g2 = "function" == typeof requestAnimationFrame;
    }
  });

  // node_modules/preact/compat/dist/compat.module.js
  function g3(n2, t3) {
    for (var e3 in t3)
      n2[e3] = t3[e3];
    return n2;
  }
  function C2(n2, t3) {
    for (var e3 in n2)
      if ("__source" !== e3 && !(e3 in t3))
        return true;
    for (var r3 in t3)
      if ("__source" !== r3 && n2[r3] !== t3[r3])
        return true;
    return false;
  }
  function E(n2, t3) {
    return n2 === t3 && (0 !== n2 || 1 / n2 == 1 / t3) || n2 != n2 && t3 != t3;
  }
  function w3(n2) {
    this.props = n2;
  }
  function R(n2, e3) {
    function r3(n3) {
      var t3 = this.props.ref, r4 = t3 == n3.ref;
      return !r4 && t3 && (t3.call ? t3(null) : t3.current = null), e3 ? !e3(this.props, n3) || !r4 : C2(this.props, n3);
    }
    function u3(e4) {
      return this.shouldComponentUpdate = r3, h(n2, e4);
    }
    return u3.displayName = "Memo(" + (n2.displayName || n2.name) + ")", u3.prototype.isReactComponent = true, u3.__f = true, u3;
  }
  function k3(n2) {
    function t3(t4) {
      var e3 = g3({}, t4);
      return delete e3.ref, n2(e3, t4.ref || null);
    }
    return t3.$$typeof = N2, t3.render = t3, t3.prototype.isReactComponent = t3.__f = true, t3.displayName = "ForwardRef(" + (n2.displayName || n2.name) + ")", t3;
  }
  function L2(n2, t3, e3) {
    return n2 && (n2.__c && n2.__c.__H && (n2.__c.__H.__.forEach(function(n3) {
      "function" == typeof n3.__c && n3.__c();
    }), n2.__c.__H = null), null != (n2 = g3({}, n2)).__c && (n2.__c.__P === e3 && (n2.__c.__P = t3), n2.__c = null), n2.__k = n2.__k && n2.__k.map(function(n3) {
      return L2(n3, t3, e3);
    })), n2;
  }
  function U(n2, t3, e3) {
    return n2 && (n2.__v = null, n2.__k = n2.__k && n2.__k.map(function(n3) {
      return U(n3, t3, e3);
    }), n2.__c && n2.__c.__P === t3 && (n2.__e && e3.insertBefore(n2.__e, n2.__d), n2.__c.__e = true, n2.__c.__P = e3)), n2;
  }
  function D() {
    this.__u = 0, this.t = null, this.__b = null;
  }
  function F2(n2) {
    var t3 = n2.__.__c;
    return t3 && t3.__a && t3.__a(n2);
  }
  function M2(n2) {
    var e3, r3, u3;
    function o4(o5) {
      if (e3 || (e3 = n2()).then(function(n3) {
        r3 = n3.default || n3;
      }, function(n3) {
        u3 = n3;
      }), u3)
        throw u3;
      if (!r3)
        throw e3;
      return h(r3, o5);
    }
    return o4.displayName = "Lazy", o4.__f = true, o4;
  }
  function V2() {
    this.u = null, this.o = null;
  }
  function P3(n2) {
    return this.getChildContext = function() {
      return n2.context;
    }, n2.children;
  }
  function $2(n2) {
    var e3 = this, r3 = n2.i;
    e3.componentWillUnmount = function() {
      P(null, e3.l), e3.l = null, e3.i = null;
    }, e3.i && e3.i !== r3 && e3.componentWillUnmount(), n2.__v ? (e3.l || (e3.i = r3, e3.l = { nodeType: 1, parentNode: r3, childNodes: [], appendChild: function(n3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, insertBefore: function(n3, t3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, removeChild: function(n3) {
      this.childNodes.splice(this.childNodes.indexOf(n3) >>> 1, 1), e3.i.removeChild(n3);
    } }), P(h(P3, { context: e3.context }, n2.__v), e3.l)) : e3.l && e3.componentWillUnmount();
  }
  function j3(n2, e3) {
    var r3 = h($2, { __v: n2, i: e3 });
    return r3.containerInfo = e3, r3;
  }
  function Y(n2, t3, e3) {
    return null == t3.__k && (t3.textContent = ""), P(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function q3(n2, t3, e3) {
    return S(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function J() {
  }
  function K() {
    return this.cancelBubble;
  }
  function Q() {
    return this.defaultPrevented;
  }
  function on(n2) {
    return h.bind(null, n2);
  }
  function ln(n2) {
    return !!n2 && n2.$$typeof === z3;
  }
  function cn(n2) {
    return ln(n2) ? q.apply(null, arguments) : n2;
  }
  function fn(n2) {
    return !!n2.__k && (P(null, n2), true);
  }
  function an(n2) {
    return n2 && (n2.base || 1 === n2.nodeType && n2) || null;
  }
  function dn(n2) {
    n2();
  }
  function pn(n2) {
    return n2;
  }
  function mn() {
    return [false, dn];
  }
  function _n(n2, t3) {
    var e3 = t3(), r3 = p2({ h: { __: e3, v: t3 } }), u3 = r3[0].h, o4 = r3[1];
    return s2(function() {
      u3.__ = e3, u3.v = t3, E(u3.__, t3()) || o4({ h: u3 });
    }, [n2, e3, t3]), h2(function() {
      return E(u3.__, u3.v()) || o4({ h: u3 }), n2(function() {
        E(u3.__, u3.v()) || o4({ h: u3 });
      });
    }, [n2]), e3;
  }
  var x3, N2, A3, O2, T3, I2, W, z3, B3, H2, Z, G, X, nn, tn, en, rn, un, sn, hn, vn, yn, bn;
  var init_compat_module = __esm({
    "node_modules/preact/compat/dist/compat.module.js"() {
      init_preact_module();
      init_preact_module();
      init_hooks_module();
      init_hooks_module();
      (w3.prototype = new d()).isPureReactComponent = true, w3.prototype.shouldComponentUpdate = function(n2, t3) {
        return C2(this.props, n2) || C2(this.state, t3);
      };
      x3 = l.__b;
      l.__b = function(n2) {
        n2.type && n2.type.__f && n2.ref && (n2.props.ref = n2.ref, n2.ref = null), x3 && x3(n2);
      };
      N2 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
      A3 = function(n2, t3) {
        return null == n2 ? null : x(x(n2).map(t3));
      };
      O2 = { map: A3, forEach: A3, count: function(n2) {
        return n2 ? x(n2).length : 0;
      }, only: function(n2) {
        var t3 = x(n2);
        if (1 !== t3.length)
          throw "Children.only";
        return t3[0];
      }, toArray: x };
      T3 = l.__e;
      l.__e = function(n2, t3, e3, r3) {
        if (n2.then) {
          for (var u3, o4 = t3; o4 = o4.__; )
            if ((u3 = o4.__c) && u3.__c)
              return null == t3.__e && (t3.__e = e3.__e, t3.__k = e3.__k), u3.__c(n2, t3);
        }
        T3(n2, t3, e3, r3);
      };
      I2 = l.unmount;
      l.unmount = function(n2) {
        var t3 = n2.__c;
        t3 && t3.__R && t3.__R(), t3 && true === n2.__h && (n2.type = null), I2 && I2(n2);
      }, (D.prototype = new d()).__c = function(n2, t3) {
        var e3 = t3.__c, r3 = this;
        null == r3.t && (r3.t = []), r3.t.push(e3);
        var u3 = F2(r3.__v), o4 = false, i3 = function() {
          o4 || (o4 = true, e3.__R = null, u3 ? u3(l3) : l3());
        };
        e3.__R = i3;
        var l3 = function() {
          if (!--r3.__u) {
            if (r3.state.__a) {
              var n3 = r3.state.__a;
              r3.__v.__k[0] = U(n3, n3.__c.__P, n3.__c.__O);
            }
            var t4;
            for (r3.setState({ __a: r3.__b = null }); t4 = r3.t.pop(); )
              t4.forceUpdate();
          }
        }, c3 = true === t3.__h;
        r3.__u++ || c3 || r3.setState({ __a: r3.__b = r3.__v.__k[0] }), n2.then(i3, i3);
      }, D.prototype.componentWillUnmount = function() {
        this.t = [];
      }, D.prototype.render = function(n2, e3) {
        if (this.__b) {
          if (this.__v.__k) {
            var r3 = document.createElement("div"), o4 = this.__v.__k[0].__c;
            this.__v.__k[0] = L2(this.__b, r3, o4.__O = o4.__P);
          }
          this.__b = null;
        }
        var i3 = e3.__a && h(p, null, n2.fallback);
        return i3 && (i3.__h = null), [h(p, null, e3.__a ? null : n2.children), i3];
      };
      W = function(n2, t3, e3) {
        if (++e3[1] === e3[0] && n2.o.delete(t3), n2.props.revealOrder && ("t" !== n2.props.revealOrder[0] || !n2.o.size))
          for (e3 = n2.u; e3; ) {
            for (; e3.length > 3; )
              e3.pop()();
            if (e3[1] < e3[0])
              break;
            n2.u = e3 = e3[2];
          }
      };
      (V2.prototype = new d()).__a = function(n2) {
        var t3 = this, e3 = F2(t3.__v), r3 = t3.o.get(n2);
        return r3[0]++, function(u3) {
          var o4 = function() {
            t3.props.revealOrder ? (r3.push(u3), W(t3, n2, r3)) : u3();
          };
          e3 ? e3(o4) : o4();
        };
      }, V2.prototype.render = function(n2) {
        this.u = null, this.o = /* @__PURE__ */ new Map();
        var t3 = x(n2.children);
        n2.revealOrder && "b" === n2.revealOrder[0] && t3.reverse();
        for (var e3 = t3.length; e3--; )
          this.o.set(t3[e3], this.u = [1, 0, this.u]);
        return n2.children;
      }, V2.prototype.componentDidUpdate = V2.prototype.componentDidMount = function() {
        var n2 = this;
        this.o.forEach(function(t3, e3) {
          W(n2, e3, t3);
        });
      };
      z3 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
      B3 = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
      H2 = "undefined" != typeof document;
      Z = function(n2) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/i : /fil|che|ra/i).test(n2);
      };
      d.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t3) {
        Object.defineProperty(d.prototype, t3, { configurable: true, get: function() {
          return this["UNSAFE_" + t3];
        }, set: function(n2) {
          Object.defineProperty(this, t3, { configurable: true, writable: true, value: n2 });
        } });
      });
      G = l.event;
      l.event = function(n2) {
        return G && (n2 = G(n2)), n2.persist = J, n2.isPropagationStopped = K, n2.isDefaultPrevented = Q, n2.nativeEvent = n2;
      };
      nn = { configurable: true, get: function() {
        return this.class;
      } };
      tn = l.vnode;
      l.vnode = function(n2) {
        var t3 = n2.type, e3 = n2.props, u3 = e3;
        if ("string" == typeof t3) {
          var o4 = -1 === t3.indexOf("-");
          for (var i3 in u3 = {}, e3) {
            var l3 = e3[i3];
            H2 && "children" === i3 && "noscript" === t3 || "value" === i3 && "defaultValue" in e3 && null == l3 || ("defaultValue" === i3 && "value" in e3 && null == e3.value ? i3 = "value" : "download" === i3 && true === l3 ? l3 = "" : /ondoubleclick/i.test(i3) ? i3 = "ondblclick" : /^onchange(textarea|input)/i.test(i3 + t3) && !Z(e3.type) ? i3 = "oninput" : /^onfocus$/i.test(i3) ? i3 = "onfocusin" : /^onblur$/i.test(i3) ? i3 = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(i3) ? i3 = i3.toLowerCase() : o4 && B3.test(i3) ? i3 = i3.replace(/[A-Z0-9]/g, "-$&").toLowerCase() : null === l3 && (l3 = void 0), /^oninput$/i.test(i3) && (i3 = i3.toLowerCase(), u3[i3] && (i3 = "oninputCapture")), u3[i3] = l3);
          }
          "select" == t3 && u3.multiple && Array.isArray(u3.value) && (u3.value = x(e3.children).forEach(function(n3) {
            n3.props.selected = -1 != u3.value.indexOf(n3.props.value);
          })), "select" == t3 && null != u3.defaultValue && (u3.value = x(e3.children).forEach(function(n3) {
            n3.props.selected = u3.multiple ? -1 != u3.defaultValue.indexOf(n3.props.value) : u3.defaultValue == n3.props.value;
          })), n2.props = u3, e3.class != e3.className && (nn.enumerable = "className" in e3, null != e3.className && (u3.class = e3.className), Object.defineProperty(u3, "className", nn));
        }
        n2.$$typeof = z3, tn && tn(n2);
      };
      en = l.__r;
      l.__r = function(n2) {
        en && en(n2), X = n2.__c;
      };
      rn = { ReactCurrentDispatcher: { current: { readContext: function(n2) {
        return X.__n[n2.__c].props.value;
      } } } };
      un = "17.0.2";
      sn = function(n2, t3) {
        return n2(t3);
      };
      hn = function(n2, t3) {
        return n2(t3);
      };
      vn = p;
      yn = s2;
      bn = { useState: p2, useId: V, useReducer: y2, useEffect: h2, useLayoutEffect: s2, useInsertionEffect: yn, useTransition: mn, useDeferredValue: pn, useSyncExternalStore: _n, startTransition: dn, useRef: _2, useImperativeHandle: A2, useMemo: F, useCallback: T2, useContext: q2, useDebugValue: x2, version: "17.0.2", Children: O2, render: Y, hydrate: q3, unmountComponentAtNode: fn, createPortal: j3, createElement: h, createContext: B, createFactory: on, cloneElement: cn, createRef: y, Fragment: p, isValidElement: ln, findDOMNode: an, Component: d, PureComponent: w3, memo: R, forwardRef: k3, flushSync: hn, unstable_batchedUpdates: sn, StrictMode: vn, Suspense: D, SuspenseList: V2, lazy: M2, __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: rn };
    }
  });

  // node_modules/react/index.mjs
  var react_exports = {};
  __export(react_exports, {
    Children: () => O2,
    Component: () => d,
    Fragment: () => p,
    PureComponent: () => w3,
    StrictMode: () => vn,
    Suspense: () => D,
    SuspenseList: () => V2,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => rn,
    cloneElement: () => cn,
    createContext: () => B,
    createElement: () => h,
    createFactory: () => on,
    createPortal: () => j3,
    createRef: () => y,
    default: () => bn,
    findDOMNode: () => an,
    flushSync: () => hn,
    forwardRef: () => k3,
    hydrate: () => q3,
    isValidElement: () => ln,
    lazy: () => M2,
    memo: () => R,
    render: () => Y,
    startTransition: () => dn,
    unmountComponentAtNode: () => fn,
    unstable_batchedUpdates: () => sn,
    useCallback: () => T2,
    useContext: () => q2,
    useDebugValue: () => x2,
    useDeferredValue: () => pn,
    useEffect: () => h2,
    useErrorBoundary: () => P2,
    useId: () => V,
    useImperativeHandle: () => A2,
    useInsertionEffect: () => yn,
    useLayoutEffect: () => s2,
    useMemo: () => F,
    useReducer: () => y2,
    useRef: () => _2,
    useState: () => p2,
    useSyncExternalStore: () => _n,
    useTransition: () => mn,
    version: () => un
  });
  var init_react = __esm({
    "node_modules/react/index.mjs"() {
      init_compat_module();
      init_compat_module();
    }
  });

  // node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.min.js
  var require_use_sync_external_store_shim_production_min = __commonJS({
    "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.min.js"(exports) {
      "use strict";
      var e3 = (init_react(), __toCommonJS(react_exports));
      function h3(a3, b3) {
        return a3 === b3 && (0 !== a3 || 1 / a3 === 1 / b3) || a3 !== a3 && b3 !== b3;
      }
      var k4 = "function" === typeof Object.is ? Object.is : h3;
      var l3 = e3.useState;
      var m3 = e3.useEffect;
      var n2 = e3.useLayoutEffect;
      var p3 = e3.useDebugValue;
      function q4(a3, b3) {
        var d3 = b3(), f3 = l3({ inst: { value: d3, getSnapshot: b3 } }), c3 = f3[0].inst, g4 = f3[1];
        n2(function() {
          c3.value = d3;
          c3.getSnapshot = b3;
          r3(c3) && g4({ inst: c3 });
        }, [a3, d3, b3]);
        m3(function() {
          r3(c3) && g4({ inst: c3 });
          return a3(function() {
            r3(c3) && g4({ inst: c3 });
          });
        }, [a3]);
        p3(d3);
        return d3;
      }
      function r3(a3) {
        var b3 = a3.getSnapshot;
        a3 = a3.value;
        try {
          var d3 = b3();
          return !k4(a3, d3);
        } catch (f3) {
          return true;
        }
      }
      function t3(a3, b3) {
        return b3();
      }
      var u3 = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? t3 : q4;
      exports.useSyncExternalStore = void 0 !== e3.useSyncExternalStore ? e3.useSyncExternalStore : u3;
    }
  });

  // node_modules/use-sync-external-store/shim/index.js
  var require_shim = __commonJS({
    "node_modules/use-sync-external-store/shim/index.js"(exports, module) {
      "use strict";
      if (true) {
        module.exports = require_use_sync_external_store_shim_production_min();
      } else {
        module.exports = null;
      }
    }
  });

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache2 = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache2;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache2) {
                    return cache2[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache2, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache2[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache2) {
                    cache2[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache2, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache2, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(
                  req,
                  {},
                  {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  }
                );
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // node_modules/prop-types/lib/ReactPropTypesSecret.js
  var require_ReactPropTypesSecret = __commonJS({
    "node_modules/prop-types/lib/ReactPropTypesSecret.js"(exports, module) {
      "use strict";
      var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
      module.exports = ReactPropTypesSecret;
    }
  });

  // node_modules/prop-types/factoryWithThrowingShims.js
  var require_factoryWithThrowingShims = __commonJS({
    "node_modules/prop-types/factoryWithThrowingShims.js"(exports, module) {
      "use strict";
      var ReactPropTypesSecret = require_ReactPropTypesSecret();
      function emptyFunction() {
      }
      function emptyFunctionWithReset() {
      }
      emptyFunctionWithReset.resetWarningCache = emptyFunction;
      module.exports = function() {
        function shim(props, propName, componentName, location, propFullName, secret) {
          if (secret === ReactPropTypesSecret) {
            return;
          }
          var err = new Error(
            "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
          );
          err.name = "Invariant Violation";
          throw err;
        }
        ;
        shim.isRequired = shim;
        function getShim() {
          return shim;
        }
        ;
        var ReactPropTypes = {
          array: shim,
          bigint: shim,
          bool: shim,
          func: shim,
          number: shim,
          object: shim,
          string: shim,
          symbol: shim,
          any: shim,
          arrayOf: getShim,
          element: shim,
          elementType: shim,
          instanceOf: getShim,
          node: shim,
          objectOf: getShim,
          oneOf: getShim,
          oneOfType: getShim,
          shape: getShim,
          exact: getShim,
          checkPropTypes: emptyFunctionWithReset,
          resetWarningCache: emptyFunction
        };
        ReactPropTypes.PropTypes = ReactPropTypes;
        return ReactPropTypes;
      };
    }
  });

  // node_modules/prop-types/index.js
  var require_prop_types = __commonJS({
    "node_modules/prop-types/index.js"(exports, module) {
      if (false) {
        ReactIs = null;
        throwOnDirectAccess = true;
        module.exports = null(ReactIs.isElement, throwOnDirectAccess);
      } else {
        module.exports = require_factoryWithThrowingShims()();
      }
      var ReactIs;
      var throwOnDirectAccess;
    }
  });

  // node_modules/react-dom/index.mjs
  var react_dom_exports = {};
  __export(react_dom_exports, {
    Children: () => O2,
    Component: () => d,
    Fragment: () => p,
    PureComponent: () => w3,
    StrictMode: () => vn,
    Suspense: () => D,
    SuspenseList: () => V2,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => rn,
    cloneElement: () => cn,
    createContext: () => B,
    createElement: () => h,
    createFactory: () => on,
    createPortal: () => j3,
    createRef: () => y,
    default: () => bn,
    findDOMNode: () => an,
    flushSync: () => hn,
    forwardRef: () => k3,
    hydrate: () => q3,
    isValidElement: () => ln,
    lazy: () => M2,
    memo: () => R,
    render: () => Y,
    startTransition: () => dn,
    unmountComponentAtNode: () => fn,
    unstable_batchedUpdates: () => sn,
    useCallback: () => T2,
    useContext: () => q2,
    useDebugValue: () => x2,
    useDeferredValue: () => pn,
    useEffect: () => h2,
    useErrorBoundary: () => P2,
    useId: () => V,
    useImperativeHandle: () => A2,
    useInsertionEffect: () => yn,
    useLayoutEffect: () => s2,
    useMemo: () => F,
    useReducer: () => y2,
    useRef: () => _2,
    useState: () => p2,
    useSyncExternalStore: () => _n,
    useTransition: () => mn,
    version: () => un
  });
  var init_react_dom = __esm({
    "node_modules/react-dom/index.mjs"() {
      init_compat_module();
      init_compat_module();
    }
  });

  // node_modules/clsx/dist/clsx.js
  var require_clsx = __commonJS({
    "node_modules/clsx/dist/clsx.js"(exports, module) {
      function e3(r4) {
        var o4, t3, f3 = "";
        if ("string" == typeof r4 || "number" == typeof r4)
          f3 += r4;
        else if ("object" == typeof r4)
          if (Array.isArray(r4))
            for (o4 = 0; o4 < r4.length; o4++)
              r4[o4] && (t3 = e3(r4[o4])) && (f3 && (f3 += " "), f3 += t3);
          else
            for (o4 in r4)
              r4[o4] && (f3 && (f3 += " "), f3 += o4);
        return f3;
      }
      function r3() {
        for (var r4, o4, t3 = 0, f3 = ""; t3 < arguments.length; )
          (r4 = arguments[t3++]) && (o4 = e3(r4)) && (f3 && (f3 += " "), f3 += o4);
        return f3;
      }
      module.exports = r3, module.exports.clsx = r3;
    }
  });

  // node_modules/react-draggable/build/cjs/utils/shims.js
  var require_shims = __commonJS({
    "node_modules/react-draggable/build/cjs/utils/shims.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.dontSetMe = dontSetMe;
      exports.findInArray = findInArray;
      exports.int = int;
      exports.isFunction = isFunction2;
      exports.isNum = isNum;
      function findInArray(array, callback) {
        for (var i3 = 0, length = array.length; i3 < length; i3++) {
          if (callback.apply(callback, [array[i3], i3, array]))
            return array[i3];
        }
      }
      function isFunction2(func) {
        return typeof func === "function" || Object.prototype.toString.call(func) === "[object Function]";
      }
      function isNum(num) {
        return typeof num === "number" && !isNaN(num);
      }
      function int(a3) {
        return parseInt(a3, 10);
      }
      function dontSetMe(props, propName, componentName) {
        if (props[propName]) {
          return new Error("Invalid prop ".concat(propName, " passed to ").concat(componentName, " - do not set this, set it on the child."));
        }
      }
    }
  });

  // node_modules/react-draggable/build/cjs/utils/getPrefix.js
  var require_getPrefix = __commonJS({
    "node_modules/react-draggable/build/cjs/utils/getPrefix.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.browserPrefixToKey = browserPrefixToKey;
      exports.browserPrefixToStyle = browserPrefixToStyle;
      exports.default = void 0;
      exports.getPrefix = getPrefix;
      var prefixes = ["Moz", "Webkit", "O", "ms"];
      function getPrefix() {
        var _window$document, _window$document$docu;
        var prop = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "transform";
        if (typeof window === "undefined")
          return "";
        var style = (_window$document = window.document) === null || _window$document === void 0 ? void 0 : (_window$document$docu = _window$document.documentElement) === null || _window$document$docu === void 0 ? void 0 : _window$document$docu.style;
        if (!style)
          return "";
        if (prop in style)
          return "";
        for (var i3 = 0; i3 < prefixes.length; i3++) {
          if (browserPrefixToKey(prop, prefixes[i3]) in style)
            return prefixes[i3];
        }
        return "";
      }
      function browserPrefixToKey(prop, prefix) {
        return prefix ? "".concat(prefix).concat(kebabToTitleCase(prop)) : prop;
      }
      function browserPrefixToStyle(prop, prefix) {
        return prefix ? "-".concat(prefix.toLowerCase(), "-").concat(prop) : prop;
      }
      function kebabToTitleCase(str) {
        var out = "";
        var shouldCapitalize = true;
        for (var i3 = 0; i3 < str.length; i3++) {
          if (shouldCapitalize) {
            out += str[i3].toUpperCase();
            shouldCapitalize = false;
          } else if (str[i3] === "-") {
            shouldCapitalize = true;
          } else {
            out += str[i3];
          }
        }
        return out;
      }
      var _default = getPrefix();
      exports.default = _default;
    }
  });

  // node_modules/react-draggable/build/cjs/utils/domFns.js
  var require_domFns = __commonJS({
    "node_modules/react-draggable/build/cjs/utils/domFns.js"(exports) {
      "use strict";
      function _typeof(obj) {
        "@babel/helpers - typeof";
        return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
          return typeof obj2;
        } : function(obj2) {
          return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        }, _typeof(obj);
      }
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.addClassName = addClassName;
      exports.addEvent = addEvent;
      exports.addUserSelectStyles = addUserSelectStyles;
      exports.createCSSTransform = createCSSTransform;
      exports.createSVGTransform = createSVGTransform;
      exports.getTouch = getTouch;
      exports.getTouchIdentifier = getTouchIdentifier;
      exports.getTranslation = getTranslation;
      exports.innerHeight = innerHeight;
      exports.innerWidth = innerWidth;
      exports.matchesSelector = matchesSelector;
      exports.matchesSelectorAndParentsTo = matchesSelectorAndParentsTo;
      exports.offsetXYFromParent = offsetXYFromParent;
      exports.outerHeight = outerHeight;
      exports.outerWidth = outerWidth;
      exports.removeClassName = removeClassName;
      exports.removeEvent = removeEvent;
      exports.removeUserSelectStyles = removeUserSelectStyles;
      var _shims = require_shims();
      var _getPrefix = _interopRequireWildcard(require_getPrefix());
      function _getRequireWildcardCache(nodeInterop) {
        if (typeof WeakMap !== "function")
          return null;
        var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
        var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
        return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
          return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
        })(nodeInterop);
      }
      function _interopRequireWildcard(obj, nodeInterop) {
        if (!nodeInterop && obj && obj.__esModule) {
          return obj;
        }
        if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
          return { default: obj };
        }
        var cache2 = _getRequireWildcardCache(nodeInterop);
        if (cache2 && cache2.has(obj)) {
          return cache2.get(obj);
        }
        var newObj = {};
        var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var key in obj) {
          if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
              Object.defineProperty(newObj, key, desc);
            } else {
              newObj[key] = obj[key];
            }
          }
        }
        newObj.default = obj;
        if (cache2) {
          cache2.set(obj, newObj);
        }
        return newObj;
      }
      function ownKeys(object, enumerableOnly) {
        var keys = Object.keys(object);
        if (Object.getOwnPropertySymbols) {
          var symbols = Object.getOwnPropertySymbols(object);
          enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
          })), keys.push.apply(keys, symbols);
        }
        return keys;
      }
      function _objectSpread(target) {
        for (var i3 = 1; i3 < arguments.length; i3++) {
          var source = null != arguments[i3] ? arguments[i3] : {};
          i3 % 2 ? ownKeys(Object(source), true).forEach(function(key) {
            _defineProperty(target, key, source[key]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
          });
        }
        return target;
      }
      function _defineProperty(obj, key, value) {
        if (key in obj) {
          Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
        } else {
          obj[key] = value;
        }
        return obj;
      }
      var matchesSelectorFunc = "";
      function matchesSelector(el, selector) {
        if (!matchesSelectorFunc) {
          matchesSelectorFunc = (0, _shims.findInArray)(["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"], function(method) {
            return (0, _shims.isFunction)(el[method]);
          });
        }
        if (!(0, _shims.isFunction)(el[matchesSelectorFunc]))
          return false;
        return el[matchesSelectorFunc](selector);
      }
      function matchesSelectorAndParentsTo(el, selector, baseNode) {
        var node = el;
        do {
          if (matchesSelector(node, selector))
            return true;
          if (node === baseNode)
            return false;
          node = node.parentNode;
        } while (node);
        return false;
      }
      function addEvent(el, event, handler, inputOptions) {
        if (!el)
          return;
        var options = _objectSpread({
          capture: true
        }, inputOptions);
        if (el.addEventListener) {
          el.addEventListener(event, handler, options);
        } else if (el.attachEvent) {
          el.attachEvent("on" + event, handler);
        } else {
          el["on" + event] = handler;
        }
      }
      function removeEvent(el, event, handler, inputOptions) {
        if (!el)
          return;
        var options = _objectSpread({
          capture: true
        }, inputOptions);
        if (el.removeEventListener) {
          el.removeEventListener(event, handler, options);
        } else if (el.detachEvent) {
          el.detachEvent("on" + event, handler);
        } else {
          el["on" + event] = null;
        }
      }
      function outerHeight(node) {
        var height = node.clientHeight;
        var computedStyle = node.ownerDocument.defaultView.getComputedStyle(node);
        height += (0, _shims.int)(computedStyle.borderTopWidth);
        height += (0, _shims.int)(computedStyle.borderBottomWidth);
        return height;
      }
      function outerWidth(node) {
        var width = node.clientWidth;
        var computedStyle = node.ownerDocument.defaultView.getComputedStyle(node);
        width += (0, _shims.int)(computedStyle.borderLeftWidth);
        width += (0, _shims.int)(computedStyle.borderRightWidth);
        return width;
      }
      function innerHeight(node) {
        var height = node.clientHeight;
        var computedStyle = node.ownerDocument.defaultView.getComputedStyle(node);
        height -= (0, _shims.int)(computedStyle.paddingTop);
        height -= (0, _shims.int)(computedStyle.paddingBottom);
        return height;
      }
      function innerWidth(node) {
        var width = node.clientWidth;
        var computedStyle = node.ownerDocument.defaultView.getComputedStyle(node);
        width -= (0, _shims.int)(computedStyle.paddingLeft);
        width -= (0, _shims.int)(computedStyle.paddingRight);
        return width;
      }
      function offsetXYFromParent(evt, offsetParent, scale) {
        var isBody = offsetParent === offsetParent.ownerDocument.body;
        var offsetParentRect = isBody ? {
          left: 0,
          top: 0
        } : offsetParent.getBoundingClientRect();
        var x4 = (evt.clientX + offsetParent.scrollLeft - offsetParentRect.left) / scale;
        var y3 = (evt.clientY + offsetParent.scrollTop - offsetParentRect.top) / scale;
        return {
          x: x4,
          y: y3
        };
      }
      function createCSSTransform(controlPos, positionOffset) {
        var translation = getTranslation(controlPos, positionOffset, "px");
        return _defineProperty({}, (0, _getPrefix.browserPrefixToKey)("transform", _getPrefix.default), translation);
      }
      function createSVGTransform(controlPos, positionOffset) {
        var translation = getTranslation(controlPos, positionOffset, "");
        return translation;
      }
      function getTranslation(_ref2, positionOffset, unitSuffix) {
        var x4 = _ref2.x, y3 = _ref2.y;
        var translation = "translate(".concat(x4).concat(unitSuffix, ",").concat(y3).concat(unitSuffix, ")");
        if (positionOffset) {
          var defaultX = "".concat(typeof positionOffset.x === "string" ? positionOffset.x : positionOffset.x + unitSuffix);
          var defaultY = "".concat(typeof positionOffset.y === "string" ? positionOffset.y : positionOffset.y + unitSuffix);
          translation = "translate(".concat(defaultX, ", ").concat(defaultY, ")") + translation;
        }
        return translation;
      }
      function getTouch(e3, identifier) {
        return e3.targetTouches && (0, _shims.findInArray)(e3.targetTouches, function(t3) {
          return identifier === t3.identifier;
        }) || e3.changedTouches && (0, _shims.findInArray)(e3.changedTouches, function(t3) {
          return identifier === t3.identifier;
        });
      }
      function getTouchIdentifier(e3) {
        if (e3.targetTouches && e3.targetTouches[0])
          return e3.targetTouches[0].identifier;
        if (e3.changedTouches && e3.changedTouches[0])
          return e3.changedTouches[0].identifier;
      }
      function addUserSelectStyles(doc) {
        if (!doc)
          return;
        var styleEl = doc.getElementById("react-draggable-style-el");
        if (!styleEl) {
          styleEl = doc.createElement("style");
          styleEl.type = "text/css";
          styleEl.id = "react-draggable-style-el";
          styleEl.innerHTML = ".react-draggable-transparent-selection *::-moz-selection {all: inherit;}\n";
          styleEl.innerHTML += ".react-draggable-transparent-selection *::selection {all: inherit;}\n";
          doc.getElementsByTagName("head")[0].appendChild(styleEl);
        }
        if (doc.body)
          addClassName(doc.body, "react-draggable-transparent-selection");
      }
      function removeUserSelectStyles(doc) {
        if (!doc)
          return;
        try {
          if (doc.body)
            removeClassName(doc.body, "react-draggable-transparent-selection");
          if (doc.selection) {
            doc.selection.empty();
          } else {
            var selection = (doc.defaultView || window).getSelection();
            if (selection && selection.type !== "Caret") {
              selection.removeAllRanges();
            }
          }
        } catch (e3) {
        }
      }
      function addClassName(el, className) {
        if (el.classList) {
          el.classList.add(className);
        } else {
          if (!el.className.match(new RegExp("(?:^|\\s)".concat(className, "(?!\\S)")))) {
            el.className += " ".concat(className);
          }
        }
      }
      function removeClassName(el, className) {
        if (el.classList) {
          el.classList.remove(className);
        } else {
          el.className = el.className.replace(new RegExp("(?:^|\\s)".concat(className, "(?!\\S)"), "g"), "");
        }
      }
    }
  });

  // node_modules/react-draggable/build/cjs/utils/positionFns.js
  var require_positionFns = __commonJS({
    "node_modules/react-draggable/build/cjs/utils/positionFns.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.canDragX = canDragX;
      exports.canDragY = canDragY;
      exports.createCoreData = createCoreData;
      exports.createDraggableData = createDraggableData;
      exports.getBoundPosition = getBoundPosition;
      exports.getControlPosition = getControlPosition;
      exports.snapToGrid = snapToGrid;
      var _shims = require_shims();
      var _domFns = require_domFns();
      function getBoundPosition(draggable, x4, y3) {
        if (!draggable.props.bounds)
          return [x4, y3];
        var bounds = draggable.props.bounds;
        bounds = typeof bounds === "string" ? bounds : cloneBounds(bounds);
        var node = findDOMNode(draggable);
        if (typeof bounds === "string") {
          var ownerDocument = node.ownerDocument;
          var ownerWindow = ownerDocument.defaultView;
          var boundNode;
          if (bounds === "parent") {
            boundNode = node.parentNode;
          } else {
            boundNode = ownerDocument.querySelector(bounds);
          }
          if (!(boundNode instanceof ownerWindow.HTMLElement)) {
            throw new Error('Bounds selector "' + bounds + '" could not find an element.');
          }
          var boundNodeEl = boundNode;
          var nodeStyle = ownerWindow.getComputedStyle(node);
          var boundNodeStyle = ownerWindow.getComputedStyle(boundNodeEl);
          bounds = {
            left: -node.offsetLeft + (0, _shims.int)(boundNodeStyle.paddingLeft) + (0, _shims.int)(nodeStyle.marginLeft),
            top: -node.offsetTop + (0, _shims.int)(boundNodeStyle.paddingTop) + (0, _shims.int)(nodeStyle.marginTop),
            right: (0, _domFns.innerWidth)(boundNodeEl) - (0, _domFns.outerWidth)(node) - node.offsetLeft + (0, _shims.int)(boundNodeStyle.paddingRight) - (0, _shims.int)(nodeStyle.marginRight),
            bottom: (0, _domFns.innerHeight)(boundNodeEl) - (0, _domFns.outerHeight)(node) - node.offsetTop + (0, _shims.int)(boundNodeStyle.paddingBottom) - (0, _shims.int)(nodeStyle.marginBottom)
          };
        }
        if ((0, _shims.isNum)(bounds.right))
          x4 = Math.min(x4, bounds.right);
        if ((0, _shims.isNum)(bounds.bottom))
          y3 = Math.min(y3, bounds.bottom);
        if ((0, _shims.isNum)(bounds.left))
          x4 = Math.max(x4, bounds.left);
        if ((0, _shims.isNum)(bounds.top))
          y3 = Math.max(y3, bounds.top);
        return [x4, y3];
      }
      function snapToGrid(grid, pendingX, pendingY) {
        var x4 = Math.round(pendingX / grid[0]) * grid[0];
        var y3 = Math.round(pendingY / grid[1]) * grid[1];
        return [x4, y3];
      }
      function canDragX(draggable) {
        return draggable.props.axis === "both" || draggable.props.axis === "x";
      }
      function canDragY(draggable) {
        return draggable.props.axis === "both" || draggable.props.axis === "y";
      }
      function getControlPosition(e3, touchIdentifier, draggableCore) {
        var touchObj = typeof touchIdentifier === "number" ? (0, _domFns.getTouch)(e3, touchIdentifier) : null;
        if (typeof touchIdentifier === "number" && !touchObj)
          return null;
        var node = findDOMNode(draggableCore);
        var offsetParent = draggableCore.props.offsetParent || node.offsetParent || node.ownerDocument.body;
        return (0, _domFns.offsetXYFromParent)(touchObj || e3, offsetParent, draggableCore.props.scale);
      }
      function createCoreData(draggable, x4, y3) {
        var state = draggable.state;
        var isStart = !(0, _shims.isNum)(state.lastX);
        var node = findDOMNode(draggable);
        if (isStart) {
          return {
            node,
            deltaX: 0,
            deltaY: 0,
            lastX: x4,
            lastY: y3,
            x: x4,
            y: y3
          };
        } else {
          return {
            node,
            deltaX: x4 - state.lastX,
            deltaY: y3 - state.lastY,
            lastX: state.lastX,
            lastY: state.lastY,
            x: x4,
            y: y3
          };
        }
      }
      function createDraggableData(draggable, coreData) {
        var scale = draggable.props.scale;
        return {
          node: coreData.node,
          x: draggable.state.x + coreData.deltaX / scale,
          y: draggable.state.y + coreData.deltaY / scale,
          deltaX: coreData.deltaX / scale,
          deltaY: coreData.deltaY / scale,
          lastX: draggable.state.x,
          lastY: draggable.state.y
        };
      }
      function cloneBounds(bounds) {
        return {
          left: bounds.left,
          top: bounds.top,
          right: bounds.right,
          bottom: bounds.bottom
        };
      }
      function findDOMNode(draggable) {
        var node = draggable.findDOMNode();
        if (!node) {
          throw new Error("<DraggableCore>: Unmounted during event!");
        }
        return node;
      }
    }
  });

  // node_modules/react-draggable/build/cjs/utils/log.js
  var require_log = __commonJS({
    "node_modules/react-draggable/build/cjs/utils/log.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.default = log;
      function log() {
        var _console;
        if (void 0)
          (_console = console).log.apply(_console, arguments);
      }
    }
  });

  // node_modules/react-draggable/build/cjs/DraggableCore.js
  var require_DraggableCore = __commonJS({
    "node_modules/react-draggable/build/cjs/DraggableCore.js"(exports) {
      "use strict";
      function _typeof(obj) {
        "@babel/helpers - typeof";
        return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
          return typeof obj2;
        } : function(obj2) {
          return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        }, _typeof(obj);
      }
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.default = void 0;
      var React = _interopRequireWildcard((init_react(), __toCommonJS(react_exports)));
      var _propTypes = _interopRequireDefault(require_prop_types());
      var _reactDom = _interopRequireDefault((init_react_dom(), __toCommonJS(react_dom_exports)));
      var _domFns = require_domFns();
      var _positionFns = require_positionFns();
      var _shims = require_shims();
      var _log = _interopRequireDefault(require_log());
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      function _getRequireWildcardCache(nodeInterop) {
        if (typeof WeakMap !== "function")
          return null;
        var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
        var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
        return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
          return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
        })(nodeInterop);
      }
      function _interopRequireWildcard(obj, nodeInterop) {
        if (!nodeInterop && obj && obj.__esModule) {
          return obj;
        }
        if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
          return { default: obj };
        }
        var cache2 = _getRequireWildcardCache(nodeInterop);
        if (cache2 && cache2.has(obj)) {
          return cache2.get(obj);
        }
        var newObj = {};
        var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var key in obj) {
          if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
              Object.defineProperty(newObj, key, desc);
            } else {
              newObj[key] = obj[key];
            }
          }
        }
        newObj.default = obj;
        if (cache2) {
          cache2.set(obj, newObj);
        }
        return newObj;
      }
      function _slicedToArray(arr, i3) {
        return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i3) || _unsupportedIterableToArray(arr, i3) || _nonIterableRest();
      }
      function _nonIterableRest() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      function _unsupportedIterableToArray(o4, minLen) {
        if (!o4)
          return;
        if (typeof o4 === "string")
          return _arrayLikeToArray(o4, minLen);
        var n2 = Object.prototype.toString.call(o4).slice(8, -1);
        if (n2 === "Object" && o4.constructor)
          n2 = o4.constructor.name;
        if (n2 === "Map" || n2 === "Set")
          return Array.from(o4);
        if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
          return _arrayLikeToArray(o4, minLen);
      }
      function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length)
          len = arr.length;
        for (var i3 = 0, arr2 = new Array(len); i3 < len; i3++) {
          arr2[i3] = arr[i3];
        }
        return arr2;
      }
      function _iterableToArrayLimit(arr, i3) {
        var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
        if (_i == null)
          return;
        var _arr = [];
        var _n2 = true;
        var _d = false;
        var _s, _e;
        try {
          for (_i = _i.call(arr); !(_n2 = (_s = _i.next()).done); _n2 = true) {
            _arr.push(_s.value);
            if (i3 && _arr.length === i3)
              break;
          }
        } catch (err) {
          _d = true;
          _e = err;
        } finally {
          try {
            if (!_n2 && _i["return"] != null)
              _i["return"]();
          } finally {
            if (_d)
              throw _e;
          }
        }
        return _arr;
      }
      function _arrayWithHoles(arr) {
        if (Array.isArray(arr))
          return arr;
      }
      function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
          throw new TypeError("Cannot call a class as a function");
        }
      }
      function _defineProperties(target, props) {
        for (var i3 = 0; i3 < props.length; i3++) {
          var descriptor = props[i3];
          descriptor.enumerable = descriptor.enumerable || false;
          descriptor.configurable = true;
          if ("value" in descriptor)
            descriptor.writable = true;
          Object.defineProperty(target, descriptor.key, descriptor);
        }
      }
      function _createClass(Constructor, protoProps, staticProps) {
        if (protoProps)
          _defineProperties(Constructor.prototype, protoProps);
        if (staticProps)
          _defineProperties(Constructor, staticProps);
        Object.defineProperty(Constructor, "prototype", { writable: false });
        return Constructor;
      }
      function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
          throw new TypeError("Super expression must either be null or a function");
        }
        subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } });
        Object.defineProperty(subClass, "prototype", { writable: false });
        if (superClass)
          _setPrototypeOf(subClass, superClass);
      }
      function _setPrototypeOf(o4, p3) {
        _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf2(o5, p4) {
          o5.__proto__ = p4;
          return o5;
        };
        return _setPrototypeOf(o4, p3);
      }
      function _createSuper(Derived) {
        var hasNativeReflectConstruct = _isNativeReflectConstruct();
        return function _createSuperInternal() {
          var Super = _getPrototypeOf(Derived), result;
          if (hasNativeReflectConstruct) {
            var NewTarget = _getPrototypeOf(this).constructor;
            result = Reflect.construct(Super, arguments, NewTarget);
          } else {
            result = Super.apply(this, arguments);
          }
          return _possibleConstructorReturn(this, result);
        };
      }
      function _possibleConstructorReturn(self2, call) {
        if (call && (_typeof(call) === "object" || typeof call === "function")) {
          return call;
        } else if (call !== void 0) {
          throw new TypeError("Derived constructors may only return object or undefined");
        }
        return _assertThisInitialized(self2);
      }
      function _assertThisInitialized(self2) {
        if (self2 === void 0) {
          throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }
        return self2;
      }
      function _isNativeReflectConstruct() {
        if (typeof Reflect === "undefined" || !Reflect.construct)
          return false;
        if (Reflect.construct.sham)
          return false;
        if (typeof Proxy === "function")
          return true;
        try {
          Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
          }));
          return true;
        } catch (e3) {
          return false;
        }
      }
      function _getPrototypeOf(o4) {
        _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf2(o5) {
          return o5.__proto__ || Object.getPrototypeOf(o5);
        };
        return _getPrototypeOf(o4);
      }
      function _defineProperty(obj, key, value) {
        if (key in obj) {
          Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
        } else {
          obj[key] = value;
        }
        return obj;
      }
      var eventsFor = {
        touch: {
          start: "touchstart",
          move: "touchmove",
          stop: "touchend"
        },
        mouse: {
          start: "mousedown",
          move: "mousemove",
          stop: "mouseup"
        }
      };
      var dragEventFor = eventsFor.mouse;
      var DraggableCore = /* @__PURE__ */ function(_React$Component) {
        _inherits(DraggableCore2, _React$Component);
        var _super = _createSuper(DraggableCore2);
        function DraggableCore2() {
          var _this;
          _classCallCheck(this, DraggableCore2);
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _super.call.apply(_super, [this].concat(args));
          _defineProperty(_assertThisInitialized(_this), "state", {
            dragging: false,
            // Used while dragging to determine deltas.
            lastX: NaN,
            lastY: NaN,
            touchIdentifier: null
          });
          _defineProperty(_assertThisInitialized(_this), "mounted", false);
          _defineProperty(_assertThisInitialized(_this), "handleDragStart", function(e3) {
            _this.props.onMouseDown(e3);
            if (!_this.props.allowAnyClick && typeof e3.button === "number" && e3.button !== 0)
              return false;
            var thisNode = _this.findDOMNode();
            if (!thisNode || !thisNode.ownerDocument || !thisNode.ownerDocument.body) {
              throw new Error("<DraggableCore> not mounted on DragStart!");
            }
            var ownerDocument = thisNode.ownerDocument;
            if (_this.props.disabled || !(e3.target instanceof ownerDocument.defaultView.Node) || _this.props.handle && !(0, _domFns.matchesSelectorAndParentsTo)(e3.target, _this.props.handle, thisNode) || _this.props.cancel && (0, _domFns.matchesSelectorAndParentsTo)(e3.target, _this.props.cancel, thisNode)) {
              return;
            }
            if (e3.type === "touchstart")
              e3.preventDefault();
            var touchIdentifier = (0, _domFns.getTouchIdentifier)(e3);
            _this.setState({
              touchIdentifier
            });
            var position = (0, _positionFns.getControlPosition)(e3, touchIdentifier, _assertThisInitialized(_this));
            if (position == null)
              return;
            var x4 = position.x, y3 = position.y;
            var coreEvent = (0, _positionFns.createCoreData)(_assertThisInitialized(_this), x4, y3);
            (0, _log.default)("DraggableCore: handleDragStart: %j", coreEvent);
            (0, _log.default)("calling", _this.props.onStart);
            var shouldUpdate = _this.props.onStart(e3, coreEvent);
            if (shouldUpdate === false || _this.mounted === false)
              return;
            if (_this.props.enableUserSelectHack)
              (0, _domFns.addUserSelectStyles)(ownerDocument);
            _this.setState({
              dragging: true,
              lastX: x4,
              lastY: y3
            });
            (0, _domFns.addEvent)(ownerDocument, dragEventFor.move, _this.handleDrag);
            (0, _domFns.addEvent)(ownerDocument, dragEventFor.stop, _this.handleDragStop);
          });
          _defineProperty(_assertThisInitialized(_this), "handleDrag", function(e3) {
            var position = (0, _positionFns.getControlPosition)(e3, _this.state.touchIdentifier, _assertThisInitialized(_this));
            if (position == null)
              return;
            var x4 = position.x, y3 = position.y;
            if (Array.isArray(_this.props.grid)) {
              var deltaX = x4 - _this.state.lastX, deltaY = y3 - _this.state.lastY;
              var _snapToGrid = (0, _positionFns.snapToGrid)(_this.props.grid, deltaX, deltaY);
              var _snapToGrid2 = _slicedToArray(_snapToGrid, 2);
              deltaX = _snapToGrid2[0];
              deltaY = _snapToGrid2[1];
              if (!deltaX && !deltaY)
                return;
              x4 = _this.state.lastX + deltaX, y3 = _this.state.lastY + deltaY;
            }
            var coreEvent = (0, _positionFns.createCoreData)(_assertThisInitialized(_this), x4, y3);
            (0, _log.default)("DraggableCore: handleDrag: %j", coreEvent);
            var shouldUpdate = _this.props.onDrag(e3, coreEvent);
            if (shouldUpdate === false || _this.mounted === false) {
              try {
                _this.handleDragStop(new MouseEvent("mouseup"));
              } catch (err) {
                var event = document.createEvent("MouseEvents");
                event.initMouseEvent("mouseup", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                _this.handleDragStop(event);
              }
              return;
            }
            _this.setState({
              lastX: x4,
              lastY: y3
            });
          });
          _defineProperty(_assertThisInitialized(_this), "handleDragStop", function(e3) {
            if (!_this.state.dragging)
              return;
            var position = (0, _positionFns.getControlPosition)(e3, _this.state.touchIdentifier, _assertThisInitialized(_this));
            if (position == null)
              return;
            var x4 = position.x, y3 = position.y;
            if (Array.isArray(_this.props.grid)) {
              var deltaX = x4 - _this.state.lastX || 0;
              var deltaY = y3 - _this.state.lastY || 0;
              var _snapToGrid3 = (0, _positionFns.snapToGrid)(_this.props.grid, deltaX, deltaY);
              var _snapToGrid4 = _slicedToArray(_snapToGrid3, 2);
              deltaX = _snapToGrid4[0];
              deltaY = _snapToGrid4[1];
              x4 = _this.state.lastX + deltaX, y3 = _this.state.lastY + deltaY;
            }
            var coreEvent = (0, _positionFns.createCoreData)(_assertThisInitialized(_this), x4, y3);
            var shouldContinue = _this.props.onStop(e3, coreEvent);
            if (shouldContinue === false || _this.mounted === false)
              return false;
            var thisNode = _this.findDOMNode();
            if (thisNode) {
              if (_this.props.enableUserSelectHack)
                (0, _domFns.removeUserSelectStyles)(thisNode.ownerDocument);
            }
            (0, _log.default)("DraggableCore: handleDragStop: %j", coreEvent);
            _this.setState({
              dragging: false,
              lastX: NaN,
              lastY: NaN
            });
            if (thisNode) {
              (0, _log.default)("DraggableCore: Removing handlers");
              (0, _domFns.removeEvent)(thisNode.ownerDocument, dragEventFor.move, _this.handleDrag);
              (0, _domFns.removeEvent)(thisNode.ownerDocument, dragEventFor.stop, _this.handleDragStop);
            }
          });
          _defineProperty(_assertThisInitialized(_this), "onMouseDown", function(e3) {
            dragEventFor = eventsFor.mouse;
            return _this.handleDragStart(e3);
          });
          _defineProperty(_assertThisInitialized(_this), "onMouseUp", function(e3) {
            dragEventFor = eventsFor.mouse;
            return _this.handleDragStop(e3);
          });
          _defineProperty(_assertThisInitialized(_this), "onTouchStart", function(e3) {
            dragEventFor = eventsFor.touch;
            return _this.handleDragStart(e3);
          });
          _defineProperty(_assertThisInitialized(_this), "onTouchEnd", function(e3) {
            dragEventFor = eventsFor.touch;
            return _this.handleDragStop(e3);
          });
          return _this;
        }
        _createClass(DraggableCore2, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            this.mounted = true;
            var thisNode = this.findDOMNode();
            if (thisNode) {
              (0, _domFns.addEvent)(thisNode, eventsFor.touch.start, this.onTouchStart, {
                passive: false
              });
            }
          }
        }, {
          key: "componentWillUnmount",
          value: function componentWillUnmount() {
            this.mounted = false;
            var thisNode = this.findDOMNode();
            if (thisNode) {
              var ownerDocument = thisNode.ownerDocument;
              (0, _domFns.removeEvent)(ownerDocument, eventsFor.mouse.move, this.handleDrag);
              (0, _domFns.removeEvent)(ownerDocument, eventsFor.touch.move, this.handleDrag);
              (0, _domFns.removeEvent)(ownerDocument, eventsFor.mouse.stop, this.handleDragStop);
              (0, _domFns.removeEvent)(ownerDocument, eventsFor.touch.stop, this.handleDragStop);
              (0, _domFns.removeEvent)(thisNode, eventsFor.touch.start, this.onTouchStart, {
                passive: false
              });
              if (this.props.enableUserSelectHack)
                (0, _domFns.removeUserSelectStyles)(ownerDocument);
            }
          }
          // React Strict Mode compatibility: if `nodeRef` is passed, we will use it instead of trying to find
          // the underlying DOM node ourselves. See the README for more information.
        }, {
          key: "findDOMNode",
          value: function findDOMNode() {
            var _this$props, _this$props2, _this$props2$nodeRef;
            return (_this$props = this.props) !== null && _this$props !== void 0 && _this$props.nodeRef ? (_this$props2 = this.props) === null || _this$props2 === void 0 ? void 0 : (_this$props2$nodeRef = _this$props2.nodeRef) === null || _this$props2$nodeRef === void 0 ? void 0 : _this$props2$nodeRef.current : _reactDom.default.findDOMNode(this);
          }
        }, {
          key: "render",
          value: function render() {
            return /* @__PURE__ */ React.cloneElement(React.Children.only(this.props.children), {
              // Note: mouseMove handler is attached to document so it will still function
              // when the user drags quickly and leaves the bounds of the element.
              onMouseDown: this.onMouseDown,
              onMouseUp: this.onMouseUp,
              // onTouchStart is added on `componentDidMount` so they can be added with
              // {passive: false}, which allows it to cancel. See
              // https://developers.google.com/web/updates/2017/01/scrolling-intervention
              onTouchEnd: this.onTouchEnd
            });
          }
        }]);
        return DraggableCore2;
      }(React.Component);
      exports.default = DraggableCore;
      _defineProperty(DraggableCore, "displayName", "DraggableCore");
      _defineProperty(DraggableCore, "propTypes", {
        /**
         * `allowAnyClick` allows dragging using any mouse button.
         * By default, we only accept the left button.
         *
         * Defaults to `false`.
         */
        allowAnyClick: _propTypes.default.bool,
        /**
         * `disabled`, if true, stops the <Draggable> from dragging. All handlers,
         * with the exception of `onMouseDown`, will not fire.
         */
        disabled: _propTypes.default.bool,
        /**
         * By default, we add 'user-select:none' attributes to the document body
         * to prevent ugly text selection during drag. If this is causing problems
         * for your app, set this to `false`.
         */
        enableUserSelectHack: _propTypes.default.bool,
        /**
         * `offsetParent`, if set, uses the passed DOM node to compute drag offsets
         * instead of using the parent node.
         */
        offsetParent: function offsetParent(props, propName) {
          if (props[propName] && props[propName].nodeType !== 1) {
            throw new Error("Draggable's offsetParent must be a DOM Node.");
          }
        },
        /**
         * `grid` specifies the x and y that dragging should snap to.
         */
        grid: _propTypes.default.arrayOf(_propTypes.default.number),
        /**
         * `handle` specifies a selector to be used as the handle that initiates drag.
         *
         * Example:
         *
         * ```jsx
         *   let App = React.createClass({
         *       render: function () {
         *         return (
         *            <Draggable handle=".handle">
         *              <div>
         *                  <div className="handle">Click me to drag</div>
         *                  <div>This is some other content</div>
         *              </div>
         *           </Draggable>
         *         );
         *       }
         *   });
         * ```
         */
        handle: _propTypes.default.string,
        /**
         * `cancel` specifies a selector to be used to prevent drag initialization.
         *
         * Example:
         *
         * ```jsx
         *   let App = React.createClass({
         *       render: function () {
         *           return(
         *               <Draggable cancel=".cancel">
         *                   <div>
         *                     <div className="cancel">You can't drag from here</div>
         *                     <div>Dragging here works fine</div>
         *                   </div>
         *               </Draggable>
         *           );
         *       }
         *   });
         * ```
         */
        cancel: _propTypes.default.string,
        /* If running in React Strict mode, ReactDOM.findDOMNode() is deprecated.
         * Unfortunately, in order for <Draggable> to work properly, we need raw access
         * to the underlying DOM node. If you want to avoid the warning, pass a `nodeRef`
         * as in this example:
         *
         * function MyComponent() {
         *   const nodeRef = React.useRef(null);
         *   return (
         *     <Draggable nodeRef={nodeRef}>
         *       <div ref={nodeRef}>Example Target</div>
         *     </Draggable>
         *   );
         * }
         *
         * This can be used for arbitrarily nested components, so long as the ref ends up
         * pointing to the actual child DOM node and not a custom component.
         */
        nodeRef: _propTypes.default.object,
        /**
         * Called when dragging starts.
         * If this function returns the boolean false, dragging will be canceled.
         */
        onStart: _propTypes.default.func,
        /**
         * Called while dragging.
         * If this function returns the boolean false, dragging will be canceled.
         */
        onDrag: _propTypes.default.func,
        /**
         * Called when dragging stops.
         * If this function returns the boolean false, the drag will remain active.
         */
        onStop: _propTypes.default.func,
        /**
         * A workaround option which can be passed if onMouseDown needs to be accessed,
         * since it'll always be blocked (as there is internal use of onMouseDown)
         */
        onMouseDown: _propTypes.default.func,
        /**
         * `scale`, if set, applies scaling while dragging an element
         */
        scale: _propTypes.default.number,
        /**
         * These properties should be defined on the child, not here.
         */
        className: _shims.dontSetMe,
        style: _shims.dontSetMe,
        transform: _shims.dontSetMe
      });
      _defineProperty(DraggableCore, "defaultProps", {
        allowAnyClick: false,
        // by default only accept left click
        disabled: false,
        enableUserSelectHack: true,
        onStart: function onStart() {
        },
        onDrag: function onDrag() {
        },
        onStop: function onStop() {
        },
        onMouseDown: function onMouseDown() {
        },
        scale: 1
      });
    }
  });

  // node_modules/react-draggable/build/cjs/Draggable.js
  var require_Draggable = __commonJS({
    "node_modules/react-draggable/build/cjs/Draggable.js"(exports) {
      "use strict";
      function _typeof(obj) {
        "@babel/helpers - typeof";
        return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
          return typeof obj2;
        } : function(obj2) {
          return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        }, _typeof(obj);
      }
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      Object.defineProperty(exports, "DraggableCore", {
        enumerable: true,
        get: function get() {
          return _DraggableCore.default;
        }
      });
      exports.default = void 0;
      var React = _interopRequireWildcard((init_react(), __toCommonJS(react_exports)));
      var _propTypes = _interopRequireDefault(require_prop_types());
      var _reactDom = _interopRequireDefault((init_react_dom(), __toCommonJS(react_dom_exports)));
      var _clsx2 = _interopRequireDefault(require_clsx());
      var _domFns = require_domFns();
      var _positionFns = require_positionFns();
      var _shims = require_shims();
      var _DraggableCore = _interopRequireDefault(require_DraggableCore());
      var _log = _interopRequireDefault(require_log());
      var _excluded = ["axis", "bounds", "children", "defaultPosition", "defaultClassName", "defaultClassNameDragging", "defaultClassNameDragged", "position", "positionOffset", "scale"];
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      function _getRequireWildcardCache(nodeInterop) {
        if (typeof WeakMap !== "function")
          return null;
        var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
        var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
        return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
          return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
        })(nodeInterop);
      }
      function _interopRequireWildcard(obj, nodeInterop) {
        if (!nodeInterop && obj && obj.__esModule) {
          return obj;
        }
        if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
          return { default: obj };
        }
        var cache2 = _getRequireWildcardCache(nodeInterop);
        if (cache2 && cache2.has(obj)) {
          return cache2.get(obj);
        }
        var newObj = {};
        var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var key in obj) {
          if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
              Object.defineProperty(newObj, key, desc);
            } else {
              newObj[key] = obj[key];
            }
          }
        }
        newObj.default = obj;
        if (cache2) {
          cache2.set(obj, newObj);
        }
        return newObj;
      }
      function _extends() {
        _extends = Object.assign || function(target) {
          for (var i3 = 1; i3 < arguments.length; i3++) {
            var source = arguments[i3];
            for (var key in source) {
              if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
              }
            }
          }
          return target;
        };
        return _extends.apply(this, arguments);
      }
      function _objectWithoutProperties(source, excluded) {
        if (source == null)
          return {};
        var target = _objectWithoutPropertiesLoose(source, excluded);
        var key, i3;
        if (Object.getOwnPropertySymbols) {
          var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
          for (i3 = 0; i3 < sourceSymbolKeys.length; i3++) {
            key = sourceSymbolKeys[i3];
            if (excluded.indexOf(key) >= 0)
              continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key))
              continue;
            target[key] = source[key];
          }
        }
        return target;
      }
      function _objectWithoutPropertiesLoose(source, excluded) {
        if (source == null)
          return {};
        var target = {};
        var sourceKeys = Object.keys(source);
        var key, i3;
        for (i3 = 0; i3 < sourceKeys.length; i3++) {
          key = sourceKeys[i3];
          if (excluded.indexOf(key) >= 0)
            continue;
          target[key] = source[key];
        }
        return target;
      }
      function ownKeys(object, enumerableOnly) {
        var keys = Object.keys(object);
        if (Object.getOwnPropertySymbols) {
          var symbols = Object.getOwnPropertySymbols(object);
          enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
          })), keys.push.apply(keys, symbols);
        }
        return keys;
      }
      function _objectSpread(target) {
        for (var i3 = 1; i3 < arguments.length; i3++) {
          var source = null != arguments[i3] ? arguments[i3] : {};
          i3 % 2 ? ownKeys(Object(source), true).forEach(function(key) {
            _defineProperty(target, key, source[key]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
          });
        }
        return target;
      }
      function _slicedToArray(arr, i3) {
        return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i3) || _unsupportedIterableToArray(arr, i3) || _nonIterableRest();
      }
      function _nonIterableRest() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      function _unsupportedIterableToArray(o4, minLen) {
        if (!o4)
          return;
        if (typeof o4 === "string")
          return _arrayLikeToArray(o4, minLen);
        var n2 = Object.prototype.toString.call(o4).slice(8, -1);
        if (n2 === "Object" && o4.constructor)
          n2 = o4.constructor.name;
        if (n2 === "Map" || n2 === "Set")
          return Array.from(o4);
        if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
          return _arrayLikeToArray(o4, minLen);
      }
      function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length)
          len = arr.length;
        for (var i3 = 0, arr2 = new Array(len); i3 < len; i3++) {
          arr2[i3] = arr[i3];
        }
        return arr2;
      }
      function _iterableToArrayLimit(arr, i3) {
        var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
        if (_i == null)
          return;
        var _arr = [];
        var _n2 = true;
        var _d = false;
        var _s, _e;
        try {
          for (_i = _i.call(arr); !(_n2 = (_s = _i.next()).done); _n2 = true) {
            _arr.push(_s.value);
            if (i3 && _arr.length === i3)
              break;
          }
        } catch (err) {
          _d = true;
          _e = err;
        } finally {
          try {
            if (!_n2 && _i["return"] != null)
              _i["return"]();
          } finally {
            if (_d)
              throw _e;
          }
        }
        return _arr;
      }
      function _arrayWithHoles(arr) {
        if (Array.isArray(arr))
          return arr;
      }
      function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
          throw new TypeError("Cannot call a class as a function");
        }
      }
      function _defineProperties(target, props) {
        for (var i3 = 0; i3 < props.length; i3++) {
          var descriptor = props[i3];
          descriptor.enumerable = descriptor.enumerable || false;
          descriptor.configurable = true;
          if ("value" in descriptor)
            descriptor.writable = true;
          Object.defineProperty(target, descriptor.key, descriptor);
        }
      }
      function _createClass(Constructor, protoProps, staticProps) {
        if (protoProps)
          _defineProperties(Constructor.prototype, protoProps);
        if (staticProps)
          _defineProperties(Constructor, staticProps);
        Object.defineProperty(Constructor, "prototype", { writable: false });
        return Constructor;
      }
      function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
          throw new TypeError("Super expression must either be null or a function");
        }
        subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } });
        Object.defineProperty(subClass, "prototype", { writable: false });
        if (superClass)
          _setPrototypeOf(subClass, superClass);
      }
      function _setPrototypeOf(o4, p3) {
        _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf2(o5, p4) {
          o5.__proto__ = p4;
          return o5;
        };
        return _setPrototypeOf(o4, p3);
      }
      function _createSuper(Derived) {
        var hasNativeReflectConstruct = _isNativeReflectConstruct();
        return function _createSuperInternal() {
          var Super = _getPrototypeOf(Derived), result;
          if (hasNativeReflectConstruct) {
            var NewTarget = _getPrototypeOf(this).constructor;
            result = Reflect.construct(Super, arguments, NewTarget);
          } else {
            result = Super.apply(this, arguments);
          }
          return _possibleConstructorReturn(this, result);
        };
      }
      function _possibleConstructorReturn(self2, call) {
        if (call && (_typeof(call) === "object" || typeof call === "function")) {
          return call;
        } else if (call !== void 0) {
          throw new TypeError("Derived constructors may only return object or undefined");
        }
        return _assertThisInitialized(self2);
      }
      function _assertThisInitialized(self2) {
        if (self2 === void 0) {
          throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }
        return self2;
      }
      function _isNativeReflectConstruct() {
        if (typeof Reflect === "undefined" || !Reflect.construct)
          return false;
        if (Reflect.construct.sham)
          return false;
        if (typeof Proxy === "function")
          return true;
        try {
          Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
          }));
          return true;
        } catch (e3) {
          return false;
        }
      }
      function _getPrototypeOf(o4) {
        _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf2(o5) {
          return o5.__proto__ || Object.getPrototypeOf(o5);
        };
        return _getPrototypeOf(o4);
      }
      function _defineProperty(obj, key, value) {
        if (key in obj) {
          Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
        } else {
          obj[key] = value;
        }
        return obj;
      }
      var Draggable2 = /* @__PURE__ */ function(_React$Component) {
        _inherits(Draggable3, _React$Component);
        var _super = _createSuper(Draggable3);
        function Draggable3(props) {
          var _this;
          _classCallCheck(this, Draggable3);
          _this = _super.call(this, props);
          _defineProperty(_assertThisInitialized(_this), "onDragStart", function(e3, coreData) {
            (0, _log.default)("Draggable: onDragStart: %j", coreData);
            var shouldStart = _this.props.onStart(e3, (0, _positionFns.createDraggableData)(_assertThisInitialized(_this), coreData));
            if (shouldStart === false)
              return false;
            _this.setState({
              dragging: true,
              dragged: true
            });
          });
          _defineProperty(_assertThisInitialized(_this), "onDrag", function(e3, coreData) {
            if (!_this.state.dragging)
              return false;
            (0, _log.default)("Draggable: onDrag: %j", coreData);
            var uiData = (0, _positionFns.createDraggableData)(_assertThisInitialized(_this), coreData);
            var newState = {
              x: uiData.x,
              y: uiData.y
            };
            if (_this.props.bounds) {
              var x4 = newState.x, y3 = newState.y;
              newState.x += _this.state.slackX;
              newState.y += _this.state.slackY;
              var _getBoundPosition = (0, _positionFns.getBoundPosition)(_assertThisInitialized(_this), newState.x, newState.y), _getBoundPosition2 = _slicedToArray(_getBoundPosition, 2), newStateX = _getBoundPosition2[0], newStateY = _getBoundPosition2[1];
              newState.x = newStateX;
              newState.y = newStateY;
              newState.slackX = _this.state.slackX + (x4 - newState.x);
              newState.slackY = _this.state.slackY + (y3 - newState.y);
              uiData.x = newState.x;
              uiData.y = newState.y;
              uiData.deltaX = newState.x - _this.state.x;
              uiData.deltaY = newState.y - _this.state.y;
            }
            var shouldUpdate = _this.props.onDrag(e3, uiData);
            if (shouldUpdate === false)
              return false;
            _this.setState(newState);
          });
          _defineProperty(_assertThisInitialized(_this), "onDragStop", function(e3, coreData) {
            if (!_this.state.dragging)
              return false;
            var shouldContinue = _this.props.onStop(e3, (0, _positionFns.createDraggableData)(_assertThisInitialized(_this), coreData));
            if (shouldContinue === false)
              return false;
            (0, _log.default)("Draggable: onDragStop: %j", coreData);
            var newState = {
              dragging: false,
              slackX: 0,
              slackY: 0
            };
            var controlled = Boolean(_this.props.position);
            if (controlled) {
              var _this$props$position = _this.props.position, x4 = _this$props$position.x, y3 = _this$props$position.y;
              newState.x = x4;
              newState.y = y3;
            }
            _this.setState(newState);
          });
          _this.state = {
            // Whether or not we are currently dragging.
            dragging: false,
            // Whether or not we have been dragged before.
            dragged: false,
            // Current transform x and y.
            x: props.position ? props.position.x : props.defaultPosition.x,
            y: props.position ? props.position.y : props.defaultPosition.y,
            prevPropsPosition: _objectSpread({}, props.position),
            // Used for compensating for out-of-bounds drags
            slackX: 0,
            slackY: 0,
            // Can only determine if SVG after mounting
            isElementSVG: false
          };
          if (props.position && !(props.onDrag || props.onStop)) {
            console.warn("A `position` was applied to this <Draggable>, without drag handlers. This will make this component effectively undraggable. Please attach `onDrag` or `onStop` handlers so you can adjust the `position` of this element.");
          }
          return _this;
        }
        _createClass(Draggable3, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            if (typeof window.SVGElement !== "undefined" && this.findDOMNode() instanceof window.SVGElement) {
              this.setState({
                isElementSVG: true
              });
            }
          }
        }, {
          key: "componentWillUnmount",
          value: function componentWillUnmount() {
            this.setState({
              dragging: false
            });
          }
          // React Strict Mode compatibility: if `nodeRef` is passed, we will use it instead of trying to find
          // the underlying DOM node ourselves. See the README for more information.
        }, {
          key: "findDOMNode",
          value: function findDOMNode() {
            var _this$props$nodeRef$c, _this$props, _this$props$nodeRef;
            return (_this$props$nodeRef$c = (_this$props = this.props) === null || _this$props === void 0 ? void 0 : (_this$props$nodeRef = _this$props.nodeRef) === null || _this$props$nodeRef === void 0 ? void 0 : _this$props$nodeRef.current) !== null && _this$props$nodeRef$c !== void 0 ? _this$props$nodeRef$c : _reactDom.default.findDOMNode(this);
          }
        }, {
          key: "render",
          value: function render() {
            var _clsx;
            var _this$props2 = this.props, axis = _this$props2.axis, bounds = _this$props2.bounds, children = _this$props2.children, defaultPosition = _this$props2.defaultPosition, defaultClassName = _this$props2.defaultClassName, defaultClassNameDragging = _this$props2.defaultClassNameDragging, defaultClassNameDragged = _this$props2.defaultClassNameDragged, position = _this$props2.position, positionOffset = _this$props2.positionOffset, scale = _this$props2.scale, draggableCoreProps = _objectWithoutProperties(_this$props2, _excluded);
            var style = {};
            var svgTransform = null;
            var controlled = Boolean(position);
            var draggable = !controlled || this.state.dragging;
            var validPosition = position || defaultPosition;
            var transformOpts = {
              // Set left if horizontal drag is enabled
              x: (0, _positionFns.canDragX)(this) && draggable ? this.state.x : validPosition.x,
              // Set top if vertical drag is enabled
              y: (0, _positionFns.canDragY)(this) && draggable ? this.state.y : validPosition.y
            };
            if (this.state.isElementSVG) {
              svgTransform = (0, _domFns.createSVGTransform)(transformOpts, positionOffset);
            } else {
              style = (0, _domFns.createCSSTransform)(transformOpts, positionOffset);
            }
            var className = (0, _clsx2.default)(children.props.className || "", defaultClassName, (_clsx = {}, _defineProperty(_clsx, defaultClassNameDragging, this.state.dragging), _defineProperty(_clsx, defaultClassNameDragged, this.state.dragged), _clsx));
            return /* @__PURE__ */ React.createElement(_DraggableCore.default, _extends({}, draggableCoreProps, {
              onStart: this.onDragStart,
              onDrag: this.onDrag,
              onStop: this.onDragStop
            }), /* @__PURE__ */ React.cloneElement(React.Children.only(children), {
              className,
              style: _objectSpread(_objectSpread({}, children.props.style), style),
              transform: svgTransform
            }));
          }
        }], [{
          key: "getDerivedStateFromProps",
          value: (
            // React 16.3+
            // Arity (props, state)
            function getDerivedStateFromProps(_ref, _ref2) {
              var position = _ref.position;
              var prevPropsPosition = _ref2.prevPropsPosition;
              if (position && (!prevPropsPosition || position.x !== prevPropsPosition.x || position.y !== prevPropsPosition.y)) {
                (0, _log.default)("Draggable: getDerivedStateFromProps %j", {
                  position,
                  prevPropsPosition
                });
                return {
                  x: position.x,
                  y: position.y,
                  prevPropsPosition: _objectSpread({}, position)
                };
              }
              return null;
            }
          )
        }]);
        return Draggable3;
      }(React.Component);
      exports.default = Draggable2;
      _defineProperty(Draggable2, "displayName", "Draggable");
      _defineProperty(Draggable2, "propTypes", _objectSpread(_objectSpread({}, _DraggableCore.default.propTypes), {}, {
        /**
         * `axis` determines which axis the draggable can move.
         *
         *  Note that all callbacks will still return data as normal. This only
         *  controls flushing to the DOM.
         *
         * 'both' allows movement horizontally and vertically.
         * 'x' limits movement to horizontal axis.
         * 'y' limits movement to vertical axis.
         * 'none' limits all movement.
         *
         * Defaults to 'both'.
         */
        axis: _propTypes.default.oneOf(["both", "x", "y", "none"]),
        /**
         * `bounds` determines the range of movement available to the element.
         * Available values are:
         *
         * 'parent' restricts movement within the Draggable's parent node.
         *
         * Alternatively, pass an object with the following properties, all of which are optional:
         *
         * {left: LEFT_BOUND, right: RIGHT_BOUND, bottom: BOTTOM_BOUND, top: TOP_BOUND}
         *
         * All values are in px.
         *
         * Example:
         *
         * ```jsx
         *   let App = React.createClass({
         *       render: function () {
         *         return (
         *            <Draggable bounds={{right: 300, bottom: 300}}>
         *              <div>Content</div>
         *           </Draggable>
         *         );
         *       }
         *   });
         * ```
         */
        bounds: _propTypes.default.oneOfType([_propTypes.default.shape({
          left: _propTypes.default.number,
          right: _propTypes.default.number,
          top: _propTypes.default.number,
          bottom: _propTypes.default.number
        }), _propTypes.default.string, _propTypes.default.oneOf([false])]),
        defaultClassName: _propTypes.default.string,
        defaultClassNameDragging: _propTypes.default.string,
        defaultClassNameDragged: _propTypes.default.string,
        /**
         * `defaultPosition` specifies the x and y that the dragged item should start at
         *
         * Example:
         *
         * ```jsx
         *      let App = React.createClass({
         *          render: function () {
         *              return (
         *                  <Draggable defaultPosition={{x: 25, y: 25}}>
         *                      <div>I start with transformX: 25px and transformY: 25px;</div>
         *                  </Draggable>
         *              );
         *          }
         *      });
         * ```
         */
        defaultPosition: _propTypes.default.shape({
          x: _propTypes.default.number,
          y: _propTypes.default.number
        }),
        positionOffset: _propTypes.default.shape({
          x: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string]),
          y: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string])
        }),
        /**
         * `position`, if present, defines the current position of the element.
         *
         *  This is similar to how form elements in React work - if no `position` is supplied, the component
         *  is uncontrolled.
         *
         * Example:
         *
         * ```jsx
         *      let App = React.createClass({
         *          render: function () {
         *              return (
         *                  <Draggable position={{x: 25, y: 25}}>
         *                      <div>I start with transformX: 25px and transformY: 25px;</div>
         *                  </Draggable>
         *              );
         *          }
         *      });
         * ```
         */
        position: _propTypes.default.shape({
          x: _propTypes.default.number,
          y: _propTypes.default.number
        }),
        /**
         * These properties should be defined on the child, not here.
         */
        className: _shims.dontSetMe,
        style: _shims.dontSetMe,
        transform: _shims.dontSetMe
      }));
      _defineProperty(Draggable2, "defaultProps", _objectSpread(_objectSpread({}, _DraggableCore.default.defaultProps), {}, {
        axis: "both",
        bounds: false,
        defaultClassName: "react-draggable",
        defaultClassNameDragging: "react-draggable-dragging",
        defaultClassNameDragged: "react-draggable-dragged",
        defaultPosition: {
          x: 0,
          y: 0
        },
        scale: 1
      }));
    }
  });

  // node_modules/react-draggable/build/cjs/cjs.js
  var require_cjs = __commonJS({
    "node_modules/react-draggable/build/cjs/cjs.js"(exports, module) {
      "use strict";
      var _require = require_Draggable();
      var Draggable2 = _require.default;
      var DraggableCore = _require.DraggableCore;
      module.exports = Draggable2;
      module.exports.default = Draggable2;
      module.exports.DraggableCore = DraggableCore;
    }
  });

  // src/popup/index.tsx
  init_preact_module();

  // node_modules/@primer/octicons-react/dist/index.esm.js
  init_react();
  var sizeMap = {
    small: 16,
    medium: 32,
    large: 64
  };
  function createIconComponent(name, defaultClassName, getSVGData) {
    var svgDataByHeight = getSVGData();
    var heights = Object.keys(svgDataByHeight);
    function Icon(_ref) {
      var ariaLabel = _ref["aria-label"], tabIndex = _ref.tabIndex, className = _ref.className, _ref$fill = _ref.fill, fill = _ref$fill === void 0 ? "currentColor" : _ref$fill, size = _ref.size, verticalAlign = _ref.verticalAlign;
      var height = sizeMap[size] || size;
      var naturalHeight = closestNaturalHeight(heights, height);
      var naturalWidth = svgDataByHeight[naturalHeight].width;
      var width = height * (naturalWidth / naturalHeight);
      var path = svgDataByHeight[naturalHeight].path;
      return /* @__PURE__ */ bn.createElement("svg", {
        "aria-hidden": ariaLabel ? "false" : "true",
        tabIndex,
        focusable: tabIndex >= 0 ? "true" : "false",
        "aria-label": ariaLabel,
        role: "img",
        className,
        viewBox: "0 0 ".concat(naturalWidth, " ").concat(naturalHeight),
        width,
        height,
        fill,
        style: {
          display: "inline-block",
          userSelect: "none",
          verticalAlign,
          overflow: "visible"
        }
      }, path);
    }
    Icon.displayName = name;
    Icon.defaultProps = {
      className: defaultClassName,
      size: 16,
      verticalAlign: "text-bottom"
    };
    return Icon;
  }
  function closestNaturalHeight(naturalHeights, height) {
    return naturalHeights.map(function(naturalHeight) {
      return parseInt(naturalHeight, 10);
    }).reduce(function(acc, naturalHeight) {
      return naturalHeight <= height ? naturalHeight : acc;
    }, naturalHeights[0]);
  }
  var GearIcon = /* @__PURE__ */ createIconComponent("GearIcon", "octicon octicon-gear", function() {
    return {
      "16": {
        "width": 16,
        "path": /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M7.429 1.525a6.593 6.593 0 011.142 0c.036.003.108.036.137.146l.289 1.105c.147.56.55.967.997 1.189.174.086.341.183.501.29.417.278.97.423 1.53.27l1.102-.303c.11-.03.175.016.195.046.219.31.41.641.573.989.014.031.022.11-.059.19l-.815.806c-.411.406-.562.957-.53 1.456a4.588 4.588 0 010 .582c-.032.499.119 1.05.53 1.456l.815.806c.08.08.073.159.059.19a6.494 6.494 0 01-.573.99c-.02.029-.086.074-.195.045l-1.103-.303c-.559-.153-1.112-.008-1.529.27-.16.107-.327.204-.5.29-.449.222-.851.628-.998 1.189l-.289 1.105c-.029.11-.101.143-.137.146a6.613 6.613 0 01-1.142 0c-.036-.003-.108-.037-.137-.146l-.289-1.105c-.147-.56-.55-.967-.997-1.189a4.502 4.502 0 01-.501-.29c-.417-.278-.97-.423-1.53-.27l-1.102.303c-.11.03-.175-.016-.195-.046a6.492 6.492 0 01-.573-.989c-.014-.031-.022-.11.059-.19l.815-.806c.411-.406.562-.957.53-1.456a4.587 4.587 0 010-.582c.032-.499-.119-1.05-.53-1.456l-.815-.806c-.08-.08-.073-.159-.059-.19a6.44 6.44 0 01.573-.99c.02-.029.086-.075.195-.045l1.103.303c.559.153 1.112.008 1.529-.27.16-.107.327-.204.5-.29.449-.222.851-.628.998-1.189l.289-1.105c.029-.11.101-.143.137-.146zM8 0c-.236 0-.47.01-.701.03-.743.065-1.29.615-1.458 1.261l-.29 1.106c-.017.066-.078.158-.211.224a5.994 5.994 0 00-.668.386c-.123.082-.233.09-.3.071L3.27 2.776c-.644-.177-1.392.02-1.82.63a7.977 7.977 0 00-.704 1.217c-.315.675-.111 1.422.363 1.891l.815.806c.05.048.098.147.088.294a6.084 6.084 0 000 .772c.01.147-.038.246-.088.294l-.815.806c-.474.469-.678 1.216-.363 1.891.2.428.436.835.704 1.218.428.609 1.176.806 1.82.63l1.103-.303c.066-.019.176-.011.299.071.213.143.436.272.668.386.133.066.194.158.212.224l.289 1.106c.169.646.715 1.196 1.458 1.26a8.094 8.094 0 001.402 0c.743-.064 1.29-.614 1.458-1.26l.29-1.106c.017-.066.078-.158.211-.224a5.98 5.98 0 00.668-.386c.123-.082.233-.09.3-.071l1.102.302c.644.177 1.392-.02 1.82-.63.268-.382.505-.789.704-1.217.315-.675.111-1.422-.364-1.891l-.814-.806c-.05-.048-.098-.147-.088-.294a6.1 6.1 0 000-.772c-.01-.147.039-.246.088-.294l.814-.806c.475-.469.679-1.216.364-1.891a7.992 7.992 0 00-.704-1.218c-.428-.609-1.176-.806-1.82-.63l-1.103.303c-.066.019-.176.011-.299-.071a5.991 5.991 0 00-.668-.386c-.133-.066-.194-.158-.212-.224L10.16 1.29C9.99.645 9.444.095 8.701.031A8.094 8.094 0 008 0zm1.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM11 8a3 3 0 11-6 0 3 3 0 016 0z"
        })
      },
      "24": {
        "width": 24,
        "path": /* @__PURE__ */ bn.createElement(bn.Fragment, null, /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M16 12a4 4 0 11-8 0 4 4 0 018 0zm-1.5 0a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"
        }), /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M12 1c-.268 0-.534.01-.797.028-.763.055-1.345.617-1.512 1.304l-.352 1.45c-.02.078-.09.172-.225.22a8.45 8.45 0 00-.728.303c-.13.06-.246.044-.315.002l-1.274-.776c-.604-.368-1.412-.354-1.99.147-.403.348-.78.726-1.129 1.128-.5.579-.515 1.387-.147 1.99l.776 1.275c.042.069.059.185-.002.315-.112.237-.213.48-.302.728-.05.135-.143.206-.221.225l-1.45.352c-.687.167-1.249.749-1.304 1.512a11.149 11.149 0 000 1.594c.055.763.617 1.345 1.304 1.512l1.45.352c.078.02.172.09.22.225.09.248.191.491.303.729.06.129.044.245.002.314l-.776 1.274c-.368.604-.354 1.412.147 1.99.348.403.726.78 1.128 1.129.579.5 1.387.515 1.99.147l1.275-.776c.069-.042.185-.059.315.002.237.112.48.213.728.302.135.05.206.143.225.221l.352 1.45c.167.687.749 1.249 1.512 1.303a11.125 11.125 0 001.594 0c.763-.054 1.345-.616 1.512-1.303l.352-1.45c.02-.078.09-.172.225-.22.248-.09.491-.191.729-.303.129-.06.245-.044.314-.002l1.274.776c.604.368 1.412.354 1.99-.147.403-.348.78-.726 1.129-1.128.5-.579.515-1.387.147-1.99l-.776-1.275c-.042-.069-.059-.185.002-.315.112-.237.213-.48.302-.728.05-.135.143-.206.221-.225l1.45-.352c.687-.167 1.249-.749 1.303-1.512a11.125 11.125 0 000-1.594c-.054-.763-.616-1.345-1.303-1.512l-1.45-.352c-.078-.02-.172-.09-.22-.225a8.469 8.469 0 00-.303-.728c-.06-.13-.044-.246-.002-.315l.776-1.274c.368-.604.354-1.412-.147-1.99-.348-.403-.726-.78-1.128-1.129-.579-.5-1.387-.515-1.99-.147l-1.275.776c-.069.042-.185.059-.315-.002a8.465 8.465 0 00-.728-.302c-.135-.05-.206-.143-.225-.221l-.352-1.45c-.167-.687-.749-1.249-1.512-1.304A11.149 11.149 0 0012 1zm-.69 1.525a9.648 9.648 0 011.38 0c.055.004.135.05.162.16l.351 1.45c.153.628.626 1.08 1.173 1.278.205.074.405.157.6.249a1.832 1.832 0 001.733-.074l1.275-.776c.097-.06.186-.036.228 0 .348.302.674.628.976.976.036.042.06.13 0 .228l-.776 1.274a1.832 1.832 0 00-.074 1.734c.092.195.175.395.248.6.198.547.652 1.02 1.278 1.172l1.45.353c.111.026.157.106.161.161a9.653 9.653 0 010 1.38c-.004.055-.05.135-.16.162l-1.45.351a1.833 1.833 0 00-1.278 1.173 6.926 6.926 0 01-.25.6 1.832 1.832 0 00.075 1.733l.776 1.275c.06.097.036.186 0 .228a9.555 9.555 0 01-.976.976c-.042.036-.13.06-.228 0l-1.275-.776a1.832 1.832 0 00-1.733-.074 6.926 6.926 0 01-.6.248 1.833 1.833 0 00-1.172 1.278l-.353 1.45c-.026.111-.106.157-.161.161a9.653 9.653 0 01-1.38 0c-.055-.004-.135-.05-.162-.16l-.351-1.45a1.833 1.833 0 00-1.173-1.278 6.928 6.928 0 01-.6-.25 1.832 1.832 0 00-1.734.075l-1.274.776c-.097.06-.186.036-.228 0a9.56 9.56 0 01-.976-.976c-.036-.042-.06-.13 0-.228l.776-1.275a1.832 1.832 0 00.074-1.733 6.948 6.948 0 01-.249-.6 1.833 1.833 0 00-1.277-1.172l-1.45-.353c-.111-.026-.157-.106-.161-.161a9.648 9.648 0 010-1.38c.004-.055.05-.135.16-.162l1.45-.351a1.833 1.833 0 001.278-1.173 6.95 6.95 0 01.249-.6 1.832 1.832 0 00-.074-1.734l-.776-1.274c-.06-.097-.036-.186 0-.228.302-.348.628-.674.976-.976.042-.036.13-.06.228 0l1.274.776a1.832 1.832 0 001.734.074 6.95 6.95 0 01.6-.249 1.833 1.833 0 001.172-1.277l.353-1.45c.026-.111.106-.157.161-.161z"
        }))
      }
    };
  });
  var GlobeIcon = /* @__PURE__ */ createIconComponent("GlobeIcon", "octicon octicon-globe", function() {
    return {
      "16": {
        "width": 16,
        "path": /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M1.543 7.25h2.733c.144-2.074.866-3.756 1.58-4.948.12-.197.237-.381.353-.552a6.506 6.506 0 00-4.666 5.5zm2.733 1.5H1.543a6.506 6.506 0 004.666 5.5 11.13 11.13 0 01-.352-.552c-.715-1.192-1.437-2.874-1.581-4.948zm1.504 0h4.44a9.637 9.637 0 01-1.363 4.177c-.306.51-.612.919-.857 1.215a9.978 9.978 0 01-.857-1.215A9.637 9.637 0 015.78 8.75zm4.44-1.5H5.78a9.637 9.637 0 011.363-4.177c.306-.51.612-.919.857-1.215.245.296.55.705.857 1.215A9.638 9.638 0 0110.22 7.25zm1.504 1.5c-.144 2.074-.866 3.756-1.58 4.948-.12.197-.237.381-.353.552a6.506 6.506 0 004.666-5.5h-2.733zm2.733-1.5h-2.733c-.144-2.074-.866-3.756-1.58-4.948a11.738 11.738 0 00-.353-.552 6.506 6.506 0 014.666 5.5zM8 0a8 8 0 100 16A8 8 0 008 0z"
        })
      },
      "24": {
        "width": 24,
        "path": /* @__PURE__ */ bn.createElement("path", {
          fillRule: "evenodd",
          d: "M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zM2.513 11.5h4.745c.1-3.037 1.1-5.49 2.093-7.204.39-.672.78-1.233 1.119-1.673C6.11 3.329 2.746 7 2.513 11.5zm4.77 1.5H2.552a9.505 9.505 0 007.918 8.377 15.698 15.698 0 01-1.119-1.673C8.413 18.085 7.47 15.807 7.283 13zm1.504 0h6.426c-.183 2.48-1.02 4.5-1.862 5.951-.476.82-.95 1.455-1.304 1.88L12 20.89l-.047-.057a13.888 13.888 0 01-1.304-1.88C9.807 17.5 8.969 15.478 8.787 13zm6.454-1.5H8.759c.1-2.708.992-4.904 1.89-6.451.476-.82.95-1.455 1.304-1.88L12 3.11l.047.057c.353.426.828 1.06 1.304 1.88.898 1.548 1.79 3.744 1.89 6.452zm1.476 1.5c-.186 2.807-1.13 5.085-2.068 6.704-.39.672-.78 1.233-1.118 1.673A9.505 9.505 0 0021.447 13h-4.731zm4.77-1.5h-4.745c-.1-3.037-1.1-5.49-2.093-7.204-.39-.672-.78-1.233-1.119-1.673 4.36.706 7.724 4.377 7.957 8.877z"
        })
      }
    };
  });

  // src/popup/Popup.tsx
  init_react();

  // node_modules/swr/core/dist/index.mjs
  init_react();
  var import_shim = __toESM(require_shim(), 1);

  // node_modules/swr/_internal/dist/index.mjs
  init_react();
  var SWRGlobalState = /* @__PURE__ */ new WeakMap();
  var EMPTY_CACHE = {};
  var noop = () => {
  };
  var UNDEFINED = (
    /*#__NOINLINE__*/
    noop()
  );
  var OBJECT = Object;
  var isUndefined = (v3) => v3 === UNDEFINED;
  var isFunction = (v3) => typeof v3 == "function";
  var mergeObjects = (a3, b3) => ({
    ...a3,
    ...b3
  });
  var STR_UNDEFINED = "undefined";
  var isWindowDefined = typeof window != STR_UNDEFINED;
  var isDocumentDefined = typeof document != STR_UNDEFINED;
  var hasRequestAnimationFrame = () => isWindowDefined && typeof window["requestAnimationFrame"] != STR_UNDEFINED;
  var createCacheHelper = (cache2, key) => {
    const state = SWRGlobalState.get(cache2);
    return [
      // Getter
      () => cache2.get(key) || EMPTY_CACHE,
      // Setter
      (info) => {
        const prev = cache2.get(key);
        state[5](key, mergeObjects(prev, info), prev || EMPTY_CACHE);
      },
      // Subscriber
      state[6]
    ];
  };
  var table = /* @__PURE__ */ new WeakMap();
  var counter = 0;
  var stableHash = (arg) => {
    const type = typeof arg;
    const constructor = arg && arg.constructor;
    const isDate = constructor == Date;
    let result;
    let index;
    if (OBJECT(arg) === arg && !isDate && constructor != RegExp) {
      result = table.get(arg);
      if (result)
        return result;
      result = ++counter + "~";
      table.set(arg, result);
      if (constructor == Array) {
        result = "@";
        for (index = 0; index < arg.length; index++) {
          result += stableHash(arg[index]) + ",";
        }
        table.set(arg, result);
      }
      if (constructor == OBJECT) {
        result = "#";
        const keys = OBJECT.keys(arg).sort();
        while (!isUndefined(index = keys.pop())) {
          if (!isUndefined(arg[index])) {
            result += index + ":" + stableHash(arg[index]) + ",";
          }
        }
        table.set(arg, result);
      }
    } else {
      result = isDate ? arg.toJSON() : type == "symbol" ? arg.toString() : type == "string" ? JSON.stringify(arg) : "" + arg;
    }
    return result;
  };
  var online = true;
  var isOnline = () => online;
  var [onWindowEvent, offWindowEvent] = isWindowDefined && window.addEventListener ? [
    window.addEventListener.bind(window),
    window.removeEventListener.bind(window)
  ] : [
    noop,
    noop
  ];
  var isVisible = () => {
    const visibilityState = isDocumentDefined && document.visibilityState;
    return isUndefined(visibilityState) || visibilityState !== "hidden";
  };
  var initFocus = (callback) => {
    if (isDocumentDefined) {
      document.addEventListener("visibilitychange", callback);
    }
    onWindowEvent("focus", callback);
    return () => {
      if (isDocumentDefined) {
        document.removeEventListener("visibilitychange", callback);
      }
      offWindowEvent("focus", callback);
    };
  };
  var initReconnect = (callback) => {
    const onOnline = () => {
      online = true;
      callback();
    };
    const onOffline = () => {
      online = false;
    };
    onWindowEvent("online", onOnline);
    onWindowEvent("offline", onOffline);
    return () => {
      offWindowEvent("online", onOnline);
      offWindowEvent("offline", onOffline);
    };
  };
  var preset = {
    isOnline,
    isVisible
  };
  var defaultConfigOptions = {
    initFocus,
    initReconnect
  };
  var IS_REACT_LEGACY = !bn.useId;
  var IS_SERVER = !isWindowDefined || "Deno" in window;
  var rAF = (f3) => hasRequestAnimationFrame() ? window["requestAnimationFrame"](f3) : setTimeout(f3, 1);
  var useIsomorphicLayoutEffect = IS_SERVER ? h2 : s2;
  var navigatorConnection = typeof navigator !== "undefined" && navigator.connection;
  var slowConnection = !IS_SERVER && navigatorConnection && ([
    "slow-2g",
    "2g"
  ].includes(navigatorConnection.effectiveType) || navigatorConnection.saveData);
  var serialize = (key) => {
    if (isFunction(key)) {
      try {
        key = key();
      } catch (err) {
        key = "";
      }
    }
    const args = key;
    key = typeof key == "string" ? key : (Array.isArray(key) ? key.length : key) ? stableHash(key) : "";
    return [
      key,
      args
    ];
  };
  var __timestamp = 0;
  var getTimestamp = () => ++__timestamp;
  var FOCUS_EVENT = 0;
  var RECONNECT_EVENT = 1;
  var MUTATE_EVENT = 2;
  var constants = {
    __proto__: null,
    FOCUS_EVENT,
    RECONNECT_EVENT,
    MUTATE_EVENT
  };
  async function internalMutate(...args) {
    const [cache2, _key, _data, _opts] = args;
    const options = mergeObjects({
      populateCache: true,
      throwOnError: true
    }, typeof _opts === "boolean" ? {
      revalidate: _opts
    } : _opts || {});
    let populateCache = options.populateCache;
    const rollbackOnErrorOption = options.rollbackOnError;
    let optimisticData = options.optimisticData;
    const revalidate = options.revalidate !== false;
    const rollbackOnError = (error) => {
      return typeof rollbackOnErrorOption === "function" ? rollbackOnErrorOption(error) : rollbackOnErrorOption !== false;
    };
    const throwOnError = options.throwOnError;
    if (isFunction(_key)) {
      const keyFilter = _key;
      const matchedKeys = [];
      const it = cache2.keys();
      for (let keyIt = it.next(); !keyIt.done; keyIt = it.next()) {
        const key = keyIt.value;
        if (
          // Skip the special useSWRInfinite keys.
          !key.startsWith("$inf$") && keyFilter(cache2.get(key)._k)
        ) {
          matchedKeys.push(key);
        }
      }
      return Promise.all(matchedKeys.map(mutateByKey));
    }
    return mutateByKey(_key);
    async function mutateByKey(_k) {
      const [key] = serialize(_k);
      if (!key)
        return;
      const [get, set] = createCacheHelper(cache2, key);
      const [EVENT_REVALIDATORS, MUTATION, FETCH] = SWRGlobalState.get(cache2);
      const revalidators = EVENT_REVALIDATORS[key];
      const startRevalidate = () => {
        if (revalidate) {
          delete FETCH[key];
          if (revalidators && revalidators[0]) {
            return revalidators[0](MUTATE_EVENT).then(() => get().data);
          }
        }
        return get().data;
      };
      if (args.length < 3) {
        return startRevalidate();
      }
      let data = _data;
      let error;
      const beforeMutationTs = getTimestamp();
      MUTATION[key] = [
        beforeMutationTs,
        0
      ];
      const hasOptimisticData = !isUndefined(optimisticData);
      const state = get();
      const displayedData = state.data;
      const currentData = state._c;
      const committedData = isUndefined(currentData) ? displayedData : currentData;
      if (hasOptimisticData) {
        optimisticData = isFunction(optimisticData) ? optimisticData(committedData) : optimisticData;
        set({
          data: optimisticData,
          _c: committedData
        });
      }
      if (isFunction(data)) {
        try {
          data = data(committedData);
        } catch (err) {
          error = err;
        }
      }
      if (data && isFunction(data.then)) {
        data = await data.catch((err) => {
          error = err;
        });
        if (beforeMutationTs !== MUTATION[key][0]) {
          if (error)
            throw error;
          return data;
        } else if (error && hasOptimisticData && rollbackOnError(error)) {
          populateCache = true;
          data = committedData;
          set({
            data,
            _c: UNDEFINED
          });
        }
      }
      if (populateCache) {
        if (!error) {
          if (isFunction(populateCache)) {
            data = populateCache(data, committedData);
          }
          set({
            data,
            _c: UNDEFINED
          });
        }
      }
      MUTATION[key][1] = getTimestamp();
      const res = await startRevalidate();
      set({
        _c: UNDEFINED
      });
      if (error) {
        if (throwOnError)
          throw error;
        return;
      }
      return populateCache ? res : data;
    }
  }
  var revalidateAllKeys = (revalidators, type) => {
    for (const key in revalidators) {
      if (revalidators[key][0])
        revalidators[key][0](type);
    }
  };
  var initCache = (provider, options) => {
    if (!SWRGlobalState.has(provider)) {
      const opts = mergeObjects(defaultConfigOptions, options);
      const EVENT_REVALIDATORS = {};
      const mutate2 = internalMutate.bind(UNDEFINED, provider);
      let unmount = noop;
      const subscriptions = {};
      const subscribe = (key, callback) => {
        const subs = subscriptions[key] || [];
        subscriptions[key] = subs;
        subs.push(callback);
        return () => subs.splice(subs.indexOf(callback), 1);
      };
      const setter = (key, value, prev) => {
        provider.set(key, value);
        const subs = subscriptions[key];
        if (subs) {
          for (let i3 = subs.length; i3--; ) {
            subs[i3](prev, value);
          }
        }
      };
      const initProvider = () => {
        if (!SWRGlobalState.has(provider)) {
          SWRGlobalState.set(provider, [
            EVENT_REVALIDATORS,
            {},
            {},
            {},
            mutate2,
            setter,
            subscribe
          ]);
          if (!IS_SERVER) {
            const releaseFocus = opts.initFocus(setTimeout.bind(UNDEFINED, revalidateAllKeys.bind(UNDEFINED, EVENT_REVALIDATORS, FOCUS_EVENT)));
            const releaseReconnect = opts.initReconnect(setTimeout.bind(UNDEFINED, revalidateAllKeys.bind(UNDEFINED, EVENT_REVALIDATORS, RECONNECT_EVENT)));
            unmount = () => {
              releaseFocus && releaseFocus();
              releaseReconnect && releaseReconnect();
              SWRGlobalState.delete(provider);
            };
          }
        }
      };
      initProvider();
      return [
        provider,
        mutate2,
        initProvider,
        unmount
      ];
    }
    return [
      provider,
      SWRGlobalState.get(provider)[4]
    ];
  };
  var onErrorRetry = (_4, __, config, revalidate, opts) => {
    const maxRetryCount = config.errorRetryCount;
    const currentRetryCount = opts.retryCount;
    const timeout = ~~((Math.random() + 0.5) * (1 << (currentRetryCount < 8 ? currentRetryCount : 8))) * config.errorRetryInterval;
    if (!isUndefined(maxRetryCount) && currentRetryCount > maxRetryCount) {
      return;
    }
    setTimeout(revalidate, timeout, opts);
  };
  var compare = (currentData, newData) => stableHash(currentData) == stableHash(newData);
  var [cache, mutate] = initCache(/* @__PURE__ */ new Map());
  var defaultConfig = mergeObjects(
    {
      // events
      onLoadingSlow: noop,
      onSuccess: noop,
      onError: noop,
      onErrorRetry,
      onDiscarded: noop,
      // switches
      revalidateOnFocus: true,
      revalidateOnReconnect: true,
      revalidateIfStale: true,
      shouldRetryOnError: true,
      // timeouts
      errorRetryInterval: slowConnection ? 1e4 : 5e3,
      focusThrottleInterval: 5 * 1e3,
      dedupingInterval: 2 * 1e3,
      loadingTimeout: slowConnection ? 5e3 : 3e3,
      // providers
      compare,
      isPaused: () => false,
      cache,
      mutate,
      fallback: {}
    },
    // use web preset by default
    preset
  );
  var mergeConfigs = (a3, b3) => {
    const v3 = mergeObjects(a3, b3);
    if (b3) {
      const { use: u1, fallback: f1 } = a3;
      const { use: u22, fallback: f22 } = b3;
      if (u1 && u22) {
        v3.use = u1.concat(u22);
      }
      if (f1 && f22) {
        v3.fallback = mergeObjects(f1, f22);
      }
    }
    return v3;
  };
  var SWRConfigContext = B({});
  var SWRConfig = (props) => {
    const { value } = props;
    const parentConfig = q2(SWRConfigContext);
    const isFunctionalConfig = isFunction(value);
    const config = F(() => isFunctionalConfig ? value(parentConfig) : value, [
      isFunctionalConfig,
      parentConfig,
      value
    ]);
    const extendedConfig = F(() => isFunctionalConfig ? config : mergeConfigs(parentConfig, config), [
      isFunctionalConfig,
      parentConfig,
      config
    ]);
    const provider = config && config.provider;
    const [cacheContext] = p2(() => provider ? initCache(provider(extendedConfig.cache || cache), config) : UNDEFINED);
    if (cacheContext) {
      extendedConfig.cache = cacheContext[0];
      extendedConfig.mutate = cacheContext[1];
    }
    useIsomorphicLayoutEffect(() => {
      if (cacheContext) {
        cacheContext[2] && cacheContext[2]();
        return cacheContext[3];
      }
    }, []);
    return h(SWRConfigContext.Provider, mergeObjects(props, {
      value: extendedConfig
    }));
  };
  var enableDevtools = isWindowDefined && window.__SWR_DEVTOOLS_USE__;
  var use = enableDevtools ? window.__SWR_DEVTOOLS_USE__ : [];
  var setupDevTools = () => {
    if (enableDevtools) {
      window.__SWR_DEVTOOLS_REACT__ = bn;
    }
  };
  var normalize = (args) => {
    return isFunction(args[1]) ? [
      args[0],
      args[1],
      args[2] || {}
    ] : [
      args[0],
      null,
      (args[1] === null ? args[2] : args[1]) || {}
    ];
  };
  var useSWRConfig = () => {
    return mergeObjects(defaultConfig, q2(SWRConfigContext));
  };
  var middleware = (useSWRNext) => (key_, fetcher_, config) => {
    const fetcher = fetcher_ && ((...args) => {
      const key = serialize(key_)[0];
      const [, , , PRELOAD] = SWRGlobalState.get(cache);
      const req = PRELOAD[key];
      if (req) {
        delete PRELOAD[key];
        return req;
      }
      return fetcher_(...args);
    });
    return useSWRNext(key_, fetcher, config);
  };
  var BUILT_IN_MIDDLEWARE = use.concat(middleware);
  var withArgs = (hook) => {
    return function useSWRArgs(...args) {
      const fallbackConfig = useSWRConfig();
      const [key, fn2, _config] = normalize(args);
      const config = mergeConfigs(fallbackConfig, _config);
      let next = hook;
      const { use: use2 } = config;
      const middleware2 = (use2 || []).concat(BUILT_IN_MIDDLEWARE);
      for (let i3 = middleware2.length; i3--; ) {
        next = middleware2[i3](next);
      }
      return next(key, fn2 || config.fetcher || null, config);
    };
  };
  var subscribeCallback = (key, callbacks, callback) => {
    const keyedRevalidators = callbacks[key] || (callbacks[key] = []);
    keyedRevalidators.push(callback);
    return () => {
      const index = keyedRevalidators.indexOf(callback);
      if (index >= 0) {
        keyedRevalidators[index] = keyedRevalidators[keyedRevalidators.length - 1];
        keyedRevalidators.pop();
      }
    };
  };
  setupDevTools();

  // node_modules/swr/core/dist/index.mjs
  var WITH_DEDUPE = {
    dedupe: true
  };
  var useSWRHandler = (_key, fetcher, config) => {
    const { cache: cache2, compare: compare2, suspense, fallbackData, revalidateOnMount, refreshInterval, refreshWhenHidden, refreshWhenOffline, keepPreviousData } = config;
    const [EVENT_REVALIDATORS, MUTATION, FETCH] = SWRGlobalState.get(cache2);
    const [key, fnArg] = serialize(_key);
    const initialMountedRef = _2(false);
    const unmountedRef = _2(false);
    const keyRef = _2(key);
    const fetcherRef = _2(fetcher);
    const configRef = _2(config);
    const getConfig = () => configRef.current;
    const isActive = () => getConfig().isVisible() && getConfig().isOnline();
    const [getCache, setCache, subscribeCache] = createCacheHelper(cache2, key);
    const stateDependencies = _2({}).current;
    const fallback = isUndefined(fallbackData) ? config.fallback[key] : fallbackData;
    const isEqual = (prev, current) => {
      let equal = true;
      for (const _4 in stateDependencies) {
        const t3 = _4;
        if (!compare2(current[t3], prev[t3])) {
          if (t3 === "data" && isUndefined(prev[t3])) {
            if (!compare2(current[t3], returnedData)) {
              equal = false;
            }
          } else {
            equal = false;
          }
        }
      }
      return equal;
    };
    const getSnapshot = F(() => {
      const shouldStartRequest = (() => {
        if (!key)
          return false;
        if (!fetcher)
          return false;
        if (!isUndefined(revalidateOnMount))
          return revalidateOnMount;
        if (getConfig().isPaused())
          return false;
        if (suspense)
          return false;
        return true;
      })();
      const getSelectedCache = () => {
        const state = getCache();
        const snapshot = mergeObjects(state);
        delete snapshot._k;
        if (!shouldStartRequest) {
          return snapshot;
        }
        return {
          isValidating: true,
          isLoading: true,
          ...snapshot
        };
      };
      let memorizedSnapshot = getSelectedCache();
      return () => {
        const snapshot = getSelectedCache();
        return isEqual(snapshot, memorizedSnapshot) ? memorizedSnapshot : memorizedSnapshot = snapshot;
      };
    }, [
      cache2,
      key
    ]);
    const cached = (0, import_shim.useSyncExternalStore)(T2(
      (callback) => subscribeCache(key, (prev, current) => {
        if (!isEqual(prev, current))
          callback();
      }),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
        cache2,
        key
      ]
    ), getSnapshot, getSnapshot);
    const isInitialMount = !initialMountedRef.current;
    const cachedData = cached.data;
    const data = isUndefined(cachedData) ? fallback : cachedData;
    const error = cached.error;
    const laggyDataRef = _2(data);
    const returnedData = keepPreviousData ? isUndefined(cachedData) ? laggyDataRef.current : cachedData : data;
    const shouldDoInitialRevalidation = (() => {
      if (isInitialMount && !isUndefined(revalidateOnMount))
        return revalidateOnMount;
      if (getConfig().isPaused())
        return false;
      if (suspense)
        return isUndefined(data) ? false : config.revalidateIfStale;
      return isUndefined(data) || config.revalidateIfStale;
    })();
    const defaultValidatingState = !!(key && fetcher && isInitialMount && shouldDoInitialRevalidation);
    const isValidating = isUndefined(cached.isValidating) ? defaultValidatingState : cached.isValidating;
    const isLoading = isUndefined(cached.isLoading) ? defaultValidatingState : cached.isLoading;
    const revalidate = T2(
      async (revalidateOpts) => {
        const currentFetcher = fetcherRef.current;
        if (!key || !currentFetcher || unmountedRef.current || getConfig().isPaused()) {
          return false;
        }
        let newData;
        let startAt;
        let loading = true;
        const opts = revalidateOpts || {};
        const shouldStartNewRequest = !FETCH[key] || !opts.dedupe;
        const callbackSafeguard = () => {
          if (IS_REACT_LEGACY) {
            return !unmountedRef.current && key === keyRef.current && initialMountedRef.current;
          }
          return key === keyRef.current;
        };
        const finalState = {
          isValidating: false,
          isLoading: false
        };
        const finishRequestAndUpdateState = () => {
          setCache(finalState);
        };
        const cleanupState = () => {
          const requestInfo = FETCH[key];
          if (requestInfo && requestInfo[1] === startAt) {
            delete FETCH[key];
          }
        };
        const initialState = {
          isValidating: true
        };
        if (isUndefined(getCache().data)) {
          initialState.isLoading = true;
        }
        try {
          if (shouldStartNewRequest) {
            setCache(initialState);
            if (config.loadingTimeout && isUndefined(getCache().data)) {
              setTimeout(() => {
                if (loading && callbackSafeguard()) {
                  getConfig().onLoadingSlow(key, config);
                }
              }, config.loadingTimeout);
            }
            FETCH[key] = [
              currentFetcher(fnArg),
              getTimestamp()
            ];
          }
          [newData, startAt] = FETCH[key];
          newData = await newData;
          if (shouldStartNewRequest) {
            setTimeout(cleanupState, config.dedupingInterval);
          }
          if (!FETCH[key] || FETCH[key][1] !== startAt) {
            if (shouldStartNewRequest) {
              if (callbackSafeguard()) {
                getConfig().onDiscarded(key);
              }
            }
            return false;
          }
          finalState.error = UNDEFINED;
          const mutationInfo = MUTATION[key];
          if (!isUndefined(mutationInfo) && // case 1
          (startAt <= mutationInfo[0] || // case 2
          startAt <= mutationInfo[1] || // case 3
          mutationInfo[1] === 0)) {
            finishRequestAndUpdateState();
            if (shouldStartNewRequest) {
              if (callbackSafeguard()) {
                getConfig().onDiscarded(key);
              }
            }
            return false;
          }
          const cacheData = getCache().data;
          finalState.data = compare2(cacheData, newData) ? cacheData : newData;
          if (shouldStartNewRequest) {
            if (callbackSafeguard()) {
              getConfig().onSuccess(newData, key, config);
            }
          }
        } catch (err) {
          cleanupState();
          const currentConfig = getConfig();
          const { shouldRetryOnError } = currentConfig;
          if (!currentConfig.isPaused()) {
            finalState.error = err;
            if (shouldStartNewRequest && callbackSafeguard()) {
              currentConfig.onError(err, key, currentConfig);
              if (shouldRetryOnError === true || isFunction(shouldRetryOnError) && shouldRetryOnError(err)) {
                if (isActive()) {
                  currentConfig.onErrorRetry(err, key, currentConfig, revalidate, {
                    retryCount: (opts.retryCount || 0) + 1,
                    dedupe: true
                  });
                }
              }
            }
          }
        }
        loading = false;
        finishRequestAndUpdateState();
        return true;
      },
      // `setState` is immutable, and `eventsCallback`, `fnArg`, and
      // `keyValidating` are depending on `key`, so we can exclude them from
      // the deps array.
      //
      // FIXME:
      // `fn` and `config` might be changed during the lifecycle,
      // but they might be changed every render like this.
      // `useSWR('key', () => fetch('/api/'), { suspense: true })`
      // So we omit the values from the deps array
      // even though it might cause unexpected behaviors.
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
        key,
        cache2
      ]
    );
    const boundMutate = T2(
      // Use callback to make sure `keyRef.current` returns latest result every time
      (...args) => {
        return internalMutate(cache2, keyRef.current, ...args);
      },
      // eslint-disable-next-line react-hooks/exhaustive-deps
      []
    );
    useIsomorphicLayoutEffect(() => {
      fetcherRef.current = fetcher;
      configRef.current = config;
      if (!isUndefined(cachedData)) {
        laggyDataRef.current = cachedData;
      }
    });
    useIsomorphicLayoutEffect(() => {
      if (!key)
        return;
      const softRevalidate = revalidate.bind(UNDEFINED, WITH_DEDUPE);
      let nextFocusRevalidatedAt = 0;
      const onRevalidate = (type) => {
        if (type == constants.FOCUS_EVENT) {
          const now = Date.now();
          if (getConfig().revalidateOnFocus && now > nextFocusRevalidatedAt && isActive()) {
            nextFocusRevalidatedAt = now + getConfig().focusThrottleInterval;
            softRevalidate();
          }
        } else if (type == constants.RECONNECT_EVENT) {
          if (getConfig().revalidateOnReconnect && isActive()) {
            softRevalidate();
          }
        } else if (type == constants.MUTATE_EVENT) {
          return revalidate();
        }
        return;
      };
      const unsubEvents = subscribeCallback(key, EVENT_REVALIDATORS, onRevalidate);
      unmountedRef.current = false;
      keyRef.current = key;
      initialMountedRef.current = true;
      setCache({
        _k: fnArg
      });
      if (shouldDoInitialRevalidation) {
        if (isUndefined(data) || IS_SERVER) {
          softRevalidate();
        } else {
          rAF(softRevalidate);
        }
      }
      return () => {
        unmountedRef.current = true;
        unsubEvents();
      };
    }, [
      key
    ]);
    useIsomorphicLayoutEffect(() => {
      let timer;
      function next() {
        const interval = isFunction(refreshInterval) ? refreshInterval(data) : refreshInterval;
        if (interval && timer !== -1) {
          timer = setTimeout(execute, interval);
        }
      }
      function execute() {
        if (!getCache().error && (refreshWhenHidden || getConfig().isVisible()) && (refreshWhenOffline || getConfig().isOnline())) {
          revalidate(WITH_DEDUPE).then(next);
        } else {
          next();
        }
      }
      next();
      return () => {
        if (timer) {
          clearTimeout(timer);
          timer = -1;
        }
      };
    }, [
      refreshInterval,
      refreshWhenHidden,
      refreshWhenOffline,
      key
    ]);
    x2(returnedData);
    if (suspense && isUndefined(data) && key) {
      if (!IS_REACT_LEGACY && IS_SERVER) {
        throw new Error("Fallback data is required when using suspense in SSR.");
      }
      fetcherRef.current = fetcher;
      configRef.current = config;
      unmountedRef.current = false;
      throw isUndefined(error) ? revalidate(WITH_DEDUPE) : error;
    }
    return {
      mutate: boundMutate,
      get data() {
        stateDependencies.data = true;
        return returnedData;
      },
      get error() {
        stateDependencies.error = true;
        return error;
      },
      get isValidating() {
        stateDependencies.isValidating = true;
        return isValidating;
      },
      get isLoading() {
        stateDependencies.isLoading = true;
        return isLoading;
      }
    };
  };
  var SWRConfig2 = OBJECT.defineProperty(SWRConfig, "defaultValue", {
    value: defaultConfig
  });
  var useSWR = withArgs(useSWRHandler);

  // src/popup/Popup.tsx
  var import_webextension_polyfill8 = __toESM(require_browser_polyfill());

  // src/components/DialogBox.tsx
  init_hooks_module();
  init_react();
  var import_react_draggable = __toESM(require_cjs());

  // node_modules/uuid/dist/esm-browser/rng.js
  var getRandomValues;
  var rnds8 = new Uint8Array(16);
  function rng() {
    if (!getRandomValues) {
      getRandomValues = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
      if (!getRandomValues) {
        throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
      }
    }
    return getRandomValues(rnds8);
  }

  // node_modules/uuid/dist/esm-browser/stringify.js
  var byteToHex = [];
  for (let i3 = 0; i3 < 256; ++i3) {
    byteToHex.push((i3 + 256).toString(16).slice(1));
  }
  function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
  }

  // node_modules/uuid/dist/esm-browser/native.js
  var randomUUID = typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
  var native_default = {
    randomUUID
  };

  // node_modules/uuid/dist/esm-browser/v4.js
  function v4(options, buf, offset) {
    if (native_default.randomUUID && !buf && !options) {
      return native_default.randomUUID();
    }
    options = options || {};
    const rnds = options.random || (options.rng || rng)();
    rnds[6] = rnds[6] & 15 | 64;
    rnds[8] = rnds[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (let i3 = 0; i3 < 16; ++i3) {
        buf[offset + i3] = rnds[i3];
      }
      return buf;
    }
    return unsafeStringify(rnds);
  }
  var v4_default = v4;

  // src/components/DialogBox.tsx
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());

  // src/config.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  async function getProviderConfigs() {
    const { provider = "aikit" /* AiKit */ } = await import_webextension_polyfill.default.storage.local.get("provider");
    const configKey = `provider:${"gpt3" /* OpenAI */}`;
    const result = await import_webextension_polyfill.default.storage.local.get(configKey);
    return {
      provider,
      configs: {
        ["gpt3" /* OpenAI */]: result[configKey]
      }
    };
  }
  async function getHistoryChat() {
    return await import_webextension_polyfill.default.storage.local.get("chat");
  }

  // src/content-script/ChatGPTError.tsx
  init_react();
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/content-script/utils.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  function isBraveBrowser() {
    var _a;
    return (_a = navigator.brave) == null ? void 0 : _a.isBrave();
  }

  // node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  init_preact_module();
  init_preact_module();
  var _3 = 0;
  function o3(o4, e3, n2, t3, f3) {
    var l3, s3, u3 = {};
    for (s3 in e3)
      "ref" == s3 ? l3 = e3[s3] : u3[s3] = e3[s3];
    var a3 = { type: o4, props: u3, key: n2, ref: l3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: --_3, __source: f3, __self: t3 };
    if ("function" == typeof o4 && (l3 = o4.defaultProps))
      for (s3 in l3)
        void 0 === u3[s3] && (u3[s3] = l3[s3]);
    return l.vnode && l.vnode(a3), a3;
  }

  // src/content-script/ChatGPTError.tsx
  function ChatGPTError(props) {
    const { error, retry } = props;
    const handleOptionLinkClick = bn.useCallback((e3) => {
      e3.preventDefault();
      import_webextension_polyfill3.default.runtime.sendMessage({ type: "OPEN_OPTIONS_PAGE" });
    }, []);
    const handleSwitchToAiKit = bn.useCallback((e3) => {
      e3.preventDefault();
      import_webextension_polyfill3.default.runtime.sendMessage({ type: "ONCLICK_SWITCH_TO_AIKIT" });
      alert("\u5B8C\u6210\u5207\u6362");
    }, []);
    if (error === "UNAUTHORIZED" || error === "CLOUDFLARE") {
      return /* @__PURE__ */ o3("p", { children: [
        "\u8BF7\u767B\u5F55ChatGPT\u5E76\u901A\u8FC7\u771F\u4EBA\u9A8C\u8BC1\xA0",
        /* @__PURE__ */ o3("a", { href: "https://chat.openai.com", target: "_blank", rel: "noreferrer", children: "chat.openai.com" }),
        retry > 0 && (() => {
          if (isBraveBrowser()) {
            return /* @__PURE__ */ o3("span", { className: "block mt-2", children: [
              "\u8FD8\u662F\u4E0D\u5DE5\u4F5C\uFF1F",
              /* @__PURE__ */ o3("a", { href: "https://goworks.vercel.app/aikit/troubleshooting.html", children: "AiKit\u5E38\u89C1\u95EE\u9898\u89E3\u51B3\u529E\u6CD5" })
            ] });
          } else {
            return /* @__PURE__ */ o3("span", { className: "italic block mt-2 text-xs", children: [
              "ChatGPT(OpenAI)\u9700\u8981\u6BCF\u9694\u4E00\u6BB5\u65F6\u95F4\u901A\u8FC7\u4E00\u6B21\u5B89\u5168\u68C0\u67E5\u3002 \u5982\u679C\u8FD8\u662F\u8BBF\u95EE\u4E0D\u4E86\uFF0C\u8FD8\u53EF\u4EE5\u5728",
              /* @__PURE__ */ o3("a", { href: "#", onClick: handleOptionLinkClick, children: "\u8BBE\u7F6E" }),
              "\u91CC\u4FEE\u6539AI\u63A5\u53E3\u670D\u52A1\u5546\u4E3AAiKit\u5B98\u65B9\u63A5\u53E3\u3002",
              /* @__PURE__ */ o3("a", { href: "#", onClick: handleSwitchToAiKit, children: "\u4E00\u952E\u5207\u6362" })
            ] });
          }
        })()
      ] });
    }
    if (error) {
      return /* @__PURE__ */ o3("p", { children: [
        "\u8BBF\u95EE\u5931\u8D25:",
        /* @__PURE__ */ o3("span", { className: "break-all block", children: error })
      ] });
    }
    return null;
  }
  var ChatGPTError_default = bn.memo(ChatGPTError);

  // src/domUtils.ts
  function scrollToBottom(ref) {
    const targetScrollTop = ref.scrollHeight - ref.clientHeight;
    ref.scroll({
      behavior: "smooth",
      top: targetScrollTop
    });
  }
  function elementBoundCheck(element) {
    if (!element) {
      return;
    }
    const clientRect = element.getBoundingClientRect();
    let transX = 0;
    let transY = 0;
    if (clientRect.right > window.innerWidth) {
      transX = window.innerWidth - clientRect.right;
    }
    if (clientRect.left < 0) {
      transX = -clientRect.left;
    }
    if (clientRect.top < 0) {
      transY = -clientRect.top;
    }
    if (clientRect.bottom > window.innerHeight) {
      transY = window.innerHeight - clientRect.bottom;
    }
    return {
      x: transX,
      y: transY
    };
  }

  // src/images/avatar.svg
  init_react();
  var SvgAvatar = (props) => /* @__PURE__ */ o3("svg", { width: "1em", height: "1em", viewBox: "0 0 215 269", xmlns: "http://www.w3.org/2000/svg", xmlnsXlink: "http://www.w3.org/1999/xlink", ...props, children: [
    /* @__PURE__ */ o3("title", { children: "avatar" }),
    /* @__PURE__ */ o3("g", { id: "Page-1", stroke: "none", strokeWidth: 1, fill: "none", fillRule: "evenodd", children: /* @__PURE__ */ o3("g", { id: "avatar", fill: "currentColor", fillRule: "nonzero", children: /* @__PURE__ */ o3("path", { d: "M182.75,139.88 C200.561183,139.88 215,154.332248 215,172.16 L215,182.92 C215,225.345468 175.020535,269 107.5,269 C39.9794644,269 0,225.345468 0,182.92 L0,172.16 C0,154.332248 14.4388169,139.88 32.25,139.88 L182.75,139.88 Z M182.75,161.4 L32.25,161.4 C26.312939,161.4 21.5,166.217416 21.5,172.16 L21.5,182.92 C21.5,213.858168 52.2913691,247.48 107.5,247.48 C162.708631,247.48 193.5,213.858168 193.5,182.92 L193.5,172.16 C193.5,166.217416 188.687062,161.4 182.75,161.4 Z M107.5,0 C140.153836,0 166.625,26.4957885 166.625,59.18 C166.625,91.8642115 140.153836,118.36 107.5,118.36 C74.8461642,118.36 48.375,91.8642115 48.375,59.18 C48.375,26.4957885 74.8461642,0 107.5,0 Z M107.5,21.52 C86.7202863,21.52 69.875,38.3809564 69.875,59.18 C69.875,79.9790436 86.7202863,96.84 107.5,96.84 C128.279714,96.84 145.125,79.9790436 145.125,59.18 C145.125,38.3809564 128.279714,21.52 107.5,21.52 Z", id: "Shape" }) }) })
  ] });
  var avatar_default = SvgAvatar;

  // src/images/openai.svg
  init_react();
  var SvgOpenai = (props) => /* @__PURE__ */ o3("svg", { width: "1em", height: "1em", viewBox: "0 0 41 41", fill: "none", xmlns: "http://www.w3.org/2000/svg", strokeWidth: 1.5, className: "h-6 w-6", ...props, children: /* @__PURE__ */ o3("path", { d: "M37.5324 16.8707C37.9808 15.5241 38.1363 14.0974 37.9886 12.6859C37.8409 11.2744 37.3934 9.91076 36.676 8.68622C35.6126 6.83404 33.9882 5.3676 32.0373 4.4985C30.0864 3.62941 27.9098 3.40259 25.8215 3.85078C24.8796 2.7893 23.7219 1.94125 22.4257 1.36341C21.1295 0.785575 19.7249 0.491269 18.3058 0.500197C16.1708 0.495044 14.0893 1.16803 12.3614 2.42214C10.6335 3.67624 9.34853 5.44666 8.6917 7.47815C7.30085 7.76286 5.98686 8.3414 4.8377 9.17505C3.68854 10.0087 2.73073 11.0782 2.02839 12.312C0.956464 14.1591 0.498905 16.2988 0.721698 18.4228C0.944492 20.5467 1.83612 22.5449 3.268 24.1293C2.81966 25.4759 2.66413 26.9026 2.81182 28.3141C2.95951 29.7256 3.40701 31.0892 4.12437 32.3138C5.18791 34.1659 6.8123 35.6322 8.76321 36.5013C10.7141 37.3704 12.8907 37.5973 14.9789 37.1492C15.9208 38.2107 17.0786 39.0587 18.3747 39.6366C19.6709 40.2144 21.0755 40.5087 22.4946 40.4998C24.6307 40.5054 26.7133 39.8321 28.4418 38.5772C30.1704 37.3223 31.4556 35.5506 32.1119 33.5179C33.5027 33.2332 34.8167 32.6547 35.9659 31.821C37.115 30.9874 38.0728 29.9178 38.7752 28.684C39.8458 26.8371 40.3023 24.6979 40.0789 22.5748C39.8556 20.4517 38.9639 18.4544 37.5324 16.8707ZM22.4978 37.8849C20.7443 37.8874 19.0459 37.2733 17.6994 36.1501C17.7601 36.117 17.8666 36.0586 17.936 36.0161L25.9004 31.4156C26.1003 31.3019 26.2663 31.137 26.3813 30.9378C26.4964 30.7386 26.5563 30.5124 26.5549 30.2825V19.0542L29.9213 20.998C29.9389 21.0068 29.9541 21.0198 29.9656 21.0359C29.977 21.052 29.9842 21.0707 29.9867 21.0902V30.3889C29.9842 32.375 29.1946 34.2791 27.7909 35.6841C26.3872 37.0892 24.4838 37.8806 22.4978 37.8849ZM6.39227 31.0064C5.51397 29.4888 5.19742 27.7107 5.49804 25.9832C5.55718 26.0187 5.66048 26.0818 5.73461 26.1244L13.699 30.7248C13.8975 30.8408 14.1233 30.902 14.3532 30.902C14.583 30.902 14.8088 30.8408 15.0073 30.7248L24.731 25.1103V28.9979C24.7321 29.0177 24.7283 29.0376 24.7199 29.0556C24.7115 29.0736 24.6988 29.0893 24.6829 29.1012L16.6317 33.7497C14.9096 34.7416 12.8643 35.0097 10.9447 34.4954C9.02506 33.9811 7.38785 32.7263 6.39227 31.0064ZM4.29707 13.6194C5.17156 12.0998 6.55279 10.9364 8.19885 10.3327C8.19885 10.4013 8.19491 10.5228 8.19491 10.6071V19.808C8.19351 20.0378 8.25334 20.2638 8.36823 20.4629C8.48312 20.6619 8.64893 20.8267 8.84863 20.9404L18.5723 26.5542L15.206 28.4979C15.1894 28.5089 15.1703 28.5155 15.1505 28.5173C15.1307 28.5191 15.1107 28.516 15.0924 28.5082L7.04046 23.8557C5.32135 22.8601 4.06716 21.2235 3.55289 19.3046C3.03862 17.3858 3.30624 15.3413 4.29707 13.6194ZM31.955 20.0556L22.2312 14.4411L25.5976 12.4981C25.6142 12.4872 25.6333 12.4805 25.6531 12.4787C25.6729 12.4769 25.6928 12.4801 25.7111 12.4879L33.7631 17.1364C34.9967 17.849 36.0017 18.8982 36.6606 20.1613C37.3194 21.4244 37.6047 22.849 37.4832 24.2684C37.3617 25.6878 36.8382 27.0432 35.9743 28.1759C35.1103 29.3086 33.9415 30.1717 32.6047 30.6641C32.6047 30.5947 32.6047 30.4733 32.6047 30.3889V21.188C32.6066 20.9586 32.5474 20.7328 32.4332 20.5338C32.319 20.3348 32.154 20.1698 31.955 20.0556ZM35.3055 15.0128C35.2464 14.9765 35.1431 14.9142 35.069 14.8717L27.1045 10.2712C26.906 10.1554 26.6803 10.0943 26.4504 10.0943C26.2206 10.0943 25.9948 10.1554 25.7963 10.2712L16.0726 15.8858V11.9982C16.0715 11.9783 16.0753 11.9585 16.0837 11.9405C16.0921 11.9225 16.1048 11.9068 16.1207 11.8949L24.1719 7.25025C25.4053 6.53903 26.8158 6.19376 28.2383 6.25482C29.6608 6.31589 31.0364 6.78077 32.2044 7.59508C33.3723 8.40939 34.2842 9.53945 34.8334 10.8531C35.3826 12.1667 35.5464 13.6095 35.3055 15.0128ZM14.2424 21.9419L10.8752 19.9981C10.8576 19.9893 10.8423 19.9763 10.8309 19.9602C10.8195 19.9441 10.8122 19.9254 10.8098 19.9058V10.6071C10.8107 9.18295 11.2173 7.78848 11.9819 6.58696C12.7466 5.38544 13.8377 4.42659 15.1275 3.82264C16.4173 3.21869 17.8524 2.99464 19.2649 3.1767C20.6775 3.35876 22.0089 3.93941 23.1034 4.85067C23.0427 4.88379 22.937 4.94215 22.8668 4.98473L14.9024 9.58517C14.7025 9.69878 14.5366 9.86356 14.4215 10.0626C14.3065 10.2616 14.2466 10.4877 14.2479 10.7175L14.2424 21.9419ZM16.071 17.9991L20.4018 15.4978L24.7325 17.9975V22.9985L20.4018 25.4983L16.071 22.9985V17.9991Z", fill: "currentColor" }) });
  var openai_default = SvgOpenai;

  // src/images/refresh.svg
  init_react();
  var SvgRefresh = (props) => /* @__PURE__ */ o3("svg", { stroke: "currentColor", fill: "none", strokeWidth: 1.5, viewBox: "0 0 24 24", strokeLinecap: "round", strokeLinejoin: "round", className: "h-3 w-3", height: "1em", width: "1em", xmlns: "http://www.w3.org/2000/svg", ...props, children: [
    /* @__PURE__ */ o3("polyline", { points: "1 4 1 10 7 10" }),
    /* @__PURE__ */ o3("polyline", { points: "23 20 23 14 17 14" }),
    /* @__PURE__ */ o3("path", { d: "M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15" })
  ] });
  var refresh_default = SvgRefresh;

  // src/images/send.svg
  init_react();
  var SvgSend = (props) => /* @__PURE__ */ o3("svg", { stroke: "currentColor", fill: "none", strokeWidth: 2, viewBox: "0 0 24 24", strokeLinecap: "round", strokeLinejoin: "round", className: "h-4 w-4 mr-1", height: "1em", width: "1em", xmlns: "http://www.w3.org/2000/svg", ...props, children: [
    /* @__PURE__ */ o3("line", { x1: 22, y1: 2, x2: 11, y2: 13 }),
    /* @__PURE__ */ o3("polygon", { points: "22 2 15 22 11 13 2 9 22 2" })
  ] });
  var send_default = SvgSend;

  // src/useUpdateEffect.ts
  init_react();

  // src/useFirstMountState.ts
  init_react();
  function useFirstMountState() {
    const isFirst = _2(true);
    if (isFirst.current) {
      isFirst.current = false;
      return true;
    }
    return isFirst.current;
  }

  // src/useUpdateEffect.ts
  var useUpdateEffect = (effect, deps) => {
    const isFirstMount = useFirstMountState();
    h2(() => {
      if (!isFirstMount) {
        return effect();
      }
    }, deps);
  };
  var useUpdateEffect_default = useUpdateEffect;

  // src/utils/getLatestQnA.ts
  function getLatestQnA(conversation) {
    let latestQnA = null;
    const qnAList = conversation == null ? void 0 : conversation.qnaList;
    if (qnAList && qnAList.length) {
      latestQnA = qnAList[qnAList.length - 1];
    }
    return latestQnA;
  }

  // src/utils/isHistoryChatValid.ts
  function isHistoryChatValid(historyConversation) {
    return !!(historyConversation.id && historyConversation.qnaList && historyConversation.createAt && historyConversation.createAt - Date.now() < 864e5);
  }

  // src/utils/initChat.ts
  function getInitChat() {
    return {
      id: v4_default(),
      qnaList: [],
      createAt: Date.now()
    };
  }
  function persistedChatOrDefault(persistent) {
    if (persistent) {
      return getHistoryChat().then((msg) => {
        console.debug("historyChat loaded.", msg.chat);
        const defaultChat = getInitChat();
        return isHistoryChatValid(msg.chat) ? { ...defaultChat, ...msg.chat } : defaultChat;
      }).catch(() => {
        return getInitChat();
      });
    } else {
      return Promise.resolve(getInitChat());
    }
  }
  async function buildChat(question, persistent) {
    const promise = persistedChatOrDefault(persistent);
    promise.then((historyChat) => {
      if (question) {
        historyChat.qnaList.push({
          question,
          answer: {
            id: v4_default(),
            text: "",
            status: "not_started"
          }
        });
      }
      return historyChat;
    });
    return promise;
  }

  // src/utils/useProvider.ts
  init_react();
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  function useAiProvider() {
    const [config, setConfig] = bn.useState();
    bn.useEffect(() => {
      let cancelled = false;
      try {
        getProviderConfigs().then((pConfig) => {
          !cancelled && setConfig(pConfig);
        });
      } catch (e3) {
        console.error(e3);
      }
      const listener = async (message) => {
        console.debug("receive message in useAiProvider", message);
        if (message.type === "ONCLICK_SWITCH_TO_AIKIT") {
          const providerConfigs = await getProviderConfigs();
          setConfig(providerConfigs);
        }
      };
      try {
        import_webextension_polyfill4.default.runtime.onMessage.addListener(listener);
      } catch (e3) {
        console.error(e3);
      }
      return () => {
        cancelled = true;
        try {
          import_webextension_polyfill4.default.runtime.onMessage.removeListener(listener);
        } catch (e3) {
          console.error(e3);
        }
      };
    }, []);
    return config;
  }

  // src/components/converse.ts
  function updateByAiEvent(prev, msg) {
    if (prev == null) {
      return prev;
    }
    const qnaList = prev == null ? void 0 : prev.qnaList;
    if (qnaList == null) {
      return prev;
    }
    const index = qnaList.findIndex((x4) => {
      return x4.question.id === msg.data.questionId;
    });
    if (index === -1) {
      return prev;
    }
    const prevItem = qnaList[index];
    let nextItem;
    if ("event" in msg) {
      if (msg.event === "done") {
        nextItem = {
          ...prevItem,
          answer: {
            ...prevItem.answer,
            text: msg.data.text,
            status: "succeed"
          }
        };
      } else {
        nextItem = {
          ...prevItem,
          answer: {
            ...prevItem.answer,
            text: msg.data.text,
            status: "progressing"
          }
        };
      }
    } else {
      nextItem = {
        ...prevItem,
        answer: {
          ...prevItem.answer,
          error: msg.error,
          status: "error"
        }
      };
    }
    return {
      ...prev,
      qnaList: [...qnaList.slice(0, index), nextItem, ...qnaList.slice(index + 1)]
    };
  }

  // src/components/CursorBlock.tsx
  function CursorBlock() {
    return /* @__PURE__ */ o3("span", { className: "cursorBlock" });
  }
  var CursorBlock_default = CursorBlock;

  // src/components/OpenAIError.tsx
  function OpenAIError(props) {
    var _a;
    const { error, messages, onCleanChat } = props;
    if (error.startsWith("{")) {
      const errorObj = JSON.parse(error);
      if (((_a = errorObj == null ? void 0 : errorObj.error) == null ? void 0 : _a.code) === "context_length_exceeded") {
        return /* @__PURE__ */ o3("p", { children: [
          errorObj.error.message,
          error.includes("context_length_exceeded") ? /* @__PURE__ */ o3("a", { href: "#", className: "btn-icon", onClick: onCleanChat, children: "\u6D88\u606F\u8FC7\u591A\uFF0C\u6E05\u7406\u5386\u53F2\u8BB0\u5F55" }) : null
        ] });
      }
    }
    return /* @__PURE__ */ o3("p", { children: [
      error,
      " ",
      messages.length > 20 ? /* @__PURE__ */ o3("a", { href: "#", className: "btn-icon", onClick: onCleanChat, children: "\u6D88\u606F\u8FC7\u591A\uFF0C\u6E05\u7406\u5386\u53F2\u8BB0\u5F55" }) : null
    ] });
  }
  var OpenAIError_default = OpenAIError;

  // src/components/QuestionTag.tsx
  var nameMap = {
    translate: "\u7FFB\u8BD1",
    summarize: "\u6982\u8FF0"
  };
  function QuestionTag(props) {
    const { type } = props;
    if (type == null || type === "chat" || nameMap[type] == null) {
      return null;
    }
    return /* @__PURE__ */ o3("span", { className: "question-tag", children: nameMap[type] });
  }
  var QuestionTag_default = QuestionTag;

  // src/components/useBrowserAPIProbe.ts
  init_react();
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());
  var EXTENSION_CONTEXT_INVALIDATED = "Extension context invalidated";
  function handleException(e3, setError) {
    if ("message" in e3) {
      if (e3.message.includes(EXTENSION_CONTEXT_INVALIDATED)) {
        setError({
          error: EXTENSION_CONTEXT_INVALIDATED,
          message: "\u63D2\u4EF6\u5DF2\u66F4\u65B0\uFF0C\u8BF7\u5237\u9875\u9762\uFF08\u56E0\u6D4F\u89C8\u5668\u673A\u5236\uFF09"
        });
        return;
      }
    }
    setError({
      error: "unknown error",
      message: "" + e3
    });
  }
  function useBrowserAPIProbe() {
    const [error, setError] = bn.useState();
    function probeAPIs() {
      try {
        import_webextension_polyfill5.default.storage.local.get("provider").catch((e3) => {
          handleException(e3, setError);
        });
      } catch (e3) {
        handleException(e3, setError);
      }
    }
    bn.useEffect(() => {
      probeAPIs();
    }, []);
    const probeApi = bn.useCallback(() => {
      probeAPIs();
    }, []);
    return {
      error,
      probeApi
    };
  }
  var useBrowserAPIProbe_default = useBrowserAPIProbe;

  // src/components/DialogBox.tsx
  function DialogItem(props) {
    const { message } = props;
    return /* @__PURE__ */ o3("div", { className: `dialog-item ${message.role}`, children: [
      /* @__PURE__ */ o3("div", { className: "avatar-box", children: /* @__PURE__ */ o3("div", { className: "avatar", children: message.role === "assistant" ? /* @__PURE__ */ o3(openai_default, {}) : /* @__PURE__ */ o3(avatar_default, {}) }) }),
      /* @__PURE__ */ o3("div", { className: "dialog-content-wrapper", children: /* @__PURE__ */ o3("div", { className: "dialog-content", children: [
        /* @__PURE__ */ o3(QuestionTag_default, { type: message.qType }),
        message.data,
        message.status === "progressing" || message.status === "not_started" ? /* @__PURE__ */ o3(CursorBlock_default, {}) : null
      ] }) })
    ] });
  }
  function newQnA(text) {
    return {
      question: {
        id: v4_default(),
        text,
        type: "chat"
      },
      answer: {
        id: v4_default(),
        text: "",
        status: "not_started"
      }
    };
  }
  function DialogBox(props) {
    const { question, persistent } = props;
    const [conversation, setConversation] = bn.useState();
    const portRef = bn.useRef();
    const inputRef = bn.useRef(null);
    const scrollRef = bn.useRef(null);
    const [text, setText] = bn.useState("");
    const [inputHeight, setInputHeight] = bn.useState(24);
    const [isChat, setIsChat] = bn.useState(() => {
      return question == null || (question == null ? void 0 : question.type) === "chat";
    });
    const [retry, setRetry] = p2(0);
    const aiProvider = useAiProvider();
    const dialogBoxRef = bn.useRef(null);
    const { error: probeError, probeApi } = useBrowserAPIProbe_default();
    bn.useEffect(() => {
      buildChat(question, persistent).then((chat) => {
        setConversation(chat);
      });
    }, [persistent, question]);
    bn.useEffect(() => {
      let port;
      try {
        port = import_webextension_polyfill6.default.runtime.connect();
        portRef.current = port;
      } catch (e3) {
        console.error(e3);
        return;
      }
      const listener = (msg) => {
        console.debug("received answer", msg);
        setConversation((prev) => {
          return updateByAiEvent(prev, msg);
        });
      };
      try {
        port.onMessage.addListener(listener);
      } catch (e3) {
        console.error(e3);
      }
      return () => {
        try {
          port.onMessage.removeListener(listener);
          port.disconnect();
        } catch (e3) {
          console.error(e3);
        }
        portRef.current = void 0;
        console.debug("browser port disconnected");
      };
    }, []);
    bn.useEffect(() => {
      const latestQnA = getLatestQnA(conversation);
      if (persistent && latestQnA && latestQnA.answer.status === "succeed") {
        console.debug("PERSIST_CHAT event sent");
        import_webextension_polyfill6.default.runtime.sendMessage({
          type: "PERSIST_CHAT",
          chat: conversation
        }).catch((e3) => {
          console.error(e3);
        });
      }
    }, [conversation, persistent]);
    bn.useEffect(() => {
      const port = portRef.current;
      if (!port) {
        console.debug("browser port not exist.");
        return;
      }
      const latestQnA = getLatestQnA(conversation);
      if ((latestQnA == null ? void 0 : latestQnA.answer.status) === "not_started") {
        try {
          console.debug("before postMessage");
          port.postMessage({
            conversation,
            persistent
          });
          console.debug("after postMessage");
        } catch (e3) {
          const err = e3;
          if ("message" in err && err.message.includes("Extension context invalidated")) {
            setConversation((prev) => {
              const errorMsg = {
                error: "\u63D2\u4EF6\u5DF2\u66F4\u65B0\uFF0C\u8BF7\u5237\u65B0\u7F51\u9875\u6216\u91CD\u5F00\u7A97\u53E3",
                data: {
                  questionId: latestQnA.question.id
                }
              };
              return updateByAiEvent(prev, errorMsg);
            });
          }
          console.error(e3);
        }
      }
    }, [conversation, persistent]);
    const handleInputChange = bn.useCallback((e3) => {
      setText(() => {
        return e3.target.value;
      });
    }, []);
    const handleKeyDown = bn.useCallback(
      (e3) => {
        if (e3.which === 13 && e3.shiftKey == true) {
          setInputHeight(e3.target.value.split("\n").length * 24 + 24);
        }
        if (e3.which === 8) {
          e3.target.value.endsWith("\n") && setInputHeight((prev) => prev - 24);
        }
        if (e3.keyCode == 13 && e3.shiftKey == false) {
          e3.preventDefault();
          submit(e3.target.value, conversation);
        }
      },
      [conversation]
    );
    const sendRetry = bn.useCallback(() => {
      const latestQA = getLatestQnA(conversation);
      if (!conversation || !latestQA || !latestQA.answer.error) {
        return;
      }
      setConversation({
        ...conversation,
        qnaList: [
          ...conversation.qnaList.slice(0, conversation.qnaList.length - 1),
          {
            ...latestQA,
            answer: {
              ...latestQA.answer,
              error: "",
              status: "not_started"
            }
          }
        ]
      });
      setRetry((r3) => r3 + 1);
    }, [conversation]);
    const handleCleanChat = bn.useCallback(() => {
      const latestQA = getLatestQnA(conversation);
      if (!conversation || !latestQA || !latestQA.answer.error) {
        return;
      }
      setConversation({
        ...conversation,
        qnaList: [
          {
            ...latestQA,
            answer: {
              ...latestQA.answer,
              error: "",
              status: "not_started"
            }
          }
        ]
      });
      setRetry((r3) => r3 + 1);
    }, [conversation]);
    function submit(inputText, conversation2) {
      if (!conversation2) {
        return;
      }
      const qnA = newQnA(inputText);
      if (conversation2.qnaList.length === 0) {
        setConversation({
          ...conversation2,
          qnaList: [qnA]
        });
      } else {
        const progressing = conversation2.qnaList.find((x4) => {
          return x4.answer.status === "progressing";
        });
        if (progressing) {
          return;
        }
        setConversation((prevState) => {
          var _a;
          return {
            ...getInitChat(),
            ...prevState,
            qnaList: [...(_a = prevState == null ? void 0 : prevState.qnaList) != null ? _a : [], qnA]
          };
        });
      }
      setTimeout(() => {
        scrollRef.current && scrollToBottom(scrollRef.current);
      }, 100);
      setText("");
    }
    const handleSendClick = bn.useCallback(
      (e3) => {
        e3.preventDefault();
        if (conversation && text) {
          submit(text, conversation);
        }
      },
      [conversation, text]
    );
    useUpdateEffect_default(() => {
      if (!conversation) {
        return;
      }
      requestAnimationFrame(() => {
        scrollRef.current && scrollToBottom(scrollRef.current);
      });
    }, [conversation]);
    const messages = bn.useMemo(() => {
      var _a;
      const msgList = [];
      (_a = conversation == null ? void 0 : conversation.qnaList) == null ? void 0 : _a.forEach((qna) => {
        msgList.push({
          status: "succeed",
          role: "user",
          data: qna.question.text,
          id: qna.question.id,
          qType: qna.question.type
        });
        msgList.push({
          status: qna.answer.status,
          role: "assistant",
          data: qna.answer.text,
          id: qna.answer.id,
          error: qna.answer.error
        });
      });
      return msgList;
    }, [conversation]);
    const handleTriggerChatClick = bn.useCallback(() => {
      setIsChat(true);
      setTimeout(() => {
        var _a;
        (_a = inputRef.current) == null ? void 0 : _a.focus();
      }, 50);
    }, []);
    const error = bn.useMemo(() => {
      const qnaList = conversation == null ? void 0 : conversation.qnaList;
      if (!qnaList || !qnaList.length) {
        return;
      }
      return qnaList[qnaList.length - 1].answer.error;
    }, [conversation]);
    h2(() => {
      const onFocus = () => {
        probeApi();
        if (error && (error == "UNAUTHORIZED" || error === "CLOUDFLARE")) {
          sendRetry();
        }
      };
      window.addEventListener("focus", onFocus);
      return () => {
        window.removeEventListener("focus", onFocus);
      };
    }, [error, probeApi, sendRetry]);
    const [position, setPosition] = bn.useState();
    bn.useEffect(() => {
      const result = elementBoundCheck(dialogBoxRef == null ? void 0 : dialogBoxRef.current);
      result && setPosition(result);
    }, []);
    const handDragStop = bn.useCallback((e3, data) => {
      setPosition(data);
    }, []);
    return /* @__PURE__ */ o3(import_react_draggable.default, { handle: ".dialog-header", position, onStop: handDragStop, children: /* @__PURE__ */ o3("div", { className: "aikit-dialog-box", ref: dialogBoxRef, style: { width: 400, maxHeight: 450 }, children: [
      /* @__PURE__ */ o3("div", { className: "dialog-header" }),
      /* @__PURE__ */ o3("div", { className: "dialog-list", ref: scrollRef, children: [
        messages.map((message, index) => /* @__PURE__ */ o3(DialogItem, { message }, index)),
        error && !probeError ? /* @__PURE__ */ o3("div", { className: "dialog-list-tail", children: [
          (aiProvider == null ? void 0 : aiProvider.provider) === "chatgpt" /* ChatGPT */ ? /* @__PURE__ */ o3(ChatGPTError_default, { error, retry }) : null,
          (aiProvider == null ? void 0 : aiProvider.provider) !== "chatgpt" /* ChatGPT */ ? /* @__PURE__ */ o3("div", { children: [
            /* @__PURE__ */ o3(OpenAIError_default, { messages, error, onCleanChat: handleCleanChat }),
            /* @__PURE__ */ o3("button", { className: "regenerate-btn", onClick: sendRetry, children: [
              /* @__PURE__ */ o3("span", { className: "btn-icon", children: /* @__PURE__ */ o3(refresh_default, {}) }),
              "\xA0\u91CD\u65B0\u751F\u6210"
            ] })
          ] }) : null
        ] }) : null,
        probeError ? /* @__PURE__ */ o3("div", { className: "dialog-list-tail", children: probeError.message }) : null
      ] }),
      isChat ? /* @__PURE__ */ o3("div", { className: "message-input-wrapper", children: [
        /* @__PURE__ */ o3(
          "textarea",
          {
            placeholder: "CMD+\u56DE\u8F66\u53D1\u9001",
            className: "message-input",
            ref: inputRef,
            value: text,
            onKeyDownCapture: handleKeyDown,
            onChange: handleInputChange,
            style: { maxHeight: "120px", height: `${inputHeight}px` },
            autoFocus: true
          }
        ),
        /* @__PURE__ */ o3("a", { role: "button", className: "send", onClick: handleSendClick, children: /* @__PURE__ */ o3(send_default, {}) })
      ] }) : /* @__PURE__ */ o3("div", { className: "triggerChat", onClick: handleTriggerChatClick, children: "\u5F00\u59CB\u804A\u5929" })
    ] }) });
  }
  var DialogBox_default = DialogBox;

  // src/logo.png
  var logo_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAgKADAAQAAAABAAAAgAAAAABrRiZNAABAAElEQVR4AeWdabClVX3u3316YOoWaJAZxCC0DKKIBpRBBKUcrppIohLF3M+pMhU/3FiJlBxSWLcSP8S6t8ovt+6HBL3EDBhvytS9xgARUeYZoUEmReZuGhpooPucfZ/f86z/++7TNHTvpmnAu87Ze613rf/8/New51H3G1gO/d7sHuuem1k5Nz+/ctR1K0fj7m1dN9q968bLu9Fo+Xg8Xj7qRmrrmjIerRt343Wj0WhdNx6vEw31k6NR94u5rlu1aGZm1fKd51fd97uza3/TwqX4vLHLm/9+dtnGF0anjEbj0wXkCaNuvHJ+3O0jVLvFMzPCUf7JSwGuhmDWtYBO20Pi0F8CkXuu+YcM+jndmaXrHtXlKrWvGo9HlyxeOr78sc/MPi0xb9gSj99A5h/997NLH97YndzNj04XULp175UTi2eMVhwB4EUNMXpE0wCudsYNtMdGAnnedAU8fFXgn3cmwU+y9PQbpfsaXV/SzYwv2W9x95PbPjP7QvG9Eeo3TAKs+PbsiQLiHOH6OWG1gtmdMhbY1U4P1wVU1YyQJLUSmJIkMbCqiURrJxkC9CT/Rik2mUipWRkqpeBR5xptN3+n3gvXfGH2Sg2+7gt+vG7LfhfNHrphfuYLmn/nKNZHZFa32asog98k2DgSkNXowRVNJQt4NQSryTU4OhDVbhdz8zoBuKiDPhEGdGBfsBJ4mDGdLzrWEqm/U9ZcuGRm/tsPnz17X+S8/u7t6uvNrL0vmn2PJtRXtZd/avFoRpNqmOUYbJANMAkAONrHFfh+VWjoqqvvY9zOmg/Em+sQvURfgSn1/PdJsnFeK0HjT5vcEPDIEhX20nYfps2Pv79ocff1x8+evfb1FusWhdeHWXte+Bc6zM2fK2vOrNleM7qWec9mBzqzP6i0Nv0FrISEB1AouFowVt9L9S+krVkPdRUv+U3cnDI14ocVwuMirmRp1z8cj2cueOKcr11ecl7r+nWRAHt9+/wztIOe143nT8ksHvVLeQFf+3clBECTJDWzSYwB/4WHwMkgJ7HIE3gZqWQI6JsDG6oCtHQU3TDzI2neZ4FRgBdfnRsqETayrYxmLtep5fzVXzjv35H9WpbXNAF0sDtIzv+1br9XQANQgR1QtbRzyGuTsvbzWiEIe/FWIGtMopwgMOchYQO7yUoSZPZyOGTprnwA4El+9Ot5hVLhOkkQmZUQ0NADL319gjT+oiMhZkbdP4r2yzowPrBA8A68IBQ7vJx26eziWx+c+RPtlOeNxqNlAAHoAMdfD3yb1V4VFEwDTWQV4knQ0w4Qi2YWgVUDPq45aTwMqG3ml+c1pcNu4OCiu2Z9BEbWnJME4jwUTG+jdXfrlwBokeOUUCOrgVYHrRJeKSLj6ZnRzPnHHDD/zcs+OLux5O2ousKwo/R1e3xn9tSZ8ehbAvtoZkct+YBfQAbo2sOpYyYrATF2ohjIJELN5B5okcNB8D3z7R2HQGY5pbUhMG2b/eHSOJRQtcNcWLIiqM0sL50kSSVVJUzqIUF8LVVJniSLVwfJN7+0aew2Jcofrf387I9Rt6MKfu6Qwqy/5YHRBfOj8Z9ysi9QAdtLvgCdIfCyKHNYtR++kRiYmBWCVhKFVgMYHEUTfmZ4gIXOoLdrM2hInS7eWtSqmQkfciCpAn/2bZg0ov8CEjle0s3X6NS5aSLAT5LU9pDZH15o0cejBtkxViz+6h0HjM/dUatBC0W5++rUKy664OBufu4iAXsSs4rAF+iLBFufDO3xeq4DeI2BWu3jNdMnZ3clhQFvOvAGffCWo6U3YKvXmEKTkuW6rgb+WrKRh6w61MFZZwPPZgHNmIk0SF8SoiWGgK4Eoi7eBdtCN75CWfy5HXE2qLgMHm/n1p4Xnv9xxeRvNIv30l7nuADCYu3VrNH0ZRuomc2yXttB+pg98EDPHk899CnWGirZADIkTXCAgFWFsSamr3GXvioS7RLQBn4SxgBbzsKtgaSxbHEafIBtgqiRT7/BVjt1VgSvPiKgD/nISbtbreYfPnHOeT+wQa/S3YTr21fD7Hh25r9f1P1XvWjyXzjDM+s9S6URMLK8Vzug9n3Q6ojMX4CvvZzVY5HDXcs3AauVAQ+cTIVGc0nrTQDX9aYO10pAzehkMlQSMEQ/tcEGVP0VYAUw6gbg87QxAIMq/SVvqNsKINkkSL3ewLjppVEvcn3jS2d3fzY7ml34EARl26FsGo/tILLreMHmoRdGf6unwD4LqLXkF2j01YwEsFq+mbmsDIDR91UiAJ3+6cdoJ0az1n3qBKAhGaBixRjOAQZRvYDnOduAjZicHXyg06i5DVwd8rLqAFQlQwEJv5/5Ex/PCSHbY+YfVgDoCly3mfWirf7IzlnCZwKvCuKfGX13/yXjL74aLzTh53Yte3//L5ePn15/sWbdhxBcyzmAoQxAgMQzVXWNG6y2ShDgWtKLL3VWDhLEySS6ShT3SXYKmoYkoo8w00spWX1HA61mYKiGe2Yjf+EPQCQKJTNeBzgSQ39e0tWfmmteT8gSjwDPbL/GkBUk/KwAc15dJrcH0xb/eP5HM8t3+fTjn/rKOvRur1Ix2S7y9r14dp+N60f/KqHHT85UwAJ4UDDgmuXUFOiqXasBwS5gK0G85xNBlSSPxEmeXgdGrEeKB5oCOcCJT/+sOi5UMG1aClSBEZlZKWq5h5z+JAqS28yXIdg3mQzQBuwcCGuF4GljoIZ5wWpQy37bMkigWgUwy7K68XVLlyz56MOf+fPHkL89SovIKxe1x3cueMvMeO7fBPPhBZCXegBW4J0AUgOgjPNHFACNa8AcwM4KUHK8iMtSaAN6ZjogU7gP+AGlDpj9hi6m0m/UymsQpHDd2k4YwNSMnuSHLKd3EbbxYq+EYBWg5JyQmmv6ATsrhODHiYn+kgdNbQM+CMoo6lpVsiKM75ofLfrw2s+fe7+FvMK7CsUrEtNm/k8AHyAMlIznwAZIAOlZLr+TFCz9glVjjLstC0wLyGpXohTg1PQVD4Yb1MSytXWhAR5auritO/EZYWhpI8x9IXvxvcYbbRIh7AaiifJs79sBHgAxIImg84CEoIq671OH29LPQ8u0h9UiMnRN0jS+PmFET1u671qy6/jkRz49++iLbZ+uBxdeUWHPn1+3/lKBd3wd9sh0A121nGWMmPb9BmCgA7iBH7psEwSQZZ7AOomQYVntHKBrEoc//r3MW7YGVIqH8awPyJJQjKFJ2Uy76AvUEAJUwObMMQkM9Iwhqp4z8LU6BBugKRnCQyJByFbgRFI/dW6VTFxr3KuH2qI1D32+ja/TmeCDr/RMUCEo/6aqc9rvfiBAPlSzl6DWIS/15H5fgA+P/c3nLSArBglSB7os/QGewC4WsP2spw3QGkhflvkCLgnDfc4IhTLJQ5uVRDGfaHOhWam/9Lcx9RVgarpkVQjgAVK8jalmLaTM7pwN2kxXH0nDwbASJst7Vg2AHVaLYRVAH3SMw0cbObr/0X5Luo+/kkcHzaU4Ns09j/P/23dG/0sgfLZmWSWBZ7kCTbAZS9AzG73/T/T5gAgosgTAoQXX4gMW0ygxCHIlwCTosbslRHMiNuFegEW+H3oqmI899Ej31JNPdOvWrDVAy/fco9tdtxX77NPNLFrkmdjzNX6CT8G2LOe+bLRtZZAq04nGhz3xoJ0VwSuA22wBSQASASBDk60Bfq8Kok07126zGojaCahx7Jgfdd/94z8Y/8G2Pk+wWHK2qfAkj4L0WdmvN+NmiScBBvADiIFowWesB1mIQF83keQMoOV+SJjMVst0hmjMdZJirPcKDUAnacikHCoJKyXXL7zwQnf7Tbd0P7/u+u7ZZ57N0Cb3uy1b1h39nuO6lce+o1u0eEnAFD+gLxoPiVFJiu96D4OTl/R10pDMlBEJk7451exiNfvD745uo+YxgDt2KGIC6JokqThYLspYHQU6NPBAruvP/vfvjO6Xsq+gdtoiEdMXnt5VXP5FS7Jf1MHQAB/w6tRfQDA+OfPrPOC+BhBWWE5LCpY6ZNZ2UMEI4KENDy4EZAJFnJJ0SACCUffYI490P7z4n7vnnl0PyxbLLrvt1n3krN/p9tKKABBEGlk18wl8Le/Vl1mbfZsp7ZkqY2rfR0D28wDufhF6FmN0G/dS32a6VweNITs3eMPv5w3U7+1Ajqv7E9vytDF+TVV4YWe8ceMNOpjtBShkbi3jBJ7DG4c2Ao9X6VOC0BagAZ+Z25JC/U4UUbuvJRNI9jMfuUQdcCWD4usmX5XkZ7b5IaDGCTDAPXT/L7sf/vP/7jZu2GC+rb1bsnRpd+anPtHtd8jBEtMOkBLJoo5sAy69WY7beUBjc8GyTxyDLi5sr707ycMSPyQAYxABevXXFkAcN90C+kQQn1eW+fHq0eJFx605+9xfba2P0LX1autYeEnXr+oZ/PYQrwFmsAQOwBB7gk8bcAHW4Fd7E/AL+CTSRNIgo8k0zaLIWuokW9QtbfJ2mlksOnTFJielxtY/ta77v5r504JPNDZoy/g/3/t+99y6p9vyTMJyoI0vO+ldniT1UunGR2xapIe9+Ozl3Ndlf+wu/opJbYflYx42t0nVfGOsSviG+ExOvsUz3V5gY4yKYSvqQfpWEPN6/sy4O6mAogZostul1QTBM55gcVOgoMVhjjwVgKoTsDjuYIjOMsRTupCTgCWoFWRkVCCqhneJALjysv/o5uZ4KnbbytzGjd0Vl1xqcG1/gYst+Cgd1i/x8QW78Xmwv/wvv8xnmqyAk/yOTeOP/MStYuHwtslFzBV5TxDOF46PsLnlwdEF03irl+G2rvBOHi2F/0O+6bUJ3UnpjLM0gNhIXScQrZ4Yp5+lFEPttNoBF1gTMF/DoxuvBVQw0QcPoEJrWTI7Mz7OYw+zEJuQ+NCvHuh+qgR4pWXtmie6Aw48qNtjxZ4BXYr8J33UBF+VfSMo2FbXjLuowgfG3aOaTRtbKQyxajI6htYeWExWU7jMb3I4dIMhZyRyIo83eGjYnbTTWadd+tzFl91f1C9Xb9UKwLKioH5Ls98v6wYQLXcyhGAHqAacr9sy2MbioE66ujb41AsyPbyeJSYG1CRFEoalPWExv8aqruSo5EEHiXLTdde9nN9Tjd107bVJrrLf+ie2G9mGfm7YM8QlsXFSSGNNEsb9RJdq08OrZHDiq4+VAFA9pn6PNbk1KeqJsp5GMhgDI92+tbVbwVY9DLzpgdGXdbA7mn22lrJalgag4nhAJBhkaTK+B74ZOckLEr4mKDgpGjWtBxkATzQquEitVwqh15vLMoMaPxfPPftsd/ddv0D0din33ntv98y6dd1uy5dJniyIa90iPWeQA50A0xQGNHuMCz4IqYPDnR6s2y+Pi4ppp34Oe/g1x0dfOAMyfwU4jyD1PgAfMEkHQF4ME6rVD1nu3KFHHBInGgsWmQ6IR9/6UPdldXxDt5ctmPKyhbduz8yMv+ZTtSjrdI231RcBGGAbGXAwWB5tvJxyEhgwBYNsV5uAVbtPnDY2OYtqtlcScM0sJxFqduwkMLgm0D+/+VYeH9ue7XInf267+RbLxp+lOgDiT3zSAVBJmANe+ZaVgHFZ1duYhE0yeBWQrRTa8a3NYuKEfMeLVsU9tbpTCCAXqvtHKqIm9+bnx19rb7tvxJuvtpgAkvxNubNsAAiX4midagm6Zy9AyyBAwSHGqT1uYNMfl+rg1MbFBx1jBhUZ4u9le5yx6LeOJtN86BU/jwxuvunGzXv7CnpvufEmydaJHxsV8+iXfdigm+3GV+xX7Rv2s2rSz63R8ibXvq0+QHTcTBcfe/ktLqZHbtPVy2tye/3EAT2jGd5u/80tufyyCcAndjSTzmI+s7QZ5ALIhpVzqqU0jmcm4pBncaNjDKMtiwD4usl0OydqkSuYopUey1BHZnqSoU+QJtc2iZ+HUNjwwAO/7lav5u1027esfXJtd5+2AvRZ1wL7W9AJvG7YXbaTrrQBhZmKX3m4SDxox1e57eUzQIu/4q3x4ofe/egxb8Wv9CcGLAzeksbjs8Dw5SLxsgkgQedNzkIvN700m4yqfhlqSmV6K2pkaRquKxHiKI4kq+Mc4Jcz6Y/+5qgc50mmJA+BaYGogIj3puuvL+3bvb7xxhui2/oKhPhQ4JT99tP2ZnwAsflbNgNkyZP9ta2q26VqlnWfL4gpI228UaVi69XNE7HJBMMMbv7+JROAD2oK3FNKYDlYGcp1W2qcjW43h5P9zXFZGtAnsld95m8AVnBIMC/xqhkHaOvHGfFkViA3Y6XfT8KIRs9Qdrf+/LbNe7odem+//Y5uo54gwpalOnPUSbwSEntik2yV7RT7Zj+VsOLjP37E1/DKH3zchJ+xSih89tbT+hibnJyWs4A/GaKHm6cEy80H4CUTYEaf0jVIEuoiAxYknWa+HcFwjZSjBWYFokCqJ03K0DgUIFlE9O9EKTnDzAdwgpMtwm2uSQLpdeCodX3Lrbd2G6Z8ynfzYdl879zcRp0vbpbOptt6my3YAzitLv9jb5ssACQasdnhJMJCfrYMeIq/4jeArfGKefM71hJBiU3lldcxEi1YhubF95tNAH8+Xx/RRpiVyanK2h4AAVKOsMxX8ZLfjPASjbEERQQGrNEmncJnJ5sztBPE6KxAkP2WU+Ajt8mu4FyzHR/7lz+b1tdcf+0AkPWXHfg5OSsnZ2/asT/Jg1+On1K/4leAVYwrmbChtoayxzwt7IlR4jy0E0firLchngmmxTtZbzYB9Jj0qxiDsFJs3Bp4NhDAlBbQ1KylnlyysK/4Wd5xGIPgr/27DC45A79ayNNtQWAJOjcSoZfFK36Pdg/8+oFJ316V9sN6ZfHBXz/Y29/bYpsCrm2T3RU/aMpP0+va/st++91mfQzW7EngVLWHyk2W5TbfHZfiJ0bq78sEv7HRGJj24xONCa708rUsyslPtUmc/RulUpYMhq5lrRQVwANQDRzPVDlO3fPjeGayA6J+AIc3CTEECrlOwkl+y2n86ufxeGwadVdft+O+fOMa6SpA84JUxSZA2F9AkY3QUSqxqd3f/Mr1BD/9/U0J0uQUkEXvFVRjjj9g6VaxmOS3ct3Nj0efAtu6rvpFCcB38tRTvjjiROBOyih+CNOAK3Cpma2NpE8K+Wp+G8RjYjuWvRzFk/wEysuadOFUBdiJRdBaIHPwSiIVDel93c3TP/Y/9u1H6nnTF4XAfr7c3fW33KTD4IbeRvzKw9C8tOLtTnKxOROD2CQYRBG760AHDdfZxlqMyl/xOP7iMeDUElArY8WvZICNC3s3ikRcScF7N/J9SyGp+814P/4iCqxYdwGPrEzmWjCDKGgFGjIz2RmHTK8+jEyBiZUDgNWkMVEA3fx9MDITeifRL3nlEDop1Dffdlv3rJ7+nbb87pkf69515FHTsnXPP/98d9NtPDMYH6hrZcMegylv6Lf96guN7Jd/+FqAEmhHxkGhRWgSpEl+r5L2P7FmzJxhaZMu77PwJGmxskBT6iHi/Pw5dV11oeNrPXV4op5C1Fu7y/BhVkNgd6XQTsqpApwBxmx4UkeOtmyWw8irwGRGKEjwt35nsANXtAmU+Ro/+uuwF1lNv8avvPYahqcqB+67X7fyLW/tzjjxpKn4ivhn0ln+10qEXdjMk1345BO97ae/ZnnajNt/1X2SmzZbYuI3xGGIbywg1pvyN4REIJA0TlUxQ4dAOgKMywfqBQkg+nNwRvWCUo4GsKCNkwV8zdxJukzzJqYJJPM9izVdkIVRXg4lyAGhbkEMXTNP/PSX/gQvvGufWNvd8Yu7Fti7NRcfet9JHW/qOOHoY7s93qRvkZ2y3H3fvd3qxx/v7U8SlP3YnfgMdic5iJFpqfG/+UWNzwGRgLWgtVbFpfip8ydKryjEaNBPu4qx0kWSs1uwCvQJwFu8JfFzMMHqDCYjUVOyWsPGYrwzNiJsRKPzOGMeD7i0oUc6fy5Uzfie30O6a7oqEZBZ+qI/zv7suqsja4r7xYsXd2f89vtt35JFS9R+3xTcA+kV112ToMuvSv6FNsrf5l/vcnPd8PaBBW4SpiUHLy6REC0pKp7W3PhpJ76JM5ODMohscZdi+FNM8zlj3XpqpOPrV/VK4woEWZgM13+T2DJLwlBaGcc4huN0Od6yjAE7jx6MAsg+e9WBUVx7Vk/yVx+6uLUx26Vr9PTZLwNYiqctJ77jnd2ey98U+bLlzPfrSc9tKGw9+lIPWRW7yjZiUA9zWcodG3xRf60IRYtfxKJuALIghhoXq2NZtBVHcODPsDYbGIPfyAAQzQm9ulzhr9pVN6VPAL16ejoKTM89bVUxmt4Ut9wfo3GIgq6UyHB2tnMARllw7opwImkWLu8O2ERSlMOV8YjBrjvuurNboxdppi0fef8HxD+sUIfss1937OErpxXTPfXM092td/zctuC/AZLdyMYHQMVO+st2J3Trt59q44/nC/cEXSXxC78BVX8i25MM8ZMuADAGZk+isf+7NHAYwrZ5fc9yBiYSQIeK022F1JBVnn1Y1pcgbDC0RJXBUNB2Rk84Wi7BzoElsznBKFrsqoNjOaeesEqqA4fjujUf1JsXOxj78dXTfx3vPiv26t575DEGplYYZH3k/adi6tTlctkAPz5NFmZn7KcfnxK/vlZvraSJaUuclhyhazziR0pNRkD07J8QmWSqJBkGykfiRrHOUbcwAfjKdQ2810DZGWUOyKpdpWZMwIgw07dMp8cgGtVkWhlFIFICM0YwlvE4XsGykxpDH/Ip5ThPinjrUM2HO268ffoXfj76vlM8u3htfyedBTgI8q7i04777W7ZLrvGzCnub1l1R/fUuqeSBLK5koEZvNB++YRfupWvPqHrmjgAEN66ln/Q1Qke/xM5DGOCZsLBhw7zGQASBd428zVWGBq/FlOwBnOkOW39ffuSCZGLAKqEreDbGSlpGWRQUEYp47m0kyimH6MoquNMrQAykDEThAg3hoRgCWvOOKgJBvtqBfinOvxN+45ffPioZjrvHir5+IDMZTvv3H34hPfb3GnuiMdPrrk6yz2gNRuZeQEaXwpMtdU/gBnfCYO3iwl+4pP4hSZxHRIFGxm3H8Q7/8FbA4Ub9iGrkhGbRLoYzJFhxPmxBQYAkj+kFBiWbGXKUHHakJZ5CHBCSKQzTLUVokKF+8iJ7KE3g/X0byWNHfZduJ3d6JRibsjKvjrT/cc1V0E0VTnhqGO7g/fe17aWfwEnK84nT+pXxqnksg0gp5KpwMTfBL7F1RGRL/LD9C1ZiKui7tjhPhBBg40VfxskupKdfslt4EZeiz+KrYv4J9lNaCHEU5byAxsqToD80kby0sphDhqNJQDjILJrCMML4KbPDgcwZit7lUyBED7d/EZPEceI9HtANP2bTsVXoEcnCZQAoWfVPXd3Dz7yMCKnKp84+TTbi0z02/YGBu0jD31rt/KQQ6eSCfGja1Z3t961yiEgQthKMSi6nlzKAbbAwHtuZQvgEipPQgmhrlhSWzAMCirXyOWSftfIAnDD2qwIANaBPLPDoF9XgbUlwHilldKBIqioWwEYX070QUfOU6yKO/U1kxp7jLCD7bEtAzaiZRFjdjJKLY87ksYrhAFaOPt/fM30h789ly/XPv9eBwKwSQJ8qISs9idP/mBvwzSNH1/9M8/ayEly0QbwhkEvLisASZgY1zJNbCb5E9iwETUnT4tTIqtEwBfxOfyQWllmvjkLRtUkGMVd47Ef9szwA0vq2QcJgOHZGulGlmAxFiMzgOHYzo0eBBrE6tQ1dlRmk1z1p6E46aUJg0QInyVh+DD7EYLj6EA/9Qa9CPOzG6Z/29fH3veBbpclS20nAfMBUIc/3l1MO/bPdJ/UQ8Sd9LnAacvVeoFo/frnHD9baqOH2GTVwU8VgmOfSQKSRXOWa/xVDSsFmxijVPwrzpEk2sZDP3yFH236YkFU6sL6UA/mYD/Dr2sxQOBjuEabncleqJtg9ScL3RXlIsYJO2TS0Fu56G04/LpBR7+NLDd1TV899x3jcCw6hxmRZ8eu0BsyXtgw/c/ynHXqGZ7t2O/PEkqnZbeE49EA17vvulv34fcseLo8zm7hfqPejvaTa6/yCpgkzipg/+V8fGbFUQyaTkWnSQ3wPuQqUsQKLJwMCkTiq04GWqGvaKCGtvoiANmJLSwaTlHtSa0rsJ+Zmxu/3dnXxqtK9jQecQMIxhegCEdpeDUoAieQ+mupUYcKDoXOjiHIAzHYW4bpkBF9LMtOirJajBXIS6+8IkRT3L9LT/IcdsBBWS5lSxKxLdNca0OoPuqzTv3QFNIH0ku1DUicCrMxzgA28WAFoFT8uELXwtgLSPrFQ2nhMHjQWq7j52aPB12Rm2SJJiSkmNfCwDGW0adPLq/kVUz9th4sAQqW2sfDHuFZIegRnRNiUpn41ZfDTjkfOoDESXjM7ToAW21EWnvNDBwKPTzSo1H0P/jwQ93dv7rfcqa5+/QppzfbAnrpIQierZ6RQ/u9K4/u3rLvAdOoMO0vH/x1d98Dv/LJqGYZKBJ73M5KV0CmEw8DbnyGFpBImppIXIcuMbYwgqSCHmQTL/4oTjb3cWWJLamQEypkyh5N/m58WMgyg519BoneFPpgoKDCBqqPkl53MqCGFJg/z4RBUzyM4myf9T1zO3xKmh0RfzMwwZEARP/7lT9F3FRlNz2+/9gJJzuJCEw+xp1VgPZwXWNJBLaMbSmsUPiAvfhK7OJ/pNEmEdw5RM99UPb+iy7xgoNJ1Tpcc0V/4oIe4sWfqSWfVc1wpMeEbDHm0R0m6HWMw+jZg86ooZcrCj0ytgHNZXInjjGGUlPpbkgcmSEZToJWR2RmMXyRjKqsIpXpjCCTBGE1gc861fBHtfXq27Tl4yeeoid5dpV9kWlQJH94O5nOBH5rWW0DWZ0+ferp4skBbBqdP73hOp9RnATyAF9r5qcv0vB505WWcacLcTNZJkTpd0wtT7CJwPFpwUQesaKv+p1oTQ6I63+i+GIPcfmnVD3gmUm/UwcxBYBFSnD+SlDVvSPmg0sgYmEpFLubqgG4ipdJDfSJJD73iYY/F41j13W33dw9/ewzxbrV9e+fdqZtKeANRgs+ScsNW92WntDNdPvuvqceNm72jbQvq3v9c891V/EBEsl08ooal/HfMWl+2T/01QQTheNAPAbvrauANE8TFvkMhw8FjKMHhZBV6dvqI5amES3YswIsC3MDCS4RcVVLC+30pA+SABlRXCMPPv54bxrZyqjp1LCjqsOR+7qiE3b0uTQ5UCVoo+6yq3TAmrIcftAh3TGHHpZ9HtBbsAtsz8LWX0lMAlYSfOYDH55SY8htq4xn1cGv5rTD2vtI/BdIH2Z7ZjPjDVzRxXZxLGSyBK8skhfZ0IgTOt1IHrehZMgc4OLGshkBxA8pZwBKDQRcKEKV7uQllDBnOWr7PARNsrNUfMgo8C3d1xhBULT0AwaCuDXmcoS+/GXk8bWru1vuvMMWT3MHgF5ReuOiF7DrsbfblQSyafC96z7wjnd3++651zQqTbvq3ru7hx59xK4RFsdMtV0tW4hDc79PikZDRHyDQHSOtZnpDUb0A27sNZnpiBuCe3LrCzju07WlhFcrwFi/oq3i5R8K0QZcN6LP3RHicRhaab2x2KIzIPmWg/PZWpwGHjQPVgxXvTPw4Rx/tUX8x5XTP/O3VF/z9sn3n4Yw3RrwAtqz3rOcQ9/ifMRL+kgEbw9tBRCTP//PWWBbymV6fYA4Ai6g2GcJwr8ecLXdr7uAwyqQPq8CXKgE5LTdkV7dN2LThM5UTUhwhDjBzlgeztOrGC/XwXC8PAYmMxjo0werAF+cGGFnWpJwTdNGtL7osRqPmaY5byeaHPM0oxIBBIUPiTD7T7XepNr9eBte+PmQnsx5k77uDQcc8GYjdpBcJKUBF0BJUJP2VhTPWSdv23MCPCnEk0N9bNGPCvTbVV23PurE2CSODNSOmRo9fQT04YtsPCwaJVe/sjb+jEbWBH+LsM8ADkgJm5RWGYQCCnbTh93UHk9nnLGlzWL1F7+Z2134bTIE1as6WnrZ6oH2Vr3evkbf6jltOUszd0v6GfcNz2xSfOvt0vhB+q7AE/Uq4rTlSX2jyE16txDJVr7RRJ+BRaDa0TXEFDtiU+oyrdc/wQ+dqKIBPv1V/OiscfRD6bvGb07dsQWsqyyNQSJECv+6uSBcjHyX3ZDBkISuaW3Eklr89DQSG0NbY7Z7UwWyDhrGoLFu0V929fSP/Q988z7dCUcGNOTwnXqT+gkEfXzZIt/j5+/oU5/+cycmxjEeW35vG58TuOyqnyIBTxfqjybHJncVk+i3/8WJA/q3/RomMJNtBh1TxuSAv1wSBtHRb2aPadDdJIM91fMAo3X6ENB4HR04bMXwgAL/0PkuYorRgwhFIHdGjWtrgIlR32Osg8lYycyIacyj60n9dlC0a59+qrtxGz7u/Tsna/ZHukxLi+/yqW/vJEjcXtBXyD0/ry9rVRv9poEOW11ISL1/6vgTut138xtoWv/WVbxbaPXavGcRic0U60t0iNcwkPgHYGwg3mV/TCKATbeEwUo/NGlXMkDXeEspbI09/nExXqdHWaP+J0iQbfoWAFfWADdQx6hkFrR88tSqLdzMCLE5uYeWrjI2hG2GoawZaDZY1Sj5P9MTP9O+64evXvvESad5VgfUOaSqyALZUkD7WzvVRzDcbmOhzX3R8jZy3ko2beF7iq649mq5ZKeS62p70iCs+V7fNko8DaZsqeL4OTixPwHSqGiIfROxoLZ8yJvPLagv0i9d6/Tb7ON1FXCkWLeltpnbLLETahMU7AlPDDVP2aza2dtbFgF8j1110TMYZ2GYaj43RMjf5Xqr1bTlxKPfqYduK6SLoOM6fgB0k69+fPDS79k+tDHQY4zbKYfOcrb1qeErdBhEgO1RK78lQJcMwmmabuSCbgMru9Of2e3vAXQiiCGumdf8Yiq+SJHXBqn5jHx1mF13HgrDOn1N3Gids06SCApffWZppm6Gi9/GWGrsjkMmal9SGHvKUQLp59j8MAiRMbKML2AWYRsvSbWCo4tEe/f993YP67H0tOXuB37ZnfP1P5eayMSekk5d9r2UXNvZBhe0ZRery7xiNE15fM2a7nZ9cunw3zrMyRWAJKEhRMyxKRMq3QHeQTfZ3Fy2516vhpwQ6kCefQJQ2nir2G9aSj76ep5RRwKMn2xsGtAQowbEDR+UeN68D5zkAy5flBZDUag+faoE4PgKd+ShEGBdG4TMrnzBWpmnmcmX3omFr1qjAb1+Xlazf/r3/CH1kSdW+1YaXg/1FVrJDvut37IpDfesNCQTHe3DJXx7qL93kPjpz4nhhBMNwBIoFeJPM5FOP7ByPfBlezOD7vokEbkhYmA8flKHwO7usIbUwtPs71mSDKR5UIMRMpBrX+le11Xop+CMidS2Ye7TyRsHTKQ72HSb1Munb/kI9m9KufHWW7pn/FX1mRD4WjEirhT6+v42SMyynU5EouIsGsjgJ86RM2AwGU9Tig5Z0BWVcu8X+iHv7o4sktxHs4FboFOzUmxhFJU4EVRJYAXqyym7KEPnvRaHyXSV1PmJlD4KdoYVIjKv1ff88QMPvyllo75b6Nqbrpd/dbYgfg6GQ1BgOa7qJrZMOm4Urome4wMKxLKNEW0u4R3w08HXfeZGgrGhLirjp/fXzuiZo1UYALyGGEG6AVxfmj7vV4hrBjHeJwsG2V5/Jw1UkacWSp2lMKgUP/LKeevWmFRt0+f9kPt6Lj+7hpeyA6jBk6OZHOkjJoSQ2GtHcIwatfjyHIwJcBJC9dWMTlfi7QOkZKDKZI3O1xCqwA3iYD+zfOf5VXRyOnUGwRVLGjgRBo0TQ3QudIsOXQWiBKjEEIxDEzwFLkqHxBr6a+ZT8yLKL/Wumt+0wruZfq13DE36SlwcMiJv4HMGcH8DcWF8Q01sPGmJsSWkH9n5o5u+rKhquKCDUniB/cx9vzu7VnSPIsizWUSIbenTE6PHwjVoRQ1c+KBn+c9qECWIQBG0ENicNJ19jHmJwyg7Ep1X6nHzb2rxKoCvLRhMOOLjZyQVD414CP+JdR8/j6SXGDum0EpOwte2C4tu8ZTcomOilk74PdH1cQaw9wvw+qbpVShEGEqpc4fS1qfajChtfaWAa0Csfi7dp3uUQ8etfwxs8rhb24BrPSt3g76T9ze13HjLzd2GjRscY4PLIyDHnThVXAN8JgdhTZyICTFMXOGikEDZRn1dgwKQCZky8BivRqNer/xOAH1M6KqWFVaYmSz2JoOlgz4yFf4kS8BN9kKoETJHzextGJZn4dINF1tNVorkO32NV2O3/vz27tn103/Xj1jfEMXfLaQvs4zLiRX4AuLw03LqyH9iKQJiZvAIlQoxqzjCX0s72HiFEFbOKFPrjoRQH3zQZOse+3F2VoDx6BKARD6JAFEyNBr7JUQjGFLGAGwVnk6dkwwz9wOhn1h2PF5sJQtd8F9//fb7kYey6/VWX6/3DDq2AsS1/KYQ6cRfDQWIhMgkoT84QAdKXh0gq0DS32Lo+EPYGo4xCSHiIJvVYSzMoXICLF46vlxP2mwkS+CzOluU5agA95gSAEEAZmBtRcssCewVIt2SNCaZtc85Q9VP5joTTdd1Tz75ZPeLe+5pV7+51f36FbM1T6yxg/3sVSwyy0kKxZzZ2uKTSLACt+dPGFAhKYifgRe9c0FDlRNOLvCEHkwbH3KEx0YwR44T4LHPzD4tedewlKDcGYYkgwtZWxFQpL4SZnobkRx1hjWFOMLDGeqNNFySg/BXhtthJdMN2/Bxryb0DVddp280ByBmuIEKnAaPSFZc+3HRJnK4qvjrHowYhxaodGm8PMF8kevC0HqQA6bC2piLxAmgGgVeEmhTIiiZyLUZWz+KKUmEZGL2MGWwxrySyIikBbQY25aplmAbGY8YW3+LvoT5/5dyq3z1L5q0AGR2kwxMjHo01eLjGGmMuDJG4jQ+VxqHJFtDA9g9RDOywKPwA7NJrPVaQCsz40s2zo2/OsN74ZUkZBWlsnDRWK8cT75oI0NMpYr31VMwxEmhF00wtqWlR3iXv3PVgpO1ZCWZce9993VPPfUUIqYqJ777+O6Itx6mly7y1m6YEc+7cSn0UrKQVR/XzKIWORPoDuNVktzQDgnKXPWYaCr49NG+Qe9XuGXKbyp55plnujvvuqs79G1v8wqQaKAvN5zIbw834PPMkJ3rn8eXQTWrY1PszaTk7MWWwQrRYGj+0SeIL7FDuusTYL/F3U8eGndrFIAVZNnCrx0FUMDys0d60UcBlOTKKo852CxVCrqUtKhLBZqzteCY37OmfPXiI+BGknvzjdN/zStf8fo7H/lP3Yrdd+/f6Ile5PNeP9TSjna1pats8TjG6L9PUrW9cqmLEp/CUQFmVSRBcI8+aA4+8MCpEwD5N99wY3fI23iFsG2HyJPsfgWFCOtRZjuzKqOXFQM7HH9+Z462/gr0st0SYFc8vMqwEsx0a8C6flOl3wL4CXJl199liVAAMEYMnslWgDiUSVEbq/0GG1OyP8FjGgUIY7hhMDUSKLDAt14vktxz5/Rf9Hj0ESu7ZfoVL7aeHEiT8djEO33Q/wKBsn50103j6n9ez8+Xf7Rf4LrJis2h34As9b8A+E2GQdAMQ+/++x/QHaLfFZy28PMzT+t9gw1bWQuIScIkRdmrGhzaOHq8gil2tU1Tc8ukKzAy6ey/xkgQ5gUYg3XZ2ycAHWK90BneLixKTBhUyjxLNIARGEyBp8YTnCyZtRxBk7aMBhAZBB3G/fyWW6Z+jR1573vPe82P3gIGoGwLOnqbE8Dn5/QEjGirHzoS4QXeEtbbnz34+Qa6Z43G4KNdtlOzKluvxk6ULdMWzgA/1y+RRVbTIbme1RLm2MuHCjJ+Wr9o7LMoKv7FU/4lgfFKBdRVSDAO4+q70B3tbkECrPnC7JWiuDMBTWDhcGmCqFCAMQm+wMZO9QfkIZNJg8EoOWnQUxc/QZi2LNfPvK884og+EAYewHubElD8wMYkRhK5aO2Dx7CnJQ7XuvGXGv6sLEOShb74CfO7jn1Xt2TJkmnd6G4n+ZvdyEFn2evlvPURN2AMlE2NYo6/k/wtbXpKMIn9odPlncZ4wtIFCUC/9lZnSOGOo745EDJTxpjOd1rymyExnODULUGEd7JM8j/y4EPdWr1jZtpy3LuO0xEipqOXWy3pteQTHHQzy1k+CQRt03ssK1DxJ1EbvXyA31uJ/UnCI9tyvEIkEfBnydIl3bFHHzOtG91Ta5/sfv3LXxo3iZkogkrXZRN+xJ8hof1GGnE4nqKtuBor/FNMuNU6zXhhO6GoHZMnepbMzH9byvQXIG0Xd20FKIAJnIPNfJFCbwktRcsYUhbWGJWAmd+AzHerNAO2pRyvBIj+SjaBKZnceHgJSBsAHh9aIGqm0M/NM0P02MYYyeF+gm3fmmy1n9dY+NVXelpf4jHfHX/88dviimJwq2TKBtsSe3hGFT3E3PGX5AISGIj1Ahsn+G2E/PFy0ejso0SB7aZGvmgFePjs2fv0KOr7AbEZhHEtkDgcWNu9LunBIG5Wph5nbLt2AkzwI4vnxe9dNf3h75BDDu723GuF9QCMZRu0zG5AZM0pWxj3zFdtH2S/Z7fomOG+6RxAXwUVsL2iwKNbZj4rQt5C7uQpOT48jruDDjq423vvvTeN7xav77/rbn+30GBvkmwy3sQcnaFJexAcAMCr/OMxlmkVZyeC7jSjvw+2A19aL0oAuvVQ4euZTW0JkXAX0o9k0LUz1gCzlNKXmVSK6aM4cxt7VpHQ3nvnnd3GbfiFr3dq9mfW4XASIPpjF/oJlu1Xu/zobQZU+mXfsAqENzwKNL6QxMWv2v61PsvCZ/fDm/F3sTVNWfjeg3v0c3TISJmMdfCL/BfHvBIRW7HJYFPrVgfDwkZP1Xx9c6ZtNgEeP3uWH+D5IXAj2LO5Bc4Aq01NISe8v5Bl+gNwXMCOCswkP0Gj3HPr7a6nuVuqb+864siVtsnBb45XIAJIwMA+7/8yhH5mL322X3xV1+zua40VLfZHBjIbj2QkJlmmSbWy5ahjj9GTLJsN6cu6mVjkYdugp1Y3RVW6K84+x0uaazp1sy9lH741rIak6n7YMH2RHS9p7Xg8c0GMyUu6tgB9FpH7ydm1sT3z5P1MxjCHemd0TZt9jXrt42u61Q9P/5bvtx91VLdIn/qtxLJMnEU2wKBV7Txmpz+rATX9bA/VrpqHRqELfSVNzaoKbvUbcAc4vuQZO/FK/8677NK97fAjXhTkLXWs1Q9PrNavkcWfWlEjv09u2Z/Z3GrZ7WvpTRlmvdHRHfLgB8uXsuElE+CJc752uSbx5SwlPObFwZo1WXonZkQDG4OgIRlcq00gY/gAxj23TT/7ceCoY4+NUxOgo6dmKbVtpDZIjAG+9kRdc4OG/b1srWfP6B/442ueHBrsx29oiMULJLzafeI3m45+5/QfJMW3exUTTxDLHJLX8WNWS6d9ajH25MOWmnjqJ5GNU6uzcsxcDpbo2Fx5yQSAWE/Unu/ZYSWcB1ph6ZFRVbLPsyixBVDUIxqT+Tq00OHkQ3ff495p7lbsvVe33wH728lKqJrFsTHOZ4a22SldjOVAl3bxcoA06BwECaQCDK1nodLWfY3fSVVjE4GuGZuZlqR5y1sP7Za/6U3TuGbah+6+zwnl2LknMaSZLdadia+CnK2AaCfi3nMd5nxcD5tIEo2eH87N379sAqz+wnn/LrZ/BDhk2+EKFLXbWWaSvS3wCpYzVuMJXlst1L9+3dPd+qen/66ftx9zjAEqMEp+QMsSz0PAgCIAOZ2XjQDp2VJ2cI39At5jalcN0GwLxaua2V5+lM9OOo0loUg7dCNH37v3jqM3H+2X6X1+/fruWT01bLmbxG9YrWK/dWIf+uom/V4hbEklSPePDcOX1PyyCdC4viw3n47jKGxBxGE7jeMtYM3wmmV9UMpIxnXqnbbwkay3HX2U9VQwkB350Q9AHORq2bZNZR8gOgEAqJKSdktq9fXAQlvL6gQ/ennauPdf14N/AzDYsVLJOrH8bbW7fAQMQNGl+yYf/9LvWjZNngvsJ3G1/8EBfv09LcVf3pLyLSaAnjp8QC8gnl8PK7zMs7azJEhRGqjJkpUhr0Vt1jTjRIGxi3bZuRtNeVI++LC3dkvFV/s4DvJ8fWZl5G8o0DRGoBjzab5tX+jmMT988DuYtfSL1uOire3As0n9w/MB8CT41qUx6280kSngpHvn5bt1B77lEIKy1WVGn8lcsuuuTUdkl3yi6fj3MW/LvkHQoPrd07oNv5Z+sNuSAVtMAAQce8D8NzXbbyMAuSlg0uoltwUvQS9QEmC2Dv7MYzqdWOXoigOn+xbOle96p8HvgZMdBBqdPtBhSwOkZketDhvob7TY4VVCwHM4JBn4fgDazO6SgdyiQ46BmJBhf9RvHtMSC0CL/9i58rh3bin2C8ZXHHJgNy800FW2gycTitUJ+bXi0OpjqrFaict+Rfm2Yw/ovrlAwUtc6N0fWy73/c1l8zudddqtOoz8Z+a5M1JstSoIY66aoIm6NXn9HUcIDPWyFXt0D6+6u60gje0lqoMPP6w78j3vbgsNuU1hieSAowOPrlDDy+Ku1SZYFKijU2cYgx9+wPVkMk3oNr2GDypqBPsZRtrqQz7N0KRmBCBcC5Tddn9Tt+bRx7p1+l3DLRVm/1FnnNot2mmpZSIFOdjp5NPV5Bbs1UsGBPiWDKKFfl6uyrrfv+OTs/duSS/jW5UAED538WX373bWB3dR0E/mS5UAUo8SbCrGch0IUvfJwaUK1/xBu1SPl3fdfXm3+r5f64qezZe9D9ive99H9UWPChD8OF56ABRgEqoGhvpKGvQGXT0EBkbGHFw1AI9x/l7UFl3espYkKDmozEwUv/iwB37AIeXQQ6Kgh5H9tA08pl8af7lDL29sOfIMfZvpvm82j+VJETb1h1qNRB86c/NKgV9NV3zjYvxXT3xh9n96YCvutjoBkHXCl0677OF13RkKyCEBON+2NaMXD9hLSAxuOAE4rnTtgoWMawBnlu21Z7f3IQd1z+oVsec3eVSwRDPhbe9+Z3fcB0/VK21LI6/dR3BkIZnH+NhSs9F9ogUMVGKHn8fQdRIotEkexmJrJQHvDiC4dFuC+NlGIj/AmMe6uYYucrzFWHdA4vB64BGH24anVq/u5rXlTJY999+vO+rMU7s37b9vbGuxwU508CgF2XVAhRef+Bg5Kx5tkgQbnBCj7opjD+y+yIoN7dYU4jVVWXHRBQeP5+Zu0Fe67wXYw7dttu/ak9O8/SpvweKtWOpXH3SmV5vgTl6/sO6Z7hktlfMbNnbLtHTu8ea9dFTQjzggC6SQoRuF7w6Ev97i5Wv6JZ+ZCk9WmmwR6CwnCRhtatOrVaOZzRpQKRpqAktHyXSiqB96BHm+U3Nd/X1dT+8q+QT+2sdWd0/r7e8zSxZ3u2kbXLLbrgIYoEkYp5trdKAX+AEf7YznBn3aXo1E21aF1QracWvOPvdX2LG1BR+nLnteeP7HFe9/0fKh94m2L19UoN0GNPUZeNVEyd/KKScKUIMkzYALD/TgC3QAyjgo90lEn8acCK4nEyEuFC3OVJJA6vOHGiRHbQsR0VaqygoYW7vApgtwsA3+Apt+4FKXgs+sDkDwZwOALyBBG74AZWBtS2gAEQBNZ9CzehUdRgXg0NHP6oZMdCRRMKb7xBPnnPcDC5ribqotoOQ+973L7tr106ftqtz0T28bAmaaIwWVHAounvUsUdkyNASdKrI8LXfZg6IhHA6JaEMXPkCA32NF02roNGg5arRvKkmQyxaDxqCKzwWufWmZSGC+1fbhJV1yLVt6CTg0NfNqvx7q6EuyBCR4ucHHDEYC9+5XOzoil/tKHPql0jxJgIwZfI2VDYzpXb7f0EO+b0nF1IUpuk3lS5/v/kwWfteeSQKZ6IdgOKHrSUdQ4LGWvdBS+mVNGRL+ZDkHKc8M0U06n9mivr6f8dwyxnPjetGHx/6i8ezQeB7/55lBApj+BBF+eEs/4xt083MI1hMbhucDBp3WXbZQc7P/Dcgak03wlz1VV4ycVO0hJPxJh7YNeHuIvPgYu9v8Ikm++6WzhcU2lpKzTez8CvVDL3Q/0PL7oWHJH/Z9luXcooalmT2ZHzPIMp09u5bsOhdA7e2CKaDpW/t/30fELAezs7XQKjrak3y5Nos0Z1vqtwMoJcuri2QB6qal+mprADj0c0hDTy3x8DkpBHi1Pd4SDD1OTF2r2emzeOLNey42Te7izwQYkosJBy0riHT9aP+l3ccn3+VrxVPcBZkpGDYl3fv7f7l8ft36SwX08bWHs+ABpsEHdAUJkCmVKIypuz8MElw+z7FYXxYFP+PFAz8Bo4/QIrtkMZDzgZZ9BYXzhjfn5pk/3wAg7doCqm0pXCBV9SSdxwBUY+4PHbPXW5W6nRjSz+pGn8fER404QKJwnW3AoEWm+pHt7UZkzHqvko2nEom6+HtZolXSXTezbOcPPv6pr/Tf88j4tAWvXnHZ9+LZfTY8O/rJolF3OAH3TJRkZnoAZ5bmuDEkAKAC+sQML9AVkJrtxAMeaJMASS5C6wShoWKdNCbkub+QV38KDGojeLLP3UXTSFV5tnOpoclk8OyHX3xOBGgFFoST16jhuk+G1iZZDTo8jSazHUNIlCQL4MPPBKFm9ovirsW7jE9+5NOz+mKPV1Ze7PE2ytvjOxe8ZVE39296mlBJoDkryX7Yp3b9JBxBD7D0aRZz7fHM6NoC8LASAAOdPKL1QzoJzoqQxCFcppGcFOigcFxd90lRxBM1q41ndONGN32ZsZFtZ6Sf4ANEjcOCqIAb0HwAFC0lwKkWlVcF94nOq0hWBmgqaQy6VpOSOSz19ESGHv/fNdct+vDaz597vzpfcSFO262wEmxcP/pXQXE8wFIMsEAL4AOwwzjbg5b9FyUDpgXkzQFv4brzGKCIv7YMxiy/ssAhjawCUyxBD2LZB7+DoTse+rn0NAE3nQE2qRFQSKACXk2DTR9AA3ABWonjZGh6kgDoDG3OE0ma6it+Jch1S3Ydf2x7zPzyBRe3a2lngosFzIfwHOBrZqPMCaE+L9ltPMt3AAJEJpA/4NnG4QPoSgiCmzmebUBkBq9WBs9q8xRVsEYCtNk6oIKP3pTM8IW0jDIznSC6gMerA0ZWu6+zrFcyMJ5VIOcEEg1QSYmi6RNA8gx4G0MH9hS/6h/NLN/l0690z8emyTJ4P9n7Ctt+dLBh9Lfy8rOAC+gA6MNbA69mqxNCfZS+bZ5AMwk8NMgAupIVPmagwJQYZEyWSi54oqXNdl+kB/oCOLz0Jz0KoIxnH7YuUWSxDocPgtJQScRTtEjhmgK4rtU/PHlEO/056E3SAH6SQAn/3f2XjL/4Sk77Vr6Zu216ImgzchZ0PfYPl8195Z9Ou/jq27pd9CXN79egYYeIUy8zmPgS1JqABkjdOJ3g194KHQLyGgIyKIS3ZiIc9KQOX40ZiKjzOPrRCa1p1Jrsq37PQGarlHPDA+oCjFlcK0P6o9/0jHmmB3j8hJ7XFKDii6td65ok8rjsSjtJY37lqtL5G3/8+e6P/uGY2enfSeO4vPydQvHqFp42loa/WTwz2ovZSICZ/cxUHGcm+3ygfs9WEeQAqOVb1nGgIwPow1hWhFq2szokh0xn6cjPmcKJJh7rET9FopKADry7rIf+KuhlRk7yoxPwIWMcgIoF0Pnj3wkiAsbh9wqgcZKlkjt1dEAPHfShVWJKkBJ3tao/3Jand8uPramJ6ateeAFJr4ZcJAhOwtlhOxDYCuyQXfcJxAAABPhJREFUAAEpy3aW81rCia6Xd1nMw0uyobYDLqqNQwADbdqsFUk8Rup5BieRCEiOyXbATEgm+WspL/mAWOPVHg53WcqxC4B74AUy2QPYMNPvttSFDj54xlfohZ2zp31hJ1ZPd48PO6Scduns4lseHF0gcP5U+47gyQwHqMxqgdYOgMP5IOYVmJ7l6vITP81qJ48CSeDgA1CCDGetEJAmCQo0dYisEq8AgQdJlKKnXQBHS9vXm07PeIhUeqA1JhMWPPTzeAGvGlnZOtJGjuAfj/R6/jsO6s697IOvzpKPHZMFn3do2eM7s6fqK8q/JVD91tmAz6qQGU3k6pk95jArxuTWgLG+JsKAqBoagAdQHGo54D5vBxAScYr5ACius3Qb7MYU/owjE3gYigCN6p+EsU6N9W0RJQEymyGsZwihQUTOGukHfAorC/qVALfp3Tx/tPbzsz/2wA66SxR2kLJSw2pw60OjL+sn4b6mRPCP8QBkJUPN6tTDTDXwIKBwsipUcdvdwzbhiId0M4khzjbmfKjLPknUobbfjtH3iWFBQhTQsaJmP1cLEgE5ApnEq5WGGhoSTL+v8LSS6S+O2X/81ztq1sfi3BOG16ys+PbsQQr0NxWjs3RI9EzzAbG2gjZLKxEAzauCLM5Ty+LUv8fthS5EVAk0iXKtKk4MqCTb24X5Ft4xxuyd5Me4AWRWnbbER2UPaOa6WNVf24PBVgezvs4JtKXnn2TDn2zNu3cXWrj9rl7TBCg39vr2+WcoXucpaqcwyxWbPFkjMNkaWCIL1B5s0fRtCRpWBA0sGNOF+KssoANFlKGhNQu0orcwjQ/gM8JsVoLApDLJMyz3kqthXvGDrPhTjy5X1/lb+tCGhb/Kd/HgVVayteL3vPAvTpkZzZ+r0J1Z+38dEOtA1z/Ek1ASAPwIcH8wbKAwkKQRoftEqP++baPEaAG+mBjnGuJUeXq2XSNLPAaysXtvD6lnuYHnnKC+ejiZuvshH9R8uc/qoXJHFmx83ZW9L5p9j7bNr86PR5/Sew8Jc5vhmDvs8yzh/TOCk4DjUUgXrBK9owY9W4DF9wNqtLHq6me3kye92cvD78Nc0wVtkZEg/Plk342/ryPL11/qI9ql67WoMf11W/a7aPbQDfMzX9C7YL8oI/Uq4+T2ELNZ0gk02wT15AphCvFkNdGV0DFADTAnCUQNtcLetboNvnUiP6VO7e3SNAX6MNt5f8DMXUquv+VrWTb3zRzF/1rX5ddrbccW9evAeKKMPUcz6nOqV9QWAaMTQ3WcaQ8buTDgwMPYcI5gG2D1aItLCE0F4XBa35R/coYjtR7KkXh+BVFfwqiHuH+nsQt1sJv+J8/Lhh1YJ2Y7UOErVcULTQ9v7E7WR2BOV6B1G79XTiyuw12d7P2kkJRVUpANgNbyIluHruklOWqphwZC5UFPDxcv4GSFaEu/ObuNIrtG/Jd0+qpdvoHz1XjBBpNerZL4vFrSd4DcN//97LKNL4xO0S+gnq6vrz1BG8JK4bcPqvukaCAX2JPQ1krgxFE0SIbJceS0AxzdjyozVunrNq/i+/b5yvX61m3o3ojlDZ8Amwv6od+b3WPdczMr5+bGb5eDKzVnDxPdHgJvuWbxMn26cbl+OXu5gFzuma5f0R7N8BO6Hb+iqq/OH/M+u7VKJP2m4mjVokWjO/iBJf++0uYUvoH7/h/+/mnI0PTxNgAAAABJRU5ErkJggg==";

  // src/popup/ChatGPTWebFrame.tsx
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());
  function ChatGPTWebFrame() {
    const accessTokenQuery = useSWR(
      "accessToken",
      () => import_webextension_polyfill7.default.runtime.sendMessage({ type: "GET_ACCESS_TOKEN" }),
      { shouldRetryOnError: false }
    );
    if (accessTokenQuery.isLoading) {
      return /* @__PURE__ */ o3("div", { className: "grow justify-center items-center flex animate-bounce", children: /* @__PURE__ */ o3(GlobeIcon, { size: 24 }) });
    }
    if (accessTokenQuery.data) {
      return /* @__PURE__ */ o3("iframe", { src: "https://chat.openai.com", className: "grow border-none" });
    }
    return /* @__PURE__ */ o3("div", { className: "grow flex flex-col justify-center", children: /* @__PURE__ */ o3("p", { className: "text-base px-2 text-center", children: [
      "\u8BF7\u767B\u5F55ChatGPT\u5E76\u901A\u8FC7\u771F\u4EBA\u9A8C\u8BC1\xA0",
      /* @__PURE__ */ o3("a", { href: "https://chat.openai.com", target: "_blank", rel: "noreferrer", children: "chat.openai.com" })
    ] }) });
  }

  // src/popup/Popup.tsx
  var isChrome = /chrome/i.test(navigator.userAgent);
  var SHORTCUTS_TIP_KEY = "hideShortcutsTip";
  function PopupHeader() {
    const openOptionsPage = T2(() => {
      import_webextension_polyfill8.default.runtime.sendMessage({ type: "OPEN_OPTIONS_PAGE" });
    }, []);
    return /* @__PURE__ */ o3("div", { className: "mb-2 flex flex-row items-center px-1", children: [
      /* @__PURE__ */ o3("img", { src: logo_default, className: "w-5 h-5 rounded-sm" }),
      /* @__PURE__ */ o3("p", { className: "text-sm font-semibold m-0 ml-1", children: "AiKit" }),
      /* @__PURE__ */ o3("div", { className: "grow" }),
      /* @__PURE__ */ o3("span", { className: "cursor-pointer leading-[0]", onClick: openOptionsPage, children: /* @__PURE__ */ o3(GearIcon, { size: 16 }) })
    ] });
  }
  function ShortCutsTip() {
    const hideShortcutsTipQuery = useSWR(SHORTCUTS_TIP_KEY, async () => {
      const { hideShortcutsTip } = await import_webextension_polyfill8.default.storage.local.get(SHORTCUTS_TIP_KEY);
      return !!hideShortcutsTip;
    });
    const openShortcutsPage = T2(() => {
      import_webextension_polyfill8.default.storage.local.set({ hideShortcutsTip: true });
      import_webextension_polyfill8.default.tabs.create({ url: "chrome://extensions/shortcuts" });
    }, []);
    return isChrome && !hideShortcutsTipQuery.isLoading && !hideShortcutsTipQuery.data && /* @__PURE__ */ o3("p", { className: "m-0 mb-2", children: [
      "\u63D0\u793A:",
      " ",
      /* @__PURE__ */ o3("a", { onClick: openShortcutsPage, className: "underline cursor-pointer", children: "\u8BBE\u7F6E\u5FEB\u6377\u952E" }),
      " ",
      "\u5FEB\u901F\u5524\u8D77\u8BE5\u7A97\u53E3."
    ] }) || null;
  }
  function Popup() {
    const aiProvider = useAiProvider();
    return /* @__PURE__ */ o3("div", { className: "flex flex-col h-full", children: [
      /* @__PURE__ */ o3(PopupHeader, {}),
      /* @__PURE__ */ o3(ShortCutsTip, {}),
      (aiProvider == null ? void 0 : aiProvider.provider) === "chatgpt" /* ChatGPT */ ? /* @__PURE__ */ o3(ChatGPTWebFrame, {}) : /* @__PURE__ */ o3(DialogBox_default, { persistent: true })
    ] });
  }
  var Popup_default = Popup;

  // src/popup/index.tsx
  P(/* @__PURE__ */ o3(Popup_default, {}), document.getElementById("popupRoot"));
})();
